# -*- coding: utf-8 -*-
"""포스크탑(게임)을 '탐지기'를 붙여서 켠다 - 맥 전용.

윈도우판 자동사냥은 게임 창 안의 단추를 win32 자식 창(EnumChildWindows)으로 찾는다.
맥의 Tk 는 단추가 따로 창이 아니라서 밖에서는 못 찾는다. 그래서 게임과 같은
프로세스 안에서 Tk 위젯 위치를 주기적으로 적어 두고(메인 스레드), 자동사냥이
127.0.0.1 소켓으로 물어보게 한다. 게임 코드는 고치지 않는다.

사용: <게임 .venv 파이썬> game_probe.py <게임 폴더(poketdesktop)>
"""
import json, os, socket, socketserver, sys, threading, time, runpy

GAME = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else os.path.expanduser('~/dev/개발_프로젝트/poketdesktop'))
GDIR = os.path.expanduser('~/Library/Application Support/poketdesktop')
INFO = os.path.join(GDIR, 'hunt_probe.json')      # 포트·pid 를 자동사냥에 알려 주는 파일
TICK_MS = 400

_snap = {'t': 0, 'tops': []}
_cmds = []                                        # (명령, 대상) - 메인 스레드에서 처리
_lock = threading.Lock()
_roots = []
_wn_cache = {}                                    # 위젯 경로 -> (winfo_id, NSWindow 번호)


def _wnum(top):
    """Tk 최상위 창 -> NSWindow windowNumber (CG 창 번호와 같다)."""
    try:
        wid = top.winfo_id()
        c = _wn_cache.get(str(top))
        if c and c[0] == wid:
            return c[1]
        from poketdesktop import platform_mac as PM
        w = PM.nswindow(top)
        n = int(w.windowNumber()) if w is not None else 0
        _wn_cache[str(top)] = (wid, n)
        return n
    except Exception:
        return 0


def _geo(w):
    return [w.winfo_rootx(), w.winfo_rooty(), w.winfo_width(), w.winfo_height()]


def _tabs(nb):
    """ttk.Notebook 탭은 위젯이 아니라서 따로 잰다: 탭 줄을 가로로 훑어 탭마다 [가짜경로, 'NotebookTab', x, y, w, h, 글자]."""
    out, rx, ry = [], nb.winfo_rootx(), nb.winfo_rooty()
    for y in range(2, 60, 2):
        spans = {}
        for x in range(0, nb.winfo_width(), 3):
            try: i = int(nb.index('@%d,%d' % (x, y)))
            except Exception: continue
            lo, hi = spans.get(i, (x, x)); spans[i] = (min(lo, x), max(hi, x))
        if spans:
            ys = [yy for yy in range(y, 60, 2) if _tab_at(nb, (spans[min(spans)][0] + spans[min(spans)][1]) // 2, yy)]
            h = (ys[-1] - y + 2) if ys else 20
            for i, (lo, hi) in sorted(spans.items()):
                out.append(['%s#tab%d' % (nb, i), 'NotebookTab', rx + lo, ry + y, hi - lo + 3, h, str(nb.tab(i, 'text')).strip()])
            break
    return out


def _tab_at(nb, x, y):
    try:
        nb.index('@%d,%d' % (x, y)); return True
    except Exception:
        return False


def _walk(w, top, kids):
    for c in w.winfo_children():
        try:
            if c.winfo_class() in ('Toplevel', 'Tk') or str(c.winfo_toplevel()) != str(top):
                continue
            if c.winfo_ismapped():
                try: txt = str(c.cget('text'))[:40]
                except Exception: txt = ''
                kids.append([str(c), c.winfo_class()] + _geo(c) + [txt])
                if c.winfo_class() == 'TNotebook':
                    kids.extend(_tabs(c))
            _walk(c, top, kids)
        except Exception:
            pass


def _all_tops(root):
    out, stack = [root], list(root.winfo_children())
    while stack:
        c = stack.pop()
        try:
            if c.winfo_class() == 'Toplevel':
                out.append(c)
            stack.extend(c.winfo_children())
        except Exception:
            pass
    return out


def _deepest(w, x, y):
    """w 안에서 화면 점 (x, y) 를 품은 가장 안쪽 위젯 (다른 최상위 창은 건너뜀)."""
    for c in reversed(w.winfo_children()):           # 나중에 놓인 것이 위
        try:
            if c.winfo_class() in ('Toplevel', 'Tk') or not c.winfo_ismapped():
                continue
            cx, cy = c.winfo_rootx(), c.winfo_rooty()
            if cx <= x < cx + c.winfo_width() and cy <= y < cy + c.winfo_height():
                return _deepest(c, x, y)
        except Exception:
            pass
    return w


def _click(top, x, y):
    """마우스를 쓰지 않고 그 자리 위젯에 왼쪽 누름·뗌을 보낸다. 늘 맨 위에 뜨는 동행 도트가
    단추를 가리고 서 있으면 진짜 클릭은 도트로 간다(2026-10-09, '도전하기' 위에 멈춘 보스로라)."""
    w = _deepest(top, x, y)
    lx, ly = x - w.winfo_rootx(), y - w.winfo_rooty()
    try:
        for seq in ('<Enter>', '<Button-1>', '<ButtonRelease-1>'):
            w.event_generate(seq, x=lx, y=ly, rootx=x, rooty=y, when='tail')
        _last_click[:] = [str(w), w.winfo_class(), 'ok']
    except Exception as e:
        _last_click[:] = [str(w), w.winfo_class(), repr(e)]


_last_click = []


def _do(cmd, path, arg=None):
    for r in _roots:
        try:
            w = r.nametowidget(path)
        except Exception:
            continue
        try:
            if cmd == 'topmost':
                w.attributes('-topmost', True); w.lift()
            elif cmd == 'front':
                w.deiconify() if w.state() == 'iconic' else None
                w.lift(); w.focus_force()
                try:
                    from AppKit import NSApplication
                    NSApplication.sharedApplication().activateIgnoringOtherApps_(True)
                except Exception:
                    pass
            elif cmd == 'restore':
                w.deiconify(); w.lift()
            elif cmd == 'click':
                _click(w, *arg)
            elif cmd == 'yview':   # 스크롤 칸을 위(0)·아래(1)로 - 창이 작으면 '도전하기'가 스크롤 밖으로 밀린다 (10/10)
                w.yview_moveto(float(arg[0]))
            elif cmd == 'close':
                proto = w.tk.call('wm', 'protocol', path, 'WM_DELETE_WINDOW')
                if proto:
                    w.tk.eval(proto)
                else:
                    w.destroy()
        except Exception:
            pass
        return


def _tick(root):
    try:
        with _lock:
            todo, _cmds[:] = list(_cmds), []
        for c, p, a in todo:
            _do(c, p, a)
        tops = []
        for r in list(_roots):
            try:
                for t in _all_tops(r):
                    try:
                        kids = []
                        _walk(t, t, kids)
                        tops.append(dict(path=str(t), title=t.title(), state=t.state(),
                                         viewable=bool(t.winfo_viewable()), geo=_geo(t),
                                         wnum=_wnum(t), kids=kids))
                    except Exception:
                        pass
            except Exception:
                _roots.remove(r)
        with _lock:
            _snap.update(t=time.time(), tops=tops)
    finally:
        try:
            root.after(TICK_MS, _tick, root)
        except Exception:
            pass


class _H(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline().decode('utf-8').strip()
        if not line:
            return
        req = json.loads(line)
        if req.get('op') == 'snap':
            with _lock:
                body = json.dumps(_snap, ensure_ascii=False)
        elif req.get('op') == 'last_click':
            body = json.dumps(_last_click, ensure_ascii=False)
        else:
            with _lock:
                _cmds.append((req['op'], req['path'], req.get('xy')))
            body = '{"ok": true}'
        self.wfile.write(body.encode('utf-8') + b'\n')


def _serve():
    srv = socketserver.ThreadingTCPServer(('127.0.0.1', 0), _H)
    srv.daemon_threads = True
    os.makedirs(GDIR, exist_ok=True)
    tmp = INFO + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f:
        json.dump({'port': srv.server_address[1], 'pid': os.getpid()}, f)
    os.replace(tmp, INFO)
    srv.serve_forever()


def _hook_tk():
    import tkinter
    orig = tkinter.Tk.__init__

    def init(self, *a, **k):
        orig(self, *a, **k)
        _roots.append(self)
        self.after(1500, _tick, self)
    tkinter.Tk.__init__ = init


if __name__ == '__main__':
    _hook_tk()
    threading.Thread(target=_serve, daemon=True).start()
    os.chdir(GAME)
    run = os.path.join(GAME, 'client', 'run.pyw')
    sys.argv = [run] + sys.argv[2:]
    runpy.run_path(run, run_name='__main__')
