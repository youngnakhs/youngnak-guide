# -*- coding: utf-8 -*-
"""아르케 풀이 받기 (11/19 사용자 '내가 풀면 배포받은 사람도 자동으로', 기본 켜짐 - 설정 '아르케_풀이받기').
배포한 사람 PC(arche_auto)가 의식에 성공하면 그 풀이(열쇠 말·바탕화면 타입·쓴 도구·시각)를 서명해 youngnak-guide/posk/arche.json 에 올린다.
여기는 그 풀이를 받아 그대로 해 본다 - Claude 를 부르지 않는다. 의식이 되면 전설 배틀·포획은 posk_hunt.arche_fight 가 한다(이 모듈을 AA 로 넘김).
posk_hunt.arche_fight 가 쓰는 것: CTX·init·step·jload·jsave·desk_set·desk_restore·log."""
import datetime, json, os, time, urllib.request
import updater

CTX = {}
KST = datetime.timezone(datetime.timedelta(hours=9))
RETRY = 1800        # 의식이 안 되면 30분 뒤 다시 (시각 조건일 수 있음)
DESK_UNDO = 1800

def init(api, api_post, say, here): CTX.update(api=api, api_post=api_post, say=say, here=here)
def P(name): return os.path.join(CTX['here'], name)
def log(msg):
    try: open(P('아르케_자동기록.txt'), 'a', encoding='utf-8').write(f"{datetime.datetime.now(KST).strftime('%m-%d %H:%M:%S')} {msg}\n")
    except Exception: pass
    CTX['say'](f'아르케: {msg[:160]}')
def jload(name, default):
    try: return json.load(open(P(name), encoding='utf-8'))
    except Exception: return default
def jsave(name, v):
    tmp = P(name) + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as f: json.dump(v, f, ensure_ascii=False, indent=1)
    for i in range(5):
        try: return os.replace(tmp, P(name))
        except PermissionError:
            if i == 4: raise
            time.sleep(0.2)

_got, _got_at = {}, 0
def recipes():
    """서명 맞는 풀이만. 10분마다 새로 받음, 못 받으면 지난 것."""
    global _got, _got_at
    if time.time() - _got_at < 600: return _got
    _got_at = time.time()
    get = lambda n: urllib.request.urlopen(urllib.request.Request(f'{updater.UPD}{n}?t={int(time.time())}', headers={'User-Agent': 'posk-hunt'}), timeout=10).read()
    try:
        data, sig = get('arche.json'), get('arche.sig').decode().strip()
        if updater.signed(data, sig): _got = json.loads(data.decode('utf-8'))
    except Exception: pass
    return _got

def desk_set(ids, save=True):
    api, post = CTX['api'], CTX['api_post']
    Pk = (api('/api/pokemon') or {}).get('pokemon') or []
    if save and not os.path.exists(P('아르케_원래바탕화면.json')):
        jsave('아르케_원래바탕화면.json', {'ids': [p['id'] for p in sorted([p for p in Pk if p.get('onDesktop')], key=lambda p: (p.get('slot') if p.get('slot') is not None else 99))], 'at': time.time()})
    for p in Pk:
        if p.get('onDesktop') and p['id'] not in ids: post(f"/api/pokemon/{p['id']}/desktop", {'on': False})
    for i in ids:
        q = next((p for p in Pk if p['id'] == i), None)
        if q and not q.get('onDesktop'): post(f"/api/pokemon/{i}/desktop", {'on': True})
    return post('/api/pokemon/order', {'ids': ids})

def desk_restore(why):
    d = jload('아르케_원래바탕화면.json', None)
    if not d: return
    desk_set(d['ids'], save=False)
    try: os.remove(P('아르케_원래바탕화면.json'))
    except Exception: pass
    log(f'바탕화면 원래대로 ({why})')

def pick_desktop(a, Pk):
    """풀이의 타입(또는 종) 순서대로 앞에 세울 포켓몬 - 탐험 중 빼고, 한 타입짜리·높은 레벨 먼저."""
    try: sp = {s['internal']: [str(t).upper() for t in s.get('types') or []] for s in json.load(open(os.path.join(os.environ.get('APPDATA', ''), 'poketdesktop', 'pokedex.json'), encoding='utf-8'))['species']}
    except Exception: sp = {}
    away = {o['pokemon']['id'] for o in (CTX['api']('/api/expedition') or {}).get('out') or [] if o.get('pokemon')}
    pool = sorted([p for p in Pk if p['id'] not in away], key=lambda p: (len(sp.get(p['species']) or [1, 2]), -p['level'], p['id']))
    out = []
    for want in (a.get('species') or a.get('types') or [])[:6]:
        if a.get('species'): c = [p for p in pool if p['species'] == str(want).upper() and p['id'] not in out]
        else: c = [p for p in pool if str(want).upper() in (sp.get(p['species']) or []) and p['id'] not in out]
        if not c: return None, f'{want} 없음'
        out.append(c[0]['id'])
    return out, ''

def run(R, ch):
    api, post = CTX['api'], CTX['api_post']
    S = jload('아르케_자동.json', {}); done = set(S.get('keys_done', {}).get(str(ch['n'])) or [])
    for a in R.get('actions') or []:
        do = a.get('do'); res = ''
        try:
            if do == 'key':
                t = str(a.get('text') or '').strip()
                if not t or t in done: continue
                r = post('/api/arche/key', {'chapter': ch['n'], 'text': t, 'via': a.get('via') or 'type'}); done.add(t)
                res = json.dumps({k: r.get(k) for k in ('ok', 'key', 'message', 'detail') if k in r}, ensure_ascii=False)[:120]
            elif do == 'desktop':
                ids, why = pick_desktop(a, (api('/api/pokemon') or {}).get('pokemon') or [])
                res = f'못 맞춤: {why}' if not ids else f"바탕화면 {'됨' if not desk_set(ids[:6]).get('detail') else '실패'}"
            elif do == 'use_item':
                it = str(a.get('item') or '').upper(); bag = (api('/api/bag') or {}).get('bag') or {}
                if it == 'MASTERBALL' or not bag.get(it): res = f'{it} 가방에 없음'
                else: post('/api/bag/use', {'item': it, 'pokemon': 0, 'stat': '', 'hour': time.localtime().tm_hour}); res = '씀'
            elif do == 'check': post('/api/arche/check', {}); res = '의식 확인'
            else: continue
        except Exception as e: res = f'오류 {e}'
        log(f"풀이 따라 {do} {a.get('text') or a.get('types') or a.get('item') or ''} → {res}")
    S = jload('아르케_자동.json', {}); S.setdefault('keys_done', {})[str(ch['n'])] = sorted(done); jsave('아르케_자동.json', S)

_at = 0
def step():
    """1분마다. 열린 장이 아직 의식 전이고 받은 풀이가 있으면 그대로 해 본다. 의식이 끝나면 st 를 돌려줘 arche_fight 로."""
    global _at
    if time.time() - _at < 60: return None
    _at = time.time()
    st = CTX['api']('/api/arche') or {}
    ch = next((c for c in st.get('chapters') or [] if c.get('open')), None) if st.get('active') else None
    if not ch: return st
    S = jload('아르케_자동.json', {})
    d = jload('아르케_원래바탕화면.json', None)
    if d and (ch.get('ritual') or time.time() - d.get('at', 0) > DESK_UNDO) and not S.get('fighting'): desk_restore('의식 됨' if ch.get('ritual') else '30분 지남')
    if ch.get('ritual'): return st
    R = recipes().get(str(ch['n']))
    if not R or datetime.datetime.now(KST).hour < int(R.get('from_hour') or 0): return st
    if time.time() - (S.get('try_at') or {}).get(str(ch['n']), 0) < RETRY: return st
    S.setdefault('try_at', {})[str(ch['n'])] = time.time(); jsave('아르케_자동.json', S)
    log(f"{ch['n']}장 '{ch.get('title')}' 받은 풀이로 해 봄")
    run(R, ch)
    st = CTX['api']('/api/arche') or st
    ch = next((c for c in st.get('chapters') or [] if c.get('n') == ch['n']), ch)
    log(f"{ch['n']}장 의식 {'됨 — 전설 배틀로' if ch.get('ritual') else '아직 (30분 뒤 다시)'}")
    return st
