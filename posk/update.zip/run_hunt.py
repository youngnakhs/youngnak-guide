# -*- coding: utf-8 -*-
"""사냥기 고리 (맥) - 윈도우 exe 의 '--hunt' 와 같은 일: posk_hunt 를 돌리고, 꺼지면 5초 뒤 다시 켠다.
원본 launcher 를 그대로 옮기고 HERE 만 이 파일 폴더로 바꿨다.

2026-10-10: 같은 프로세스 안에서 runpy 로 다시 돌리면 앞 실행의 파일 잠금(.사냥기.lock)이 안 풀려
새 실행이 '이미 다른 사냥기가 실행 중'으로 영영 기다렸다(02:29~03:25 멈춤). 매번 새 프로세스로 띄운다.
이 고리가 꺼지면(pkill·조종판) 돌던 사냥기도 같이 끈다."""
import os, signal, subprocess, sys, time
FROZEN = getattr(sys, 'frozen', False)
HERE = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.abspath(__file__))
MAC = sys.platform == 'darwin'
LOG = os.path.join(HERE, '사냥기록.txt')
child = None

def stop(*_):
    if child and child.poll() is None:
        child.terminate()
        try: child.wait(5)
        except Exception: child.kill()
    sys.exit(0)

# 맥이 1분 만에 잠들어 게임·사냥기·네트워크가 같이 멈췄다(10/10 새벽 '동기화 실패'·기록 공백은 모두 잠에서 깬 순간).
# 이 고리가 도는 동안만 시스템 잠자기를 막는다(화면은 꺼져도 됨). -w: 이 고리가 끝나면 caffeinate 도 끝난다
# -i 만으로는 이미 잠든 뒤 잠깐 깬 상태(DarkWake)에서 다시 잠드는 걸 못 막았다(10/10 05:39·06:40) → -u 로 완전히 깨우고
# -s(충전 중 시스템 잠자기 자체를 막음)까지 건다. 화면은 설정대로 꺼진다
if MAC: subprocess.call(['caffeinate', '-u', '-t', '3'])
# -d: 화면도 안 꺼지게. 화면이 꺼지면 잠김(암호)으로 넘어가 진짜 클릭이 게임에 안 닿았다(10/11 01:20부터 풀숲 무반응·게임 재시작 반복)
if MAC: subprocess.Popen(['caffeinate', '-d', '-i', '-s', '-w', str(os.getpid())], start_new_session=True)
else: import ctypes; ctypes.windll.kernel32.SetThreadExecutionState(0x80000003)   # 윈도우: 잠자기·화면 끄기 막기 (사냥기도 따로 건다)
signal.signal(signal.SIGTERM, stop)
signal.signal(signal.SIGINT, stop)
while True:
    # 기록이 30MB 넘으면 날짜를 붙여 나눈다
    try:
        if os.path.getsize(LOG) > 30 * 1024 * 1024: os.replace(LOG, LOG.replace('.txt', time.strftime('_%Y%m%d_%H%M.txt')))
    except OSError: pass
    # 자동 업데이트(10/13): 드라이브에 새 판이 있으면 받고 켠다 (사냥기는 새 판을 보면 스스로 끝나 여기로 돌아온다)
    try:
        import updater; v = updater.apply()
        t = updater.game_code()   # 공유받은 윈도우 PC: 게임 규칙 코드를 게임 공식 저장소에서 받음
        if t:
            with open(LOG, 'a', encoding='utf-8') as f: f.write(time.strftime('%H:%M:%S') + f' 게임 규칙 코드 {t} 받음 (GitHub)'+chr(10))
        if v:
            with open(LOG, 'a', encoding='utf-8') as f: f.write(time.strftime('%H:%M:%S') + f' 새 판 {v} 받음\n')
    except Exception: pass
    # 윈도우 exe: 자기 자신을 --hunt-child 로 (같은 프로세스 runpy 재실행 금지 - 잠금이 안 풀림)
    cmd = [sys.executable, '--hunt-child'] if FROZEN else [sys.executable, os.path.join(HERE, 'posk_hunt.py')]
    child = subprocess.Popen(cmd, cwd=HERE, **({} if MAC else {'creationflags': 0x08000000}))
    # 사냥기가 살아 있는데 기록이 20분 넘게 안 늘면(멈춤·무한 대기) 다시 켠다. 잠깐 멈춤 중은 제외 (2026-10-10)
    while child.poll() is None:
        time.sleep(30)
        try: stale = time.time() - os.path.getmtime(LOG)
        except OSError: stale = 0
        if stale > 1200 and not os.path.exists(os.path.join(HERE, '잠깐멈춤.flag')):
            with open(LOG, 'a', encoding='utf-8') as f: f.write(time.strftime('%H:%M:%S') + f' 이상 감지[사냥기 멈춤]: 기록이 {int(stale // 60)}분째 그대로 → 사냥기 다시 켬\n')
            child.terminate()
            try: child.wait(10)
            except Exception: child.kill()
    code = child.returncode
    with open(LOG, 'a', encoding='utf-8') as f:
        if code not in (0, None, -15, -9):   # -15·-9 = 일부러 끈 것(조종판·재시작) - 오류 아님
            f.write(time.strftime('%H:%M:%S') + f' 사냥기 오류로 멈춤 (종료 코드 {code}) \n')
        f.write(time.strftime('%Y-%m-%d %H:%M:%S') + ' 사냥기 꺼짐 - 5초 뒤 다시 켬\n')
    time.sleep(5)
