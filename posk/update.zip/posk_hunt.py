# -*- coding: utf-8 -*-
# posk_hunt.py - 포스크탑 자동사냥 (윈도우 exe 바이트코드에서 복원 → 맥 겸용, 2026-10-09)
#
#
#
import ctypes, json, os, random, sys, time, traceback
MAC = sys.platform == 'darwin'
if MAC: sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), 'macshim'))  # 맥: win32gui·win32process 대역
import win32gui, win32process, psutil, pyautogui, requests
# 서버 연결을 다시 쓴다 (10/12): 요청마다 HTTPS 연결을 새로 맺어 요청 하나가 약 1초(그중 0.97초가 연결) — 판 사이 육성 점검 23번 요청에 24초,
# 관장 매 턴도 같은 값을 냈다. 세션 하나로 묶으면 연결을 한 번만 맺는다 (사냥기는 스레드 하나라 공유해도 안전)
_http = requests.Session()
# 이름 찾기(DNS) 대비 (2026-10-10): 통신사 DNS가 새벽에 posktop.duckdns.org 를 자주 못 찾아(NameResolutionError 07시 30번)
# 서버는 멀쩡한데 사냥기 요청이 다 실패했다. 마지막으로 찾은 주소를 기억해 두고, 못 찾으면 그 주소를 쓴다
import socket as _socket
_gai, _gai_ok = _socket.getaddrinfo, {}
def _getaddrinfo(host, *a, **k):
    try:
        r = _gai(host, *a, **k); _gai_ok[(host,) + a] = r; return r
    except _socket.gaierror:
        if (host,) + a in _gai_ok: return _gai_ok[(host,) + a]
        raise
_socket.getaddrinfo = _getaddrinfo

# 그래도 이름 찾기가 계속 실패하면(1분 안에 3번) 와이파이를 껐다 켠다 - 맥 DNS 설정은 안 바꾼다(사용자 결정 10/10).
# 게임도 같은 DNS 문제로 '동기화 실패'가 나므로, 연결을 새로 맺어 둘 다 살린다. 10분에 한 번까지
_dns_fail, _wifi_at = [], 0
def dns_trouble():
    global _wifi_at
    now = time.time(); _dns_fail[:] = [t for t in _dns_fail if now - t < 60] + [now]
    if len(_dns_fail) < 3 or now - _wifi_at < 600: return
    _wifi_at = now; _dns_fail.clear()
    import subprocess
    if sys.platform != 'darwin':   # 윈도우: DNS 캐시 비우고 와이파이 다시 연결 (관리자 권한 불필요, DNS 설정은 안 바꿈)
        say('서버 이름을 계속 못 찾음 → DNS 캐시 비우고 와이파이 다시 연결')
        nw = 0x08000000
        subprocess.run(['ipconfig', '/flushdns'], capture_output=True, timeout=15, creationflags=nw)
        out = subprocess.run(['netsh', 'wlan', 'show', 'interfaces'], capture_output=True, timeout=15, creationflags=nw).stdout.decode('cp949', 'ignore')
        prof = next((l.split(':', 1)[1].strip() for l in out.splitlines() if l.strip().startswith(('Profile', '프로필'))), None)
        if prof:
            subprocess.run(['netsh', 'wlan', 'disconnect'], capture_output=True, timeout=15, creationflags=nw); time.sleep(3)
            subprocess.run(['netsh', 'wlan', 'connect', 'name=' + prof], capture_output=True, timeout=15, creationflags=nw); time.sleep(15)
        return
    dev = 'en0'
    try:
        out = subprocess.run(['networksetup', '-listallhardwareports'], capture_output=True, text=True, timeout=10).stdout.split('\n')
        dev = next(out[i + 1].split(': ')[1] for i, l in enumerate(out) if l.strip() == 'Hardware Port: Wi-Fi')
    except Exception: pass
    say(f'서버 이름을 계속 못 찾음 → 와이파이({dev}) 껐다 켬')
    subprocess.run(['networksetup', '-setairportpower', dev, 'off'], timeout=15); time.sleep(3)
    subprocess.run(['networksetup', '-setairportpower', dev, 'on'], timeout=15); time.sleep(15)
from PIL import Image

HERE = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))
LITE = False
GDIR = os.path.expanduser('~/Library/Application Support/poketdesktop') if MAC else os.path.join(os.environ['APPDATA'], 'poketdesktop')
LOG = os.path.join(GDIR, 'poketdesktop.log')
CONF = os.path.join(HERE, '조종판설정.json')
PAUSE = os.path.join(HERE, '잠깐멈춤.flag')
_status = {}
def status(**kv):
    _status.update(kv); _status['시각'] = time.time()
    try: json.dump(_status, open(os.path.join(HERE, '사냥기상태.json'), 'w', encoding='utf-8'), ensure_ascii=False)
    except OSError: pass
def gym_idle():
    try: return max(0, int(json.load(open(CONF, encoding='utf-8')).get('관장_대기초', 60)))
    except Exception: return 60

S = 1.0 if MAC else ctypes.windll.user32.GetDpiForSystem() / 96   # 맥은 Tk·pyautogui 모두 포인트 단위
def z(n): return int(round(n * S))
SMALL = (z(40), z(120))
def win_size_range():
    # 윈도우: 게임 코드(wild_ui.GrassPatch) 풀숲 창 = max(28, targetHeight) 높이 x 1.15 폭(기본 55x48), 야생 창 ≈ 4/3배(64x64).
    # 크기 설정을 바꿔도 찾게 targetHeight 비례로 잡고, 가로세로 비(0.75~1.45)로 세로로 긴 동행 포켓몬 창(55x88~91x201)을 거른다 (10/12)
    try: th = float(json.load(open(os.path.join(GDIR, 'settings.json'), encoding='utf-8')).get('targetHeight') or 48)
    except Exception: th = 48
    k = max(28, th) / 48
    return z(30 * k), z(110 * k)
def size_range():
    # 게임 설정 targetHeight(포켓몬 높이, 기본 48)에 맞춰 풀숲·야생 창 크기 범위를 잡는다 (10/10: 크기를 바꿔도 찾게)
    try: th = float(json.load(open(os.path.join(GDIR, 'settings.json'), encoding='utf-8')).get('targetHeight') or 48)
    except Exception: th = 48
    k = th / 48
    return (max(10, int(z(40) * min(k, 1) * 0.6)), int(z(120) * max(k, 1) * 1.6) + 20)

_print = print
def print(*a, **k):
    if sys.stdout: _print(*a, **k)
    try:
        with open(os.path.join(HERE, '사냥기록.txt'), 'a', encoding='utf-8') as f:
            f.write(' '.join(map(str, a)) + '\n')
    except OSError: pass

def say(*a): print(time.strftime('%H:%M:%S'), *a, flush=True)


if MAC:   # 맥: 뮤텍스 대신 파일 잠금 (프로세스가 죽으면 자동으로 풀린다)
    import fcntl
    _mutex = open(os.path.join(HERE, '.사냥기.lock'), 'w')
    try: fcntl.flock(_mutex, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        say('이미 다른 사냥기가 실행 중 - 그게 꺼질 때까지 대기')
        fcntl.flock(_mutex, fcntl.LOCK_EX)
else:
    _k32 = ctypes.WinDLL('kernel32', use_last_error=True)
    # 잠자기·화면 끄기 막기 (맥 caffeinate -d -i -s 와 같음): 화면이 꺼지면 잠김으로 넘어가 진짜 클릭이 안 닿는다. 사냥기가 꺼지면 풀린다
    _k32.SetThreadExecutionState(0x80000003)
    _mutex = _k32.CreateMutexW(None, True, 'Local\\포스크탑자동사냥')
    if ctypes.get_last_error() == 183:
        say('이미 다른 사냥기가 실행 중 - 그게 꺼질 때까지 대기')
        while _k32.WaitForSingleObject(_mutex, 30000) not in (0, 128): pass
#
#
global human_at, my_tick
_u = None if MAC else ctypes.windll.user32
def _tick():   # GetTickCount 대신 (밀리초)
    return int(time.monotonic() * 1000) if MAC else ctypes.windll.kernel32.GetTickCount()
human_at = time.time()
my_tick = 0
class _LII(ctypes.Structure): _fields_ = [('cbSize', ctypes.c_uint), ('dwTime', ctypes.c_uint)]
def _mark(f):
    def g(*a, **k):
        global my_tick
        try: return f(*a, **k)
        finally: my_tick = _tick()
    return g
for _n in ('click', 'doubleClick', 'moveTo', 'press'): setattr(pyautogui, _n, _mark(getattr(pyautogui, _n)))
def idle_s():
    global human_at
    if MAC:   # 맥: 마지막 하드웨어 입력 뒤 지난 초
        import Quartz
        ago = Quartz.CGEventSourceSecondsSinceLastEventType(Quartz.kCGEventSourceStateHIDSystemState, Quartz.kCGAnyInputEventType)
        li = _LII(0, max(0, _tick() - int(ago * 1000)))
    else:
        li = _LII(ctypes.sizeof(_LII), 0); _u.GetLastInputInfo(ctypes.byref(li))
    if li.dwTime > my_tick + 1000:
        human_at = max(human_at, time.time() - (_tick() - li.dwTime) / 1000)
    return time.time() - human_at


def rect(h):
    try: return win32gui.GetWindowRect(h)
    except Exception: return None

def alive(h):
    try: return bool(h) and win32gui.IsWindow(h) and win32gui.IsWindowVisible(h)
    except Exception: return False

def wins(pid):
    o = []
    def f(h, _):
        try:
            if win32gui.IsWindowVisible(h) and win32process.GetWindowThreadProcessId(h)[1] == pid:
                o.append((h, win32gui.GetWindowText(h), win32gui.GetWindowRect(h)))
        except Exception: pass
    try: win32gui.EnumWindows(f, None)
    except Exception: pass
    return o

def children(top):
    o = []
    def f(c, _):
        try:
            if win32gui.IsWindowVisible(c): o.append((c, win32gui.GetWindowRect(c)))
        except Exception: pass
    try: win32gui.EnumChildWindows(top, f, None)
    except Exception: pass
    return o

def kids(top, w, h, dw=3, dh=3):
    if MAC: return win32gui.kids_role(top, w, h)   # 맥: 크기 대신 글자·구조로 같은 단추를 찾는다
    w, h, dw, dh = z(w), z(h), max(dw, z(dw)), max(dh, z(dh))
    return [c for (t, l), c in sorted(((r[1], r[0]), c) for c, r in children(top) if abs(r[2] - r[0] - w) <= dw and abs(r[3] - r[1] - h) <= dh)]

def _hit(h):
    r = rect(h)
    if not r: return
    l, t, rr, b = r
    for p in [((l + rr) // 2, (t + b) // 2)] + [(l + (rr - l) * i // 6, t + (b - t) * j // 6) for j in (3, 2, 4, 1, 5) for i in (3, 2, 4, 1, 5)]:
        try:
            if win32gui.GetAncestor(win32gui.WindowFromPoint(p), 2) == h: return p
        except Exception: return

def hit_point(h):
    p = _hit(h)
    if p or not alive(h): return p
    try: win32gui.SetWindowPos(h, -1, 0, 0, 0, 0, 19)
    except Exception: return None
    # 맥: '맨 앞으로'는 탐지기가 0.4초마다 처리하고 관장전 중엔 더 밀린다 → 0.2초 한 번으론 관장 창에 가려진 채
    # '메뉴 없음'이 됐다 (10/9 21:52, 10/10 00:52 둘 다 관장전 중). 볼 기회는 10초라 2.5초까지 기다린다
    for _ in range(12 if MAC else 1):
        time.sleep(0.2)
        p = _hit(h)
        if p or not alive(h): return p
    return None

def blocker(h):
    try:
        l, t, r, b = rect(h)
        w = win32gui.GetAncestor(win32gui.WindowFromPoint(((l + r) // 2, (t + b) // 2)), 2)
        return f"가림: {psutil.Process(win32process.GetWindowThreadProcessId(w)[1]).name()} '{win32gui.GetWindowText(w)}'"
    except Exception: return '가림: ?'

def front(top):
    try: pyautogui.press('alt'); win32gui.SetForegroundWindow(top)
    except Exception: pass
    if win32gui.GetForegroundWindow() != top:
        try: win32gui.BringWindowToTop(top); win32gui.SetForegroundWindow(top)
        except Exception: pass

def real_click(x, y, button='left'):
    cur = pyautogui.position()
    pyautogui.click(x, y, button=button)
    pyautogui.moveTo(*cur)

def game_pid():
    if MAC:   # 맥: 탐지기를 붙여 켠 게임(game_probe.py)만 조작할 수 있다
        d = win32gui.probe_info()
        if d: return d['pid']
        if any('run.pyw' in c or '포스크탑.app/Contents/MacOS' in c for c in (' '.join(p.info['cmdline'] or []) for p in psutil.process_iter(['cmdline']))):   # 설치된 앱(dmg)도 탐지기 없음
            global _warned
            if not globals().get('_warned'): _warned = True; say('게임이 탐지기 없이 켜져 있음 - 조종판의 [게임 다시 켜기]로 켜 주세요')
        return None
    # 10/19: 창이 하나도 없는 poketdesktop 프로세스(업데이트 중 멈춘 옛 판 등)는 켜진 게임이 아니다 - 10/18 15:48 게임 업데이트 뒤
    # 16시간 게임이 없는데도 '켜짐'으로 봐서 다시 켜지 않았다. 창이 없으면 None → 2분 뒤 watchdog 이 다시 켬
    for p in psutil.process_iter(['name']):
        if (p.info['name'] or '').startswith('poketdesktop') and wins(p.pid):
            return p.pid

global log_pos
log_pos = os.path.getsize(LOG) if os.path.exists(LOG) else 0
def new_log():
    global log_pos
    if not os.path.exists(LOG): return ''
    size = os.path.getsize(LOG)
    if size < log_pos: log_pos = 0
    with open(LOG, 'rb') as f:
        f.seek(log_pos); new = f.read().decode('utf-8', 'ignore'); log_pos = size
    return new

def log_since(t0):
    try:
        with open(LOG, 'rb') as f:
            f.seek(max(0, os.path.getsize(LOG) - 4000)); tail = f.read().decode('utf-8', 'ignore')
    except OSError: return ''
    since = time.strftime('[%Y-%m-%d %H:%M:%S]', time.localtime(t0))
    return ' / '.join(x for x in tail.splitlines() if x[:1] == '[' and x[:21] >= since)


companions = set()
clicked = set()
seen_at = {}
def grass_since():
    # 풀숲이 지금 흔들리는 중이면 흔들리기 시작한 시각(초), 아니면 0
    tail = log_since(time.time() - 600)
    i = tail.rfind('흔들리고')
    if i < 0 or i < max(tail.rfind('잠잠'), tail.rfind('나타났다')): return 0
    j = tail.rfind('[', 0, i)
    try: return time.mktime(time.strptime(tail[j + 1:j + 20], '%Y-%m-%d %H:%M:%S'))
    except ValueError: return time.time()
grass_on = lambda: bool(grass_since())

def targets(pid):
    if MAC:   # 맥: 위에 붙은 글자로 가른다 - 야생('야생 …' 표식) 먼저, 풀숲(위에 아무것도 없음)은 풀숲이 흔들릴 때만
        # 야생은 표식이 확실하니 크기를 넓게(실측 38px 짜리도 있었음), 풀숲은 흔들리기 시작한 뒤 새로 생긴 창만
        lo, hi = size_range()
        ws = win32gui.small_wins(min(z(16), lo), max(z(200), hi))
        for h, _, _ in ws: seen_at.setdefault(h, time.time())
        wild_ = [h for h, _, txt in ws if txt and txt.lstrip('★ ').startswith('야생')]
        since = grass_since()
        grass = [h for h, (l, t, r, b), txt in ws if txt is None and since and seen_at[h] >= since - 3
                 and lo <= r - l <= hi and lo <= b - t <= hi]
        for h, _, txt in ws:
            if txt and h not in wild_: companions.add(h)
        return grass + wild_   # wild_clicks 는 끝의 것을 야생으로 본다(ts[-1])
    ws = [(h, r) for h, _, r in wins(pid)]
    labels = win32gui.plate_rects() if MAC else [r for _, r in ws if abs(r[3] - r[1] - z(25)) <= 2]   # 맥 이름표는 29px
    lo, hi = win_size_range()
    out = []
    for h, (l, t, r, b) in ws:
        #
        first = seen_at.setdefault(h, time.time())
        if h not in clicked and not (battle and first >= battle - 5) and any(0 <= t - lb <= 6 and abs(ll - l) <= 40 for ll, _, _, lb in labels):
            companions.add(h)
        # 10/12: 바이트코드 복원 때 'elif h not in companions' 가 'if h in companions' 로 뒤집혀 화면 포획이 풀숲을 하나도 못 골랐다
        elif h not in companions and lo <= r - l <= hi and lo <= b - t <= hi and 0.75 <= (r - l) / max(1, b - t) <= 1.45:
            out.append(h)
    return out
global last_click
last_click = 0
def click(h, since):
    global last_click
    #
    if any(w in log_since(since - 1) for w in ('튀어나왔다', '볼을', '배틀 종료', '도망')): return '안 누름(이미 전투)'
    if not alive(h): return '사라짐'
    p = hit_point(h)
    if not p: return '실클릭 못함 ' + blocker(h)
    last_click = time.time(); clicked.add(h); companions.discard(h)
    real_click(*p)
    return '실클릭'


BALL_IMGS = [(n, Image.open(os.path.join(HERE, f)).convert('RGB')) for n, f in (('추천 볼', '추천_견본.png'), ('몬스터볼', '몬스터볼_견본.png'), ('몬스터볼', '몬스터볼_견본_앞.png'), ('몬스터볼', '몬스터볼_견본_뒤.png'))]
#
#
if S != 1:
    BALL_IMGS = [(n, im.resize((z(im.width), z(im.height)), Image.LANCZOS)) for n, im in BALL_IMGS]

def window_shot(h):
    if MAC: return win32gui.window_image(h)
    import win32ui
    l, t, r, b = win32gui.GetWindowRect(h)
    hdc = win32gui.GetWindowDC(h); dc = win32ui.CreateDCFromHandle(hdc); mem = dc.CreateCompatibleDC()
    bmp = win32ui.CreateBitmap(); bmp.CreateCompatibleBitmap(dc, r - l, b - t); mem.SelectObject(bmp)
    try:
        ctypes.windll.user32.PrintWindow(h, mem.GetSafeHdc(), 0); i = bmp.GetInfo()
        return Image.frombuffer('RGB', (i['bmWidth'], i['bmHeight']), bmp.GetBitmapBits(True), 'raw', 'BGRX', 0, 1).copy()
    finally:
        win32gui.DeleteObject(bmp.GetHandle()); mem.DeleteDC(); dc.DeleteDC(); win32gui.ReleaseDC(h, hdc)

def game_menu(pid):
    for h, _, _ in wins(pid):
        try:
            if win32gui.GetClassName(h) == '#32768': return h
        except Exception: pass

def normal_balls():
    try:
        b = api('/api/bag')
        return sum(v for k, v in (b.get('bag') or {}).items() if k.endswith('BALL') and k != 'MASTERBALL')
    except Exception: return 0

def throw_at(pid, h):
    p = hit_point(h)
    if not p: return '클릭 자리 없음 ' + blocker(h)   # 메뉴 탓이 아니라 창이 가려진 것 - 구분해서 남긴다
    cur = pyautogui.position()
    pyautogui.click(*p, button='right')
    if MAC:   # 맥: 볼 메뉴가 Tk 창이라 '#32768'·견본 그림 대신 줄 글자로 고른다 (마스터볼은 안 누름)
        try:
            rows = []
            for _ in range(25):   # 최대 5초 - 관장전 중엔 탐지기 갱신(0.4초마다)이 밀려 2초로는 모자랄 때가 있었다 (2026-10-09)
                time.sleep(0.2); rows = win32gui.ball_menu()
                if rows: break
            if not rows:   # 원인을 알 수 있게 증거를 남긴다: 탐지기 갱신이 멈췄나, 메뉴가 정말 안 떴나
                age = time.time() - (win32gui.snap().get('t') or 0)
                try: pyautogui.screenshot().save(os.path.join(HERE, time.strftime('메뉴없음_%m%d_%H%M%S.png')))
                except Exception: pass
                return f'메뉴 없음(탐지기 {age:.1f}초 전 갱신, 클릭 {p})'
            # 추천(서버가 고른 제일 잘 듣는 볼) > 슈퍼볼 > 몬스터볼 > 나머지. 드림볼 같은 희귀 볼이 맨 윗줄이라고 먼저 나가지 않게
            pick = ([x for x in rows if x[0].startswith('추천')] or [x for x in rows if x[0].startswith('슈퍼볼')]
                    or [x for x in rows if x[0].startswith('몬스터볼')] or [x for x in rows if not x[0].startswith('마스터볼')])
            if not pick:
                pyautogui.press('esc'); return '못 찾음(안 던짐)'
            text, (l, t, r, b) = pick[0]
            pyautogui.click((l + r) // 2, (t + b) // 2)
            return ' '.join(text.split('개')[0].split()[:-1]) + ' 던짐'   # '추천 몬스터볼 던짐'
        finally:
            pyautogui.moveTo(*cur)
    try:
        m = None
        for _ in range(8):
            time.sleep(0.2); m = game_menu(pid)
            if m: break
        if not m: return '메뉴 없음'
        r = rect(m)
        if r: pyautogui.moveTo(r[0] - z(6), r[1] - z(6))
        time.sleep(0.15)
        hit = None
        for _ in range(5):
            if not alive(m): return '메뉴 사라짐'
            shot = window_shot(m)
            for name, img in BALL_IMGS:
                try: hit = pyautogui.locate(img, shot, confidence=0.9)
                except Exception: hit = None
                if hit: break
            if hit: break
            time.sleep(0.3)
        r = rect(m)
        if hit and r:
            pyautogui.click(int(r[0] + hit.left + hit.width // 2), int(r[1] + hit.top + hit.height // 2))
            return f'{name} 던짐'
        try: shot.save(os.path.join(HERE, time.strftime('못찾음_%H%M%S.png')))
        except Exception: pass


        if alive(m) and normal_balls() > 0:
            pyautogui.press('down'); time.sleep(0.15); pyautogui.press('enter')
            return '첫 줄 볼 던짐(키보드)'
        pyautogui.press('esc')
        return '못 찾음(안 던짐)'
    finally:
        pyautogui.moveTo(*cur)

CAUGHT, BROKE = ('을 잡았다', '를 잡았다'), ('나와버렸다', '튀어나와버렸', '아깝', '조금만')   # 'X을/를 잡았다'만 — '아깝다! 다 잡았다고…'는 빠짐
def catch_tries():
    try: return max(1, min(10, int(json.load(open(CONF, encoding='utf-8')).get('포획_시도횟수', 1))))
    except Exception: return 1

def throw_ball(pid, wild, prompt_at):
    tries, out = catch_tries(), []
    for n in range(tries):
        t0 = time.time()
        r = throw_once(pid, wild, prompt_at, ENDED if n == 0 else ENDED[:5])
        out.append(r)
        if '던짐' not in r: break
        res = ''
        time.sleep(1.2)
        for _ in range(20):
            time.sleep(0.3); res = log_since(t0 + 1)
            if any(w in res for w in CAUGHT + BROKE + ('쓰러뜨렸다', '배틀 종료', '도망')): break
        if any(w in res for w in CAUGHT) and not any(w in res for w in BROKE): out.append('잡음'); break   # '아깝다! 다 잡았다고 생각했는데!' 는 빠짐
        if not any(w in res for w in BROKE) or any(w in res for w in ('쓰러뜨렸다', '배틀 종료', '도망')): break
        out.append('빠짐')
        time.sleep(1.1)
    return ' → '.join(out) + (f' (최대 {tries}번)' if tries > 1 else '')

ENDED = ('쓰러뜨렸다', '을 잡았다', '배틀 종료', '도망', '를 잡았다', '나와버렸다', '아깝', '조금만')   # 앞 5개 = 판이 끝난 말
def throw_once(pid, wild, prompt_at, ended=ENDED):
    for attempt in range(2):
        if any(w in log_since(prompt_at) for w in ended):
            return '이미 끝남'
        ws = []
        for _ in range(6):
            ws = ([wild] if alive(wild) else []) + [h for h in targets(pid) if h != wild]
            if ws or any(w in log_since(prompt_at) for w in ended): break
            time.sleep(0.5)
        for h in ws[:3]:
            r = throw_at(pid, h)
            if '던짐' in r: return r
        if attempt == 0: time.sleep(0.8)
    return r if ws else '대상 창 없음'


def pillar(pid):
    for h, title, (l, t, r, b) in wins(pid):
        if title == 'tk' and h not in companions and z(110) <= r - l <= z(400) and z(90) <= b - t <= z(300) and r - l >= b - t:
            return h

def raid_open(pid): return any(title.startswith('레이드') for _, title, _ in wins(pid))


while not (os.path.exists(os.path.join(GDIR, 'pokedex.json')) and os.path.exists(os.path.join(GDIR, 'session.json'))):
    say('게임 로그인 대기 - 포스크탑에 로그인하면 자동으로 시작합니다'); time.sleep(30)   # 맥 첫 실행: 로그인 전엔 도감·세션이 없다
_DEX = json.load(open(os.path.join(GDIR, 'pokedex.json'), encoding='utf-8'))
TYPES = _DEX['types']
MOVES = _DEX['moves']
SPECIES = {sp['internal']: sp for sp in _DEX['species']}
MEGA_OF = {}   # 종 → 메가 폼들 (유대 미션으로 메가스톤을 받으면 배틀에서 메가진화)
for _m in _DEX.get('megas') or []: MEGA_OF.setdefault(_m.get('megaOf'), []).append(_m)
MEGA_SP = {_m['internal']: _m for _m in _DEX.get('megas') or []}   # 메가 폼 종족값 (foe_stat)
gym_done = None, 0
gym_mega = set()
gym_refused = {}
gym_swapped = set()
gym_team_max = 0
gym_target = None
class _Skip(dict):
    # 건너뛸 관장 — 30분 지나면 풀림. 예전엔 사냥기가 꺼질 때까지 남아, 컴퓨터 사용 중 시작 확인이 한 번 빗나간
    # Lv85 로즈가 22:04부터 빠져 Lv80 관장만 돌았다(10/10 22~23시)
    def add(self, k): self[k] = time.time()
    def discard(self, k): self.pop(k, None)
    def __contains__(self, k):
        t = self.get(k)
        if t is None: return False
        if time.time() - t > 1800: self.pop(k, None); return False
        return True
gym_skip = _Skip()
gym_paused = False
gym_active = False
gym_retry = 0, 0
CHAIN = os.path.join(HERE, '관장_이어도전중.flag')
gym_try_at = 0
gym_seen = 0

def api(path, method='GET'):
    tok = json.load(open(os.path.join(GDIR, 'session.json'), encoding='utf-8'))['token']
    base = json.load(open(os.path.join(GDIR, 'settings.json'), encoding='utf-8'))['server']
    return _http.request(method, base + path, headers={'Authorization': 'Bearer ' + tok, 'Accept': 'application/json'}, timeout=15).json()

def eff(atk, defs):
    m = 1.0
    for d in defs: m *= TYPES.get(atk, {}).get('eff', {}).get(d, 1.0)
    return m

def foe_stat(foe, key):
    sp = SPECIES.get(foe.get('species') or '') or MEGA_SP.get(foe.get('species') or '')
    if not sp: return 100
    return int((2 * sp['base'][key] + 31) * foe.get('level', 50) / 100) + 5

def damage(mon, mv, foe):
    if mv['cat'] == 'status' or not mv['power']: return 0
    a = mon['stats']['atk' if mv['cat'] == 'physical' else 'spa']
    d = foe_stat(foe, 'def' if mv['cat'] == 'physical' else 'spd')
    lo, hi = (MOVES.get(mv['key']) or {}).get('hits', [1, 1])
    hits = 3.1 if (lo, hi) == (2, 5) else (lo + hi) / 2
    return ((2 * mon['level'] / 5 + 2) * mv['power'] * a / max(d, 1) / 50 + 2) * (1.5 if mv['type'] in mon['typeIds'] else 1) * eff(mv['type'], foe['typeIds']) * 0.925 * hits

def best_move(mon, foe, skip=()):
    best = (-1, 0)
    for i, mv in enumerate(mon['moves']):
        if i in skip or mv.get('blocked') or mv['pp'] <= 0: continue
        if mon.get('locked') and mv['key'] != mon['locked']: continue
        info = MOVES.get(mv['key']) or {}
        dmg, acc = damage(mon, mv, foe), (mv['acc'] or 100) / 100
        selfko = mv['key'] in ('SELFDESTRUCT', 'EXPLOSION', 'MISTYEXPLOSION', 'FINALGAMBIT')
        if dmg and dmg >= foe.get('hp', 1e9) and not selfko and 'charge' not in info.get('flags', []):
            sc = 1e6 + acc * 1000 + dmg / 1e4
        else:
            sc = dmg * acc
            if 'recharge' in info.get('flags', []): sc *= 0.6
            if 'charge' in info.get('flags', []): sc *= 0.5
            if mv['key'] in ('FUTURESIGHT', 'DOOMDESIRE'): sc *= 0.5
            if mv['key'] in ('OUTRAGE', 'PETALDANCE', 'THRASH'): sc *= 0.85
            if selfko: sc *= 0.25
            if info.get('drain', 0) < 0: sc *= 1 + info['drain'] / 200
        if sc > best[0]: best = (sc, i)
    return best

def threat(foe, mon):
    return max(eff(t, mon['typeIds']) for t in foe['typeIds'])

def grow_first(bench, team, foe, growing):
    # 쓰러져서 다음 포켓몬을 낼 때: 때릴 수 있고(×1 이상) 약점 ×2 미만인 육성 포켓몬을 먼저(레벨 높은 순), 없으면 점수 1등.
    # 점수×3 으로는 Lv100 메가 주력을 못 이겨, 저레벨 육성 선두가 한 방에 쓰러지면 주력이 나와 나머지를 다 쓰러뜨렸다
    # (10/11 05:43~06:42 서버 관장 KO 360 중 육성 128 = 36%, 화면 관장 때는 82%)
    ok = []
    for _, i in bench:
        m = team[i]
        if not growing(m) or threat(foe, m) >= 2: continue
        sc, mi = best_move(m, foe)
        if sc > 0 and eff(m['moves'][mi]['type'], foe['typeIds']) >= 1: ok.append((m.get('level', 0), i))
    return max(ok)[1] if ok else bench[0][1]

def value(mon, foe):
    return max(best_move(mon, foe)[0], 1) / max(threat(foe, mon), 0.25) * mon['hp'] / max(mon['maxhp'], 1)

def gym_window(pid):
    return next((h for h, title, _ in wins(pid) if title.startswith('관장 도전')), None)

def main_window(pid):
    return next((h for h, title, _ in wins(pid) if title == '포스크탑'), None)

def press(top, c):
    r = rect(c)
    return bool(r) and press_at(top, (r[0] + r[2]) // 2, (r[1] + r[3]) // 2)

def press_at(top, x, y):
    def mine():
        try: return win32gui.GetAncestor(win32gui.WindowFromPoint((x, y)), 2) == top
        except Exception: return False
    if MAC and not mine():
        # 맥: 동행 도트·이름표는 늘 맨 위라 단추 위에 멈춰 서 있으면 진짜 클릭은 도트로 간다
        # (14:13~14:35 '도전하기' 위에 선 보스로라 → 매번 안 눌림). 게임 자기 창이 가리면 탐지기가 직접 누른다.
        if win32gui.owned_by_game(win32gui.GetAncestor(win32gui.WindowFromPoint((x, y)), 2)):
            return win32gui.click_in(top, x, y)
    if not mine():
        front(top); time.sleep(0.3)
        if not mine(): return False
    if MAC and not win32gui.GetForegroundWindow():   # 맥: 다른 앱이 앞이면 첫 클릭은 '앱 깨우기'로 먹혀 단추가 안 눌린다
        win32gui._activate(); time.sleep(0.3)
    real_click(x, y)
    return True

def island_code():
    try:
        gp = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop/client') if MAC else os.path.join(HERE, '_game_pyc')
        if gp not in sys.path: sys.path.insert(0, gp)
        from poketdesktop import ui_gym as g
        return g
    except Exception: return None

def region_point(sido, code, cv, alts=False):
    m = json.load(open(next(os.path.join(GDIR, f) for f in os.listdir(GDIR) if f.startswith('gym_map_')), encoding='utf-8'))
    regs = [d for d in m['sgg'] if d['sido'] == sido]
    g = island_code()
    shifts, boxes, hidden = g.island_layout(regs) if g else ({}, None, set())
    sh = lambda d, i: shifts.get((d['code'], i), (0, 0))
    rings = {d['code']: [[(p[0] + sh(d, i)[0], p[1] + sh(d, i)[1]) for p in r] for i, r in enumerate(d['rings']) if (d['code'], i) not in hidden] for d in regs}
    pts = [p for v in rings.values() for r in v for p in r]
    l, t, r, b = rect(cv); cw, ch = r - l, b - t
    pad = g.U.h(g.PAD) if g and MAC else z(18)   # 맥 게임은 글자 12pt 라 여백도 22px (ui_gym._fit 의 U.h(PAD)) - 18 로 재면 작은 구(부천 등)가 옆 구로 빗나감
    minx, maxx, miny, maxy = min(p[0] for p in pts), max(p[0] for p in pts), min(p[1] for p in pts), max(p[1] for p in pts)
    s = min((cw - 2 * pad) / (maxx - minx), (ch - 2 * pad) / (maxy - miny))
    ox, oy = (cw - (maxx - minx) * s) / 2 - minx * s, (ch - (maxy - miny) * s) / 2 - miny * s
    d = next(x for x in regs if x['code'] == code)
    big = max(rings[code], key=len)
    x, y = d['center']
    ins = sum(1 for (x1, y1), (x2, y2) in zip(big, big[1:] + big[:1]) if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1) % 2
    c = d['center'] if ins else (sum(p[0] for p in big) / len(big), sum(p[1] for p in big) / len(big))
    scr = lambda q: (int(l + q[0] * s + ox), int(t + q[1] * s + oy))
    if alts == 'box':   # 화면에서 그 구의 크기(px)
        a1, a2 = scr((min(p[0] for p in big), min(p[1] for p in big))), scr((max(p[0] for p in big), max(p[1] for p in big)))
        return abs(a2[0] - a1[0]), abs(a2[1] - a1[1])
    if not alts: return scr(c)
    # 다시 누를 자리: 그 구 안쪽 격자점(화면 1px 이상 떨어진 것), 가운데에서 가까운 순
    inside = lambda x, y: sum(1 for (x1, y1), (x2, y2) in zip(big, big[1:] + big[:1]) if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1) % 2
    bx = [p[0] for p in big]; by = [p[1] for p in big]
    grid = [(min(bx) + (max(bx) - min(bx)) * i / 8, min(by) + (max(by) - min(by)) * j / 8) for i in range(1, 8) for j in range(1, 8)]
    pts = sorted((q for q in grid if inside(*q)), key=lambda q: (q[0] - c[0]) ** 2 + (q[1] - c[1]) ** 2)
    out = [scr(c)]
    for q in pts:
        if scr(q) not in out: out.append(scr(q))
    return out[:6]

REWIN = os.path.join(HERE, '관장_다시이김.json')
gym_quiet = ''
def train_on():
    if LITE: return False
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('관장_수련', False))
    except Exception: return False

def money_on():
    # 돈 모드(10/12 사용자): 관장 상금은 이긴 곳마다 하루 1번(레벨×5원, 서버 regions[].today). 켜면 그날 상금이 남은 이긴 관장을
    # 레벨 높은 순으로 먼저 다 돌고(상한 안 215곳 ≈ 3.7~5.7만 원/일), 다 받으면 수련으로 돌아간다. 상금은 한국 자정에 다시 생긴다
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('돈_모드', False))
    except Exception: return False
money_said = ''
money_n = 0   # 돈 모드 균형: 낮은 상금 관장을 고른 뒤 지난 판 수
MONEY_HI = 10   # 상한−10 이상 관장은 상금·경험치 둘 다 좋아 늘 먼저
GYM_MIN = 1.5   # 관장 한 판 + 사이 빈틈(분) — 마감 맞추기 계산용 (10/12 실측 78초 + 빈틈)
def money_deadline():
    # 돈 마감 시각(시, 24 = 자정)을 스스로 정한다 (10/12 사용자: '니가 최적으로'). 상금은 0시에 새로 생기니 PC가 하루 종일 켜져 있으면
    # 자정이 최적. PC를 끄는 날이 있으면 그 전에 다 받아야 하므로, 시간별_지표.json(매시 정각 기록 = 그 시각에 켜져 있었음)에서
    # 최근 7일(오늘 제외) 날마다 마지막으로 기록된 시각을 보고 가장 이른 것(+1시)을 마감으로. 기록 없는 날·밤새 켜진 날은 자정
    try: rows = json.load(open(METRIC, encoding='utf-8')).get('rows') or []
    except Exception: rows = []
    today = time.strftime('%m-%d'); last = {}
    for r in rows:
        if r.get('기기') != ('mac' if MAC else 'win'): continue   # 맥에서 가져온 기록(10-11 14시에 묶음이 끊긴 것)은 이 PC의 켜짐·꺼짐이 아님
        d, h = str(r.get('시각', ''))[:5], str(r.get('시각', ''))[6:8]
        if d and d != today and h.isdigit(): last[d] = max(last.get(d, 0), int(h))
    days = sorted(last)[-7:]
    return min([last[d] + 1 for d in days] + [24])

def money_every(n_lo):
    # 낮은 상금 관장(경험치 적음)을 몇 판에 한 번 낄지 (10/12 사용자: 시간대 관점) — 상금은 하루 총액이 정해져 있어 언제 받든 같으니,
    # 마감(money_deadline)까지 남은 판 수에 남은 낮은 관장이 딱 맞게 끝나도록 나눈다. 여유가 있으면 육성에 몰고 마감이 가까울수록 자주. 지났으면 매 판
    t = time.localtime(); left = money_deadline() * 60 - (t.tm_hour * 60 + t.tm_min)
    if left <= 0 or not n_lo: return 1
    return max(1, int(left / GYM_MIN / n_lo))

GSTATE = os.path.join(HERE, '관장_승패.json')
def gym_state_load():
    try: st = json.load(open(GSTATE, encoding='utf-8'))
    except Exception: st = {}
    if st.get('date') != time.strftime('%Y-%m-%d'): st = {'date': time.strftime('%Y-%m-%d'), 'lost': [], 'cap': 999, 'streak': 0, 'target': st.get('target')}
    return st

def gym_state_save(st): json.dump(st, open(GSTATE, 'w', encoding='utf-8'), ensure_ascii=False)
GYM_HOPELESS, GYM_HOPELESS_DAYS = 5, 3   # 10/27: 같은 관장에게 5연패면 3일 쉼 (10/26 구아버·간피·타로 Lv95 각 36~41패 0승, 진 판에 하루 6시간)
def lost_today():
    st = gym_state_load()
    return set(st.get('lost', [])) | {k for k, u in (st.get('hopeless') or {}).items() if u > time.time()}
def gym_cap(): return gym_state_load().get('cap', 999)

def judge(info):
    st = gym_state_load(); t = st.get('target')
    if not t: return
    if (info.get('active') or {}).get('region') == t['region']: return   # 아직 끝나지 않은 승부(창을 닫아도 1시간 유지) - 짐이 아니다
    r = next((x for x in info['regions'] if x['region'] == t['region']), None)
    if not r: return
    win = r['cleared'] if not t['cleared'] else r.get('wins', 0) > t['wins']
    run = st.setdefault('loss_run', {}); run[t['region']] = 0 if win else run.get(t['region'], 0) + 1
    if run[t['region']] >= GYM_HOPELESS:
        st.setdefault('hopeless', {})[t['region']] = time.time() + GYM_HOPELESS_DAYS * 86400; run[t['region']] = 0
        say(f"관장 {r.get('name', t['region'])} Lv{t['level']} {GYM_HOPELESS}연패 → {GYM_HOPELESS_DAYS}일 쉼")
    if win:
        st['streak'] = st.get('streak', 0) + 1
        if st['streak'] >= 3 and st.get('cap', 999) < 999:
            st['cap'] += 5; st['streak'] = 0; say(f"관장 3연승 — 도전 상한을 Lv{st['cap']}로 올림")
    else:
        # 이미 이긴 곳(다시 이기기·수련)은 지더라도 오늘 목록에서 빼지 않는다 — 상한만 5 내리고 3연승하면 다시 오른다.
        # 육성 포켓몬을 앞에 세운 뒤 지는 판이 생기자 Lv85→80→75→70 관장이 하루 동안 차례로 빠졌다(10/11 0시). 관장전은 경험치용이라
        # 높은 관장을 계속 오가야 이득(쓰러뜨린 상대 레벨이 높을수록 경험치↑). 안 이긴 곳(상금)만 오늘 건너뛴다
        focus = gym_focus()   # 관장 올클리어: 안 이긴 곳도 30분 쉬고 다시, 상한은 안 내림
        if not t['cleared'] and not focus: st['lost'] = sorted(set(st.get('lost', [])) | {t['region']})
        if focus: gym_skip[t['region']] = time.time() - 1800 + 300; globals()['gym_party_for'] = None   # 5분만 쉼 - 남은 관장을 돌아가며
        st['streak'] = 0
        # 상한은 가장 낮은 관장(Lv20) 아래로는 안 내림 — 10/16 저렙 시험: Lv20 한 판 지자 상한 15 → 그날 관장 0판 (지는 판도 경험치는 받음)
        if not focus: st['cap'] = min(st.get('cap', 999), max(t['level'] - 5, min((x['level'] for x in info['regions']), default=0)))
        # 진 그 관장은 30분 쉬게(gym_skip) — 상한만 내리면 3연승 뒤 같은 관장을 또 골라 또 졌다(10/11 09:27~09:41 달리아 Lv80 4연패,
        # 그사이 Lv75만 돎). 같은 레벨의 다른 관장(타입이 다름)을 먼저 해 본다
        if t['cleared']: gym_skip.add(t['region'])
        say(f"관장전 짐: {r.get('name', t['region'])} Lv{t['level']} → " + ('5분 쉬고 다시 (관장 올클리어)' if focus else '오늘은 건너뛰고' if not t['cleared'] else '30분 쉬고, 3연승하면 다시 —') + ('' if focus else f" Lv{st['cap']} 이하로 도전"))
    st['target'] = None; gym_state_save(st)

def rewin_done():
    try: return set(json.load(open(REWIN, encoding='utf-8')).get(time.strftime('%Y-%m-%d'), []))
    except Exception: return set()

def rewin_mark(code):
    json.dump({time.strftime('%Y-%m-%d'): sorted(rewin_done() | {code})}, open(REWIN, 'w', encoding='utf-8'))

def gym_fail(msg):
    global gym_retry
    n = gym_retry[1] + 1
    gym_retry = (time.time() + 60, n) if n <= 3 else (0, 0)
    say(f'관장 이어 도전 못함: {msg}' + (f' → 1분 뒤 다시({n}/3)' if n <= 3 else ' → 그만둠'))

POPUPS = {'기술 배우기': '기술은 그대로 — 게임이 나중에 다시 물음', '업적': '알림만', '메가스톤': '알림만', '알이 부화했다': '알림만', '선물': '알림만(이미 받음)', '진화!': '알림만'}
def clear_learn(pid, notices_only=False):
    # 게임의 묻는 창·알림 창이 관장 창을 막는다: '기술 배우기'는 가운데를 덮고, 업적·선물 등은 grab_set 으로
    # 모든 클릭을 가로챈다('지도로 돌아가기'를 4초마다 눌러도 안 먹힘). 닫기 = 그 창의 확인 단추와 같은 동작
    # (기술 배우기는 아무것도 안 바뀌고 나중에 다시 물음, ui_learn._cancel). 사람이 손 뗐을 때 관장전 하는 동안만 치운다.
    for h, title, _ in wins(pid):
        if title in POPUPS and not (notices_only and title == '기술 배우기'):
            try: win32gui.PostMessage(h, 16, 0, 0); say(f"'{title}' 창 닫음 ({POPUPS[title]})"); time.sleep(0.5)
            except Exception: pass

bond_types_at, bond_types, bond_ko = 0, set(), set()
def bond_gym_types():
    # 진행 중인 유대 미션 중 '관장 1곳'이 남은 것의 타입 (데리고 다니는 포켓몬만 - 관장 파티에 있어야 센다)
    # 11/11: '직접 30번 쓰러뜨리기'가 남은 포켓몬 id 도 같이 모은다(bond_ko) → 관장전에서 앞자리·우대 (플라엣테 2마리 이틀 동안 1/30·2/30)
    global bond_types_at, bond_types, bond_ko
    if time.time() - bond_types_at < 300: return bond_types
    bond_types_at, bond_types, bond_ko = time.time(), set(), set()
    P = api('/api/pokemon')['pokemon']
    today = time.strftime('%Y-%m-%d')
    for p in P:
        if not p['onDesktop'] or not MEGA_OF.get(p['species']) or not bond_live(p, P): continue
        b = bond_info(p)
        left = {m.get('key'): m.get('value', 0) for m in b.get('missions') or [] if m.get('value', 0) < m.get('target', 1)}
        if 'gym' in left:
            # 11/11: 이겨도 안 오르는 경우(관장 파티에 안 들어감 등) 하루 종일 같은 관장만 돌았다(11/09~11 하루 2,000판, 상금 0) → 30분 지켜보고 그날은 포기
            v0, t0, d0 = bond_watch.get(p['id'], (None, 0, ''))
            if v0 != left['gym'] or d0 != today and d0 != today + '!': bond_watch[p['id']] = (left['gym'], time.time(), today)
            elif d0 == today and time.time() - t0 > 1800:
                bond_watch[p['id']] = (v0, t0, today + '!'); say(f"유대 미션: {p['info']['name']} '관장 1곳'이 30분째 안 올라 오늘은 그 타입 관장 먼저 안 함")
            if bond_watch[p['id']][2] != today + '!': bond_types |= set((SPECIES.get(p['species']) or {}).get('types') or [])
        if 'kos' in left: bond_ko.add(p['id'])
    return bond_types
bond_watch = {}

def gym_pref(m, grow_ids):
    # 관장전에서 우대할 포켓몬: 육성(Lv100 전) 또는 유대 미션 '직접 쓰러뜨리기' 남음 — 체력 35% 이상일 때만
    return (m.get('id') in grow_ids and m.get('level', 100) < 100 or m.get('id') in bond_ko) and m.get('hp', 0) >= 0.35 * max(m.get('maxhp', 1), 1)

FOE_EV = os.path.join(HERE, '관장_상대노력치.json')
try: _foe_ev = json.load(open(FOE_EV, encoding='utf-8'))
except Exception: _foe_ev = {}
_foe_new = [0]
def ev_need(P):
    # 노력치 자리 포켓몬(ev_ids)이 아직 못 채운 지킬 능력 (자마젠타 스피드 67/252 등)
    x = next((p for p in P if p['id'] in ev_ids), None)
    if not x: return set()
    ev = x.get('evs') or {}; use, _ = ev_side(x)
    return {s for s in (use, 'spe') if ev.get(s, 0) < 252}
def gym_ev(code, need):
    # 그 관장 상대 6마리가 주는 노력치 중 need 능력 합 (도감 'ev'). 상대 팀은 고정이라 관장마다 한 번만 묻는다
    if not need: return 0
    if code not in _foe_ev:
        if _foe_new[0] >= 10: return 0   # ponytail: 한 번에 10곳만 물음(255곳 다 물으면 사냥이 몇 분 멈춤) — 나머지는 다음 판에
        _foe_new[0] += 1
        try: t = (api(f'/api/gym/trainer/{code}') or {}).get('team') or []
        except Exception: return 0
        _foe_ev[code] = [(SPECIES.get(m.get('species')) or {}).get('ev') or {} for m in t]
        try: json.dump(_foe_ev, open(FOE_EV, 'w', encoding='utf-8'))
        except Exception: pass
    return sum(e.get(s, 0) for e in _foe_ev[code] for s in need)
def ev_sort(regions, P):
    # 11/11: 노력치 자리가 스피드를 못 채우고 이틀째 그대로(페어리 관장만 돌아 HP·방어·특공·특방만 들어옴) → 필요한 능력을 주는 관장을 먼저.
    # 같은 점수끼리는 원래 순서 그대로 (sorted 는 안정 정렬)
    need = ev_need(P); _foe_new[0] = 0
    return sorted(regions, key=lambda r: -gym_ev(r['region'], need)) if need else regions

def grow_hit(p, gtype):
    # 관장전에서 실제로 고를 기술(위력·명중·자속·상성 곱이 가장 큰 것)이 관장 타입에 ×1 이상인가
    if not gtype: return True
    mine = {t for t, v in TYPES.items() if v.get('kr') in (p['info'].get('types') or [])}
    sc = lambda m: (m.get('power') or 0) * (m.get('acc') or 100) * (1.5 if m.get('type') in mine else 1) * eff(m.get('type'), [gtype])
    ms = [MOVES.get(k) or {} for k in p.get('moves') or []]
    best = max(ms, key=sc, default={})
    return bool(best.get('power')) and eff(best.get('type'), [gtype]) >= 1

def grow_fit(P, gtype):
    # 이 타입 관장에서 직접 쓰러뜨릴 수 있는 육성 포켓몬 수: ×1 이상으로 때리고, 관장 타입에 약점(×2+)이 아님
    try: ids = set(json.load(open(GROW, encoding='utf-8')).get('ids') or [])
    except Exception: return 0
    def safe_vs(p):
        mine = [t for t, v in TYPES.items() if v.get('kr') in (p['info'].get('types') or [])]
        return not gtype or eff(gtype, mine) < 2
    return sum(1 for p in P if p['id'] in ids and p['level'] < 100 and grow_hit(p, gtype) and safe_vs(p))

def train_pick(regions, P):
    # 수련 관장 고르기: 가장 높은 레벨에서 5 안쪽이면 육성 포켓몬이 직접 쓰러뜨릴 수 있는 타입을 먼저, 그다음 레벨·상금 남은 곳.
    # 레벨만 보면 강철 로즈 Lv85 를 1시간 65판 중 41판 돌았고 불꽃 주력(메가리자몽X)이 다 쓰러뜨려 육성 KO 27%(10/11 06:43~07:42)
    if not regions: return []
    top = max(r['level'] for r in regions); done = rewin_done()
    return ev_sort(sorted(regions, key=lambda r: (r['level'] >= top - 5, grow_fit(P, r.get('type')), r['level'], r['region'] not in done), reverse=True), P)

def gym_lead(gtype=None):
    # 관장 파티는 시작할 때 slot 순서(서버 gym_routes: ORDER BY slot) → 첫 자리가 주력(어흥염)이면 첫 상대를 주력이 쓰러뜨린다.
    # 관장전은 육성 경험치용이라 시작 전에 육성 포켓몬(Lv100 전, 높은 레벨 먼저)을 앞자리로. 야생 선두 바꾸기와는 따로 돈다(배틀 끝나면 이 순서로 되돌아옴)
    if lead_saved: return
    try: ids = set(json.load(open(GROW, encoding='utf-8')).get('ids') or [])
    except Exception: return
    P = [p for p in api('/api/pokemon')['pokemon'] if p['onDesktop']]
    order = [p['id'] for p in sorted(P, key=lambda p: (p.get('slot') if p.get('slot') is not None else 99, p['id']))]
    # 관장은 한 타입 파티(로즈=강철) → 그 타입에 반감 이하만 가진 육성 포켓몬(페어리 슈쁘)은 0턴에 바로 교체되고 주력이 다 쓰러뜨렸다(21:46).
    # 관장 타입을 ×1 이상으로 때리는 육성 포켓몬만 앞자리로 (기술 위력 있는 것만 침)
    # 관장전에서 실제로 고를 기술(위력·명중·자속·상성 곱이 가장 큰 것)이 ×1 이상이어야 함 — 폴리곤은 전자포(명중 50%)가 있어도
    # 반감 이판사판태클을 골라 0턴에 교체됐다(21:52)
    bond_gym_types()   # bond_ko 새로 (5분 캐시)
    g = [p['id'] for p in sorted((p for p in P if (p['id'] in ids and p['level'] < 100 or p['id'] in bond_ko) and grow_hit(p, gtype)), key=lambda p: (p['id'] not in bond_ko, -p['level']))]
    want = g + [i for i in order if i not in g]
    if not g or want == order: return
    r = api_post('/api/pokemon/order', {'ids': want})
    if r.get('ok'): say(f"관장 선두: 육성 포켓몬 {len(g)}마리를 앞자리로 ({next(p['info']['name'] for p in P if p['id'] == g[0])} 먼저)")
    else: say(f"관장 선두 바꾸기 실패: {str(r.get('detail') or r.get('error'))[:50]}")

# ---------------------------------------------------------------- 관장 올클리어 모드 (2026-10-14 사용자)
# 남은 관장(Lv95·100 챔피언급)은 고정 주력으로 지고 하루 1번만 도전했다. 설정 '관장_올클리어' 가 켜지면:
# 안 이긴 관장을 시작하기 전에 /api/gym/trainer/{region} 의 상대 파티를 보고 박스 전체에서 6마리·순서·도구를 맞춘다.
# 열매는 판이 끝나면 돌아온다(common/held._consume) → 마음껏 씀. 메가스톤은 그대로. 지면 그날 제외 대신 30분 쉬고 다시.
def gym_focus():
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('관장_올클리어'))
    except Exception: return False

def _gstat(base, lv, k):
    return int((2 * base.get(k, 50) + 31) * lv / 100) + (lv + 10 if k == 'hp' else 5)

def gym_pair(p, f):
    # 관장 포켓몬은 판에서 메가진화한다(난천 루카리오·목호 갸라도스→물/악·나여조경석 뮤츠X, 10/14) — 서버 파티엔 진화 전만 나옴
    # → 메가 폼이 있으면 진화 전·후 중 나쁜 쪽으로 친다
    sp = SPECIES.get(f['species']) or {}
    return min(_gym_pair(p, f, x) for x in [sp] + MEGA_OF.get(f['species'], []))

def _gym_pair(p, f, sp):
    # 내 p 가 상대 f 를 상대로 얼마나 유리한가: (내가 주는 체력 비율 / 받는 비율) x 빠르면 1.2, 4 에서 자름
    fb = sp.get('base') or {}; ft = sp.get('types') or []; lv = f['level']
    foe = {'species': sp.get('internal') or f['species'], 'level': lv, 'typeIds': ft, 'hp': _gstat(fb, lv, 'hp')}
    st = p['info']['stats']; mt = (SPECIES.get(p['species']) or {}).get('types') or []
    mon = {'stats': st, 'level': p['level'], 'typeIds': mt,
           'moves': [dict(key=k, type=MOVES[k]['type'], cat=MOVES[k]['cat'], power=MOVES[k].get('power') or 0, acc=MOVES[k].get('acc'), pp=1) for k in p['moves'] if k in MOVES]}
    sc, i = best_move(mon, foe)
    out = damage(mon, mon['moves'][i], foe) / foe['hp'] if sc > 0 else 0
    phys = fb.get('atk', 50) >= fb.get('spa', 50)
    a = _gstat(fb, lv, 'atk' if phys else 'spa')
    inc = max(((2 * lv / 5 + 2) * 90 * a / max(st['def' if phys else 'spd'], 1) / 50 + 2) * 1.5 * eff(t, mt) for t in ft) / max(st['hp'], 1) if ft else 0.3
    return min(4.0, min(out, 1.0) / max(inc, 0.05)) * (1.2 if st['spe'] > _gstat(fb, lv, 'spe') else 1)

gym_party_for = None
GTRIED = os.path.join(HERE, '관장_낸조합.json')   # 관장 → [[6마리 id, 선두 id]] 진 팀 (사냥기를 다시 켜도 이어감)
try: gym_tried = {k: [(set(t), l) for t, l in v] for k, v in json.load(open(GTRIED, encoding='utf-8')).items()}
except Exception: gym_tried = {}
def gym_party(code):
    global gym_party_for
    if gym_party_for == code: return
    foes = api(f'/api/gym/trainer/{code}').get('team') or []
    if not foes: return
    P = api('/api/pokemon')['pokemon']; away = {o['pokemon']['id'] for o in (api('/api/expedition').get('out') or [])}
    natk = lambda p: sum(1 for k in p['moves'] if (MOVES.get(k) or {}).get('cat') not in (None, 'status') and (MOVES.get(k) or {}).get('power'))
    C = [p for p in P if p['level'] >= 90 and natk(p) >= 2 and p['id'] not in away]
    V = {p['id']: [gym_pair(p, f) for f in foes] for p in C}
    pool = sorted(C, key=lambda p: -sum(V[p['id']]))[:20]
    legend = lambda p: bool((SPECIES.get(p['species']) or {}).get('legendary') or (SPECIES.get(p['species']) or {}).get('mythical'))
    def score(team):
        s = 0
        for j in range(len(foes)):
            vs = sorted((V[p['id']][j] for p in team), reverse=True) + [0, 0]
            s += vs[0] + 0.5 * vs[1] + 0.25 * vs[2]
        return s
    import itertools
    # 같은 관장에 늘 같은 6마리·선두를 골라 같은 판을 9번 되풀이하며 졌다(10/14 난천·카지·목호·나여조경석 0승 36패)
    # → 진 팀은 기억해 두고, 다음엔 점수 순으로 내려가며 그동안 낸 팀과 2마리 이상 다른 팀 + 선두도 돌아가며
    tried = gym_tried.setdefault(code, [])
    # 설정 '관장_고정파티' {지역: [id, ...]} - 게임 엔진으로 미리 돌려 본 팀(첫 id 가 선두)을 그대로 낸다.
    # 난천: 점수 순 맞춤 팀은 0승 44패, 엔진 모의로 찾은 딱구리 선두 팀은 73% (10/15). 선두를 바꾸면 0~2%
    try: fixed = (json.load(open(CONF, encoding='utf-8')).get('관장_고정파티') or {}).get(code)
    except Exception: fixed = None
    byid = {p['id']: p for p in P}
    if fixed and not all(i in byid and i not in away for i in fixed): fixed = None
    if fixed: team = [byid[i] for i in fixed]   # 순서·도구 그대로 (모의할 때 지닌 도구 기준)
    else:
      combos = sorted((c for c in itertools.combinations(pool, min(6, len(pool))) if sum(map(legend, c)) <= 1), key=score, reverse=True)
      if not combos: return
      ok = lambda c, d: all(len({p['id'] for p in c} & t) <= 6 - d for t, _ in tried)
      best = next((c for c in combos if ok(c, 2)), None) or next((c for c in combos if ok(c, 1)), combos[0])
      leads = sorted(best, key=lambda p: -V[p['id']][0])
      used = {l for t, l in tried}   # 선두도 아직 안 세워 본 것 중 첫 상대에 쓸 만한(최고의 절반 이상) 것
      lead = next((p for p in leads if p['id'] not in used and V[p['id']][0] >= 0.5 * V[leads[0]['id']][0]), leads[0])
      tried.append(({p['id'] for p in best}, lead['id']))
      try: json.dump({k: [[sorted(t), l] for t, l in v] for k, v in gym_tried.items()}, open(GTRIED, 'w', encoding='utf-8'))
      except Exception: pass
      team = [lead] + sorted((p for p in best if p is not lead), key=lambda p: -sum(V[p['id']]))
    ids = [p['id'] for p in team]
    for p in P:
        if p['onDesktop'] and p['id'] not in ids: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': False})
    for p in team:
        if not p['onDesktop']: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': True})
    api_post('/api/pokemon/order', {'ids': ids})
    if not fixed: gym_items(team, foes, P)
    gym_party_for = code
    say(f"관장 {'고정' if fixed else '맞춤'} 파티({code}, {len(tried)}번째 조합): " + ', '.join(f"{p['info']['name']}{'←' + (p.get('_item') or '-')}" for p in team))

def gym_items(team, foes, P):
    # 공격 도구(+5% 이상)보다, 상대 둘 이상이 가진 타입에 ×2 이상 약하면 그 반감 열매가 먼저. 둘 다 아니면 자뭉열매
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
    if root not in sys.path: sys.path.insert(0, root)
    from common import held as HL
    shop = api('/api/shop'); items = {i['id']: i for i in shop.get('items') or []}
    mega = lambda i: (items.get(i) or {}).get('cat') == 'megastone'
    pool = dict(shop.get('bag') or {})
    lock = set(api('/api/pvp/team').get('ids') or []) if rank_locked() else set()   # 10/25 사용자: 랭크팀_고정이면 랭크 팀 도구는 빼지도 끼우지도 않음
    if not conf_on('도구_자동'): lock = {p['id'] for p in team}   # 11/02: 도구 자동을 끄면 관장 맞춤 파티도 지닌 그대로
    for p in team:
        if p['id'] in lock: p['_item'] = HL.name(p['held']) if p.get('held') else None
    mine, team = team, [p for p in team if p['id'] not in lock]
    for p in team:
        if p.get('held') and not mega(p['held']): pool[p['held']] = pool.get(p['held'], 0) + 1
    off = {i for i in pool if i in HL.ALL and not i.endswith('BERRY') and i not in HELD_SKIP and i not in HL.HAPPINESS_ITEMS and not mega(i) and i != 'LUCKYEGG'}
    ftypes = [t for f in foes for t in ((SPECIES.get(f['species']) or {}).get('types') or [])]
    rb = {t: b for b, t in HL.RESIST_BERRY.items()}
    want = {}
    if not any(p.get('held') and mega(p['held']) for p in mine):   # 메가는 한 판에 한 번 - 메가 든 포켓몬이 없으면 가방의 메가스톤을 맞는 종에게
        for p in sorted(team, key=lambda p: team.index(p)):
            st = next((m.get('megaStone') for m in MEGA_OF.get(p['species'], []) if pool.get(m.get('megaStone'), 0) > 0), None)
            if st: want[p['id']] = st; pool[st] -= 1; p['_item'] = HL.name(st); break
    for p in team:
        if p['id'] in want: continue
        if p.get('held') and mega(p['held']): p['_item'] = HL.name(p['held']); continue
        mt = (SPECIES.get(p['species']) or {}).get('types') or []
        weak = sorted({t for t in ftypes if eff(t, mt) >= 2 and ftypes.count(t) >= 2 and pool.get(rb.get(t), 0) > 0}, key=lambda t: (-ftypes.count(t), -eff(t, mt)))
        g = sorted(((held_gain(p, i, HL.TYPE_BOOST), i) for i in off if pool.get(i, 0) > 0), reverse=True)
        it = rb[weak[0]] if weak else g[0][1] if g and g[0][0] >= 0.05 else 'SITRUSBERRY' if pool.get('SITRUSBERRY') else None
        if it: want[p['id']] = it; pool[it] -= 1; p['_item'] = HL.name(it)
    for p in team:
        if p['id'] in want and p.get('held') != want[p['id']] and p.get('held'): api(f"/api/pokemon/{p['id']}/hold", 'DELETE')
    for p in team:
        if p['id'] in want and p.get('held') != want[p['id']]:
            r = api_post(f"/api/pokemon/{p['id']}/hold", {'item': want[p['id']]})
            if not r.get('ok'): say(f"관장 도구 실패: {p['info']['name']} {want[p['id']]} — {str(r.get('detail') or r.get('error'))[:50]}")

def gym_next(pid):
    global gym_team_max, gym_target, gym_retry
    if not gym_team_max:
        gym_team_max = max((p['level'] for p in api('/api/pokemon')['pokemon'] if p.get('onDesktop')), default=0)
    info = api('/api/gym')
    judge(info)
    cap = min(gym_team_max, gym_cap())
    m = json.load(open(next(os.path.join(GDIR, f) for f in os.listdir(GDIR) if f.startswith('gym_map_')), encoding='utf-8'))
    sido_of = {d['code']: d['sido'] for d in m['sgg']}
    if not island_code():
        island_sido = {d['sido'] for d in m['sgg'] if d.get('islands')}
        sido_of = {c: sd for c, sd in sido_of.items() if sd not in island_sido}
    lost = lost_today()
    act = (info.get('active') or {}).get('region')
    if act:   # 끝나지 않은 승부가 있으면 다른 곳은 '다른 승부가 진행 중'으로 막힌다 → 그곳부터 이어서 한다
        lv0 = next((r['level'] for r in info['regions'] if r['region'] == act), 0)
        sido_of.setdefault(act, next((d['sido'] for d in m['sgg'] if d['code'] == act), None))
        if sido_of.get(act):
            say(f"관장 승부 이어하기: {act} {next((r['name'] for r in info['regions'] if r['region'] == act), '?')} (창이 닫혀도 서버에 남은 승부)")
            gym_skip.discard(act)
    # 유대 미션 ①(그 포켓몬 타입 관장 1곳 이기기)이 남았으면 그 타입 관장을 먼저 (2026-10-10). 안 이긴 곳 > 다시 이기기
    bt = bond_gym_types()
    if bt and not act:
        ok = lambda r: r.get('type') in bt and r['region'] not in lost and r['region'] in sido_of and r['level'] <= cap and r['region'] not in gym_skip
        bc = sorted((r['level'], r['region']) for r in info['regions'] if ok(r) and not r['cleared']) \
            or sorted(((r['level'], r['region']) for r in info['regions'] if ok(r) and r['cleared']), reverse=True)
        if bc:
            act, lv0 = bc[0][1], bc[0][0]
            say(f"유대 미션: {', '.join((TYPES.get(t) or {}).get('kr', t) for t in bt)} 타입 관장 먼저 → {act} {next((r['name'] for r in info['regions'] if r['region'] == act), '?')}")
    cand = [(lv0, act)] if act and sido_of.get(act) else sorted((r['level'], r['region']) for r in info['regions'] if not r['cleared'] and r['region'] not in gym_skip and r['region'] not in lost and r['region'] in sido_of and r['level'] <= cap)
    rewin = False
    if not cand:
        # 관장전은 육성 경험치용 (10/10). 서버는 상금만 하루 한 번이고 도전·경험치는 몇 번이든 준다 → '하루 한 번 다시 이기기'로
        # 높은 곳을 다 쓰면 Lv35 같은 낮은 곳만 돌았다. 수련이 켜져 있으면 상한 안에서 가장 높은 레벨을 고르고(같은 레벨이면 상금 남은 곳)
        done = rewin_done()
        ok = [r for r in info['regions'] if r['cleared'] and r['region'] not in lost and r['region'] in sido_of and r['level'] <= cap and r['region'] not in gym_skip]
        if train_on():
            cand = [(r['level'], r['region']) for r in train_pick(ok, [p for p in api('/api/pokemon')['pokemon'] if p['onDesktop']])][:3]
            rewin = True if cand and cand[0][1] not in done else '수련'
        else:
            cand = sorted(((r['level'], r['region']) for r in ok if r['region'] not in done), reverse=True)
            rewin = True
    if not cand:
        if gym_quiet != time.strftime('%Y-%m-%d'):
            say(f'관장 오늘 할 곳 없음: 안 이긴 곳(내 최고 Lv.{gym_team_max} 이하)도, 다시 이기기도 다 함 — 내일 다시')
            globals()['gym_quiet'] = time.strftime('%Y-%m-%d')
        gym_target = None; return
    lv, code = cand[0]; sido = sido_of[code]
    clear_learn(pid)
    top = main_window(pid)
    if not top:
        p = next((q for q in (hit_point(h) for h, _, _ in wins(pid) if h in companions) if q), None)
        if p:
            cur = pyautogui.position(); pyautogui.doubleClick(*p); pyautogui.moveTo(*cur); time.sleep(2.5)
            top = main_window(pid)
    if not top: return gym_fail('포스크탑 메인 창을 못 엶')
    try:
        if win32gui.IsIconic(top): win32gui.ShowWindow(top, 9); time.sleep(1)
    except Exception: pass
    L, T, _, _ = rect(top)

    tab = win32gui.find_text(top, '관장') if MAC else []   # 맥: 탭 위치가 달라 '관장' 글자로 찾는다
    if tab: press(top, tab[0]); time.sleep(1.5)
    else: press_at(top, L + z(485), T + z(60)); time.sleep(1.5)
    canvas = lambda: [c for c in kids(top, 683, 496, 80, 80) if rect(c) and (MAC or rect(c)[0] - L < z(40))]
    if not canvas(): return gym_fail('관장 탭으로 못 감')
    nat = [c for c in kids(top, 83, 32) if rect(c) and (MAC or rect(c)[0] - L > z(800) and rect(c)[1] - T < z(150))]
    if not nat: return gym_fail('전국 지도 버튼 없음')
    press(top, nat[0])
    codes = sorted(s['code'] for s in m['sido'])
    if MAC:   # 맥: 시·도 칸을 순서·좌표가 아니라 '이름 글자'로 찾아 탐지기로 누른다. 창이 작으면 칸이 스크롤 안에 있어
        # 순서·좌표로는 엉뚱한 시·도가 눌렸다(10/10 경남 → 충북). 안 보이면 칸을 내려서 다시 찾는다
        short = {'서울특별시': '서울', '부산광역시': '부산', '대구광역시': '대구', '인천광역시': '인천', '대전광역시': '대전', '울산광역시': '울산',
                 '세종특별자치시': '세종', '경기도': '경기', '강원특별자치도': '강원', '충청북도': '충북', '충청남도': '충남', '경상북도': '경북',
                 '경상남도': '경남', '제주특별자치도': '제주', '전북특별자치도': '전북', '전남광주통합특별시': '전남광주'}
        nm = next((x['name'] for x in m['sido'] if x['code'] == sido), '')
        want_s = short.get(nm, nm)
        hit_s = None
        for frac in (0.0, 0.25, 0.5, 0.75, 1.0):   # 칸이 정보 칸의 '보이는 범위' 안에 들어올 때까지 내린다 (밖이면 목록엔 있어도 눌리지 않음)
            win32gui.scroll_panels(top, frac); time.sleep(0.4)
            head = win32gui.find_text(top, '시·도 바로 가기')
            hy = rect(head[0])[1] if head and rect(head[0]) else 0
            pan = [(k[2], k[3], k[2] + k[4], k[3] + k[5]) for k in win32gui._canvases(top)[1]]
            seen = lambda r: any(pl <= r[0] and r[2] <= pr and pt <= r[1] and r[3] <= pb - 2 for pl, pt, pr, pb in pan) if pan else True
            hit_s = next((c for c in win32gui.find_text(top, want_s) if rect(c) and rect(c)[1] > hy and seen(rect(c))), None)
            if hit_s: break
        if not hit_s: return gym_fail(f'시·도 칸 못 찾음 ({want_s})')
        press(top, hit_s); time.sleep(1.5)
        win32gui.scroll_panels(top, 0.0)
    else:
        for _ in range(10):
            time.sleep(0.3); btns = kids(top, 71, 53, 5, 2)
            if len(btns) == len(codes): break
        if len(btns) != len(codes): return gym_fail(f'시·도 버튼 {len(btns)}개')
        r = rect(btns[codes.index(sido)])
        if not r: return gym_fail('시·도 버튼 사라짐')
        press_at(top, (r[0] + r[2]) // 2, r[1] + z(15)); time.sleep(1.5)
    cv = canvas()
    if not cv: return gym_fail('지도 캔버스 못 찾음')
    pts = region_point(sido, code, cv[0], alts=True); pt = pts[0]
    bw, bh = region_point(sido, code, cv[0], alts='box')
    if MAC and min(bw, bh) < 12:   # 창이 작아 지도에서 그 구가 손톱만 하면(12px 미만) 빗맞는다 → 오늘은 건너뛰고 바로 다른 관장 (실패로 안 셈)
        gym_skip.add(code); gym_retry = (time.time() + 2, gym_retry[1])
        say(f"관장 건너뜀: {code} 이(가) 지도에서 {bw}x{bh}px 로 너무 작음 (게임 창이 작음) → 다른 관장"); return
    hit = press_at(top, *pt)
    go = []
    for _ in range(16):
        time.sleep(0.5)
        go = [c for c in kids(top, 304, 40, 1, 1) if rect(c) and (MAC or rect(c)[0] - L > z(650))]
        if go: time.sleep(0.5); break
    if MAC and not go:   # 창이 작으면 오른쪽 정보 칸이 스크롤되어 '도전하기'가 밖으로 밀린다 → 맨 아래로 내려 다시 찾는다
        for alt in [None] + pts[1:4]:   # 그래도 없으면 작은 지도에서 빗맞힌 것 - 그 구 안 다른 자리를 눌러 본다
            if alt: press_at(top, *alt); time.sleep(1.0)
            for frac in (1.0, 0.75, 0.5):
                win32gui.scroll_panels(top, frac); time.sleep(0.5)
                pan = [(k[2], k[3], k[2] + k[4], k[3] + k[5]) for k in win32gui._canvases(top)[1]]
                go = [c for c in kids(top, 304, 40, 1, 1) if rect(c) and (not pan or any(pt <= rect(c)[1] and rect(c)[3] <= pb for pl, pt, pr, pb in pan))]
                if go: break
            if go: break
    if MAC and go:   # 맥: 오른쪽 경로 글자로 고른 구가 맞는지 보고, 아니면 그 구 안의 다른 자리를 누른다 (41196 → 41192 로 28번 엇나간 일)
        want = next((x['name'] for x in m['sgg'] if x['code'] == code), '').replace(' ', '')
        picked = lambda: any(len(k) > 6 and k[6] and k[6].replace(' ', '') in (want, want[-len(k[6].replace(' ', '')):]) and len(k[6].replace(' ', '')) >= 2
                             for k in win32gui._kid_rows(top) if k[1] == 'Label')
        for alt in [None] + pts[1:]:
            if picked(): break
            if alt is None: continue
            press_at(top, *alt); time.sleep(1.0); win32gui._cache['t'] = 0
        else:
            if not picked(): gym_skip.add(code); return gym_fail(f'지도에서 {want} 을(를) 못 고름 (옆 구가 눌림)')
        go = [c for c in kids(top, 304, 40, 1, 1) if rect(c)] or go
    if not go: gym_skip.add(code); return gym_fail(f"도전하기 버튼 없음 ({code} {sido}, 지도 클릭 {pt} {'됨' if hit else "못함(가림: '" + win32gui.GetWindowText(win32gui.GetAncestor(win32gui.WindowFromPoint(pt), 2)) + "')"})")
    safe('관장 선두', gym_lead, next((r.get('type') for r in info['regions'] if r['region'] == code), None))
    press(top, go[0])
    if MAC: win32gui.scroll_panels(top, 0.0)   # 정보 칸 스크롤을 원래대로
    for _ in range(10):   # 서버가 늦게 답할 수 있다 (원본은 3초 한 번)
        time.sleep(1); b = api('/api/gym/battle')
        if b.get('region'): break
    gym_target = code
    st = gym_state_load()
    if b.get('region') == code: st['target'] = {'region': code, 'cleared': any(r['region'] == code and r['cleared'] for r in info['regions']),
                                           'wins': next((r.get('wins', 0) for r in info['regions'] if r['region'] == code), 0), 'level': lv}
    gym_state_save(st)
    if b.get('region') != code:
        say(f"관장 이어 도전: {code} 눌렀는데 시작된 곳 {b.get('region')}")
        if not b.get('region'): gym_skip.add(code)
    else:
        gym_retry = (0, 0)
        if rewin is True: rewin_mark(code)
        label = {True: '다시 이기기', '수련': '수련'}.get(rewin, '이어 도전')
        say(f"관장 {label}: {code} {next((r['name'] for r in info['regions'] if r['region'] == code), '?')} Lv.{lv} 시작" + (f' (보상 {lv * 5}원)' if rewin is True else ' (보상 없음, 경험치)' if rewin == '수련' else ''))

def press_sure(top, c, b):


    sig = lambda x: (x.get('turn'), x.get('needSwitch'), (x.get('me') or {}).get('slot'))
    before = sig(b)
    for k in range(5):
        if not alive(c) or not press(top, c): return k > 0
        for _ in range(4):
            time.sleep(0.5)
            if sig(api('/api/gym/battle').get('battle') or {}) != before: return True
    return 'stuck'

def gym_step(pid):
    global gym_paused, gym_seen, gym_active, gym_retry, gym_try_at, gym_done, gym_team_max
    top = gym_window(pid)
    wait, idle = gym_idle(), idle_s()
    try: force = json.load(open(CONF, encoding='utf-8')).get('바로진행_까지', 0) - time.time()
    except Exception: force = 0
    busy = idle < wait and force <= 0
    left = '손 뗀 지 %d초 / %d초' % (idle, wait)
    if force > 0: left += ' (조종판: 바로 진행 %d분 남음)' % (force // 60 + 1)
    status(관장=('대기 중 — ' + left if busy else '진행 중' + (' (조종판 바로 진행)' if force > 0 else '')) if top else ('다음 도전 대기 — ' + left if busy else '다음 도전 곧 시작') if gym_retry[0] or os.path.exists(CHAIN) else '없음')
    if busy != gym_paused and (top or gym_retry[0]):
        say('관장전 잠시 멈춤: 컴퓨터 사용 중' if busy else f'관장전 다시 진행: {gym_idle()}초 동안 입력 없음')
    gym_paused = busy

    if battle or fight:
        gym_seen = time.time()
        status(관장='잠깐 대기 — 야생 전투 우선' if top or os.path.exists(CHAIN) else '없음')
        return
    if not top:
        if gym_active:
            gym_active = False; gym_retry = (time.time() + 3, gym_retry[1])

        if not gym_retry[0] and os.path.exists(CHAIN) and time.time() - gym_try_at > (20 if force > 0 else 120):
            gym_retry = (time.time(), gym_retry[1])
        if gym_retry[0] and time.time() > gym_retry[0] and not busy:
            gym_retry = (0, gym_retry[1]); gym_try_at = time.time(); gym_next(pid)
        return
    if not gym_active:
        gym_active = True; gym_seen = time.time()
        try: open(CHAIN, 'w').close()
        except OSError: pass
    if busy: gym_seen = time.time(); return
    clear_learn(pid)
    moves, party = kids(top, 304, 91, 12, 8), kids(top, 201, 73, 12, 8)
    back = kids(top, 142, 42, 4, 3)
    if back and not moves and not party:
        if gym_done[0] != '결과': gym_done = ('결과', time.time())
        elif time.time() - gym_done[1] > 3:
            press(top, back[0]); gym_done = (None, 0)
            say('관장전 끝 - 지도로 돌아가기')
            globals()['gym_gap'] = True   # 다음 판을 고르기 전 빈틈 - 육성 교체·기술 배우기를 지금 돌린다
        return
    if not moves and not party:
        if time.time() - gym_seen > 120:
            gym_seen = time.time()
            j = api('/api/gym/battle')
            if not (j.get('battle') or {}) or (j.get('battle') or {}).get('over'):
                say('관장전 창이 2분째 멈춤 - 전투가 끝나 있어 창을 닫음')
                try: win32gui.PostMessage(top, 16, 0, 0)
                except Exception: pass
            else:
                say('관장전 창이 2분째 멈춤 - 서버상 전투 진행 중, 계속 기다림')
        return
    gym_seen = time.time()
    j = api('/api/gym/battle'); b = j.get('battle') or {}
    if not b or b.get('over'): return
    key = (j['id'], b['turn'], b['needSwitch'], b['me']['slot'])
    if gym_done[0] == key and time.time() - gym_done[1] < 12: return
    team, slot = b['me']['team'], b['me']['slot']
    gym_team_max = max(m['level'] for m in team)
    me, foe = team[slot], b['foe']['team'][b['foe']['slot']]
    # 관장전은 이기기보다 육성 포켓몬에게 경험치를 먹이는 용도 (2026-10-10 사용자). 경험치는 쓰러뜨린 순간 나와 있던
    # 포켓몬이 다 받고 나머지는 학습장치로 절반 → 내보낼 때 육성 포켓몬(Lv100 전)을 1.3배 쳐서 직접 쓰러뜨리게 한다
    try: grow_ids = set(json.load(open(GROW, encoding='utf-8')).get('ids') or [])
    except Exception: grow_ids = set()
    # 1.3배로는 불꽃 ×4 주력에 밀려 육성 포켓몬이 1시간 277턴 중 21턴만 공격했다(10/10 19~20시) → 체력 35% 이상이면 3배
    growing = lambda m: gym_pref(m, grow_ids)
    gb = lambda m: 3 if growing(m) else 1
    bench = sorted(((value(m, foe) * gb(m), i) for i, m in enumerate(team) if i != slot and not m.get('fainted') and m.get('hp', 0) > 0), reverse=True)
    if party and not moves:
        if not bench or len(party) != len(team): return
        pick = grow_first(bench, team, foe, growing)
        if not press_sure(top, party[pick], b): return
        say(f"관장전 {b['turn']}턴: {foe['name']} 상대로 {team[pick]['name']} 내보냄")
    else:
        refused = gym_refused.get(key, set())
        sc, mi = best_move(me, foe, refused)
        if sc < 0: mi = next((i for i in range(len(me['moves'])) if i not in refused), 0)
        fk = (j['id'], b['foe']['slot'], foe.get('species'))
        weak = eff(me['moves'][mi]['type'], foe['typeIds']) <= 0.5 or threat(foe, me) >= 2
        if growing(me) and eff(me['moves'][mi]['type'], foe['typeIds']) >= 1 and threat(foe, me) < 4: weak = False   # 육성 포켓몬은 때릴 수 있으면 남아서 직접 쓰러뜨림
        if bench and fk not in gym_swapped and weak and bench[0][0] > 1.5 * value(me, foe) * gb(me):   # 육성 포켓몬은 웬만하면 계속 싸움
            gym_swapped.add(fk)
            btn = kids(top, 200, 44, 6, 3)
            if btn and not kids(top, 201, 73, 12, 8):
                press(top, btn[0])
                for _ in range(8):
                    time.sleep(0.25); party = kids(top, 201, 73, 12, 8)
                    if len(party) == len(team): break
                if len(party) == len(team) and press_sure(top, party[bench[0][1]], b):
                    say(f"관장전 {b['turn']}턴: {foe['name']} 상대로 불리 → {team[bench[0][1]]['name']}로 교체")
                    gym_done = (key, time.time()); return
        if not LITE and b.get('canMega') and not b.get('megaUsed') and j['id'] not in gym_mega:
            gym_mega.add(j['id'])
            L, T, _, _ = rect(top)
            # 맥: 단추 글자 그대로(ui_mega.TEXT) — '메가' 부분 일치는 전투 메시지('메가리자몽X의 …')에도 걸린다
            btn = win32gui.find_text(top, '메가진화') if MAC else [c for c, r in children(top) if z(325) <= r[1] - T <= z(390) and z(50) <= r[2] - r[0] <= z(240) and z(20) <= r[3] - r[1] <= z(52)]
            if btn and press(top, btn[0]): say('관장전: 메가진화 단추 누름(처음 쓰는 기능 — 결과 확인 필요)'); time.sleep(0.5)
            else: say('관장전: 메가진화 가능한데 단추를 못 찾음')
        # 기술이 4개 미만인 포켓몬(빈티나: 튀어오르기·몸통박치기·바둥바둥)도 있다 - 단추 수 = 기술 수면 누른다.
        # 예전엔 '정확히 4개'만 받아서 그런 포켓몬이 나오면 관장전이 통째로 멈췄다 (10/10 13:20~13:27)
        if not (len(moves) == len(me['moves']) and mi < len(moves)): return
        ok = press_sure(top, moves[mi], b)
        if ok == 'stuck':
            gym_refused.setdefault(key, set()).add(mi); say(f"관장전 {b['turn']}턴: {me['moves'][mi]['kr']}가 안 먹혀 다른 기술로 바꿈")
            if len(gym_refused[key]) >= 2:
                # 두 기술째 안 먹히면 게임 화면이 굳은 것 — 서버는 같은 기술을 받는다(10/11 01:20 메가리자몽X 4턴에서 3분 동안
                # 단추가 안 먹혀 게임 재시작 반복, 서버에 직접 보내니 바로 다음 턴). 서버에 직접 보내고 창을 닫아 게임이 다시 불러오게 한다
                mi0 = best_move(me, foe)[1]
                r = api_post(f"/api/gym/battle/{j['id']}/act", {'kind': 'move', 'move': me['moves'][mi0]['key'], 'hour': time.localtime().tm_hour})
                say(f"관장전 {b['turn']}턴: 화면 단추가 안 먹혀 서버에 직접 {me['moves'][mi0]['kr']} → " + ('다음 턴, 창 다시 엶' if r.get('battle') else f"실패 {str(r.get('detail'))[:40]}"))
                gym_refused.pop(key, None)
                try: win32gui.PostMessage(top, 16, 0, 0)
                except Exception: pass
            return
        if not ok: return
        mv = me['moves'][mi]
        say(f"관장전 {b['turn']}턴: {me['name']} → {mv['kr']} (상성 ×{eff(mv['type'], foe['typeIds']):g}, 상대 {foe['name']})")
    gym_done = (key, time.time())



GROW = os.path.join(HERE, '육성슬롯.json')
global grow_at; grow_at = 0
def evo_need(p):
    if p.get('noEvolve'): return None
    lv = [e['level'] for e in (SPECIES.get(p['species']) or {}).get('evo') or []
          if e.get('mode') == 'level' and e.get('level') and (not e.get('gender') or e['gender'] == p.get('gender'))]
    return max(0, min(lv) - p['level']) if lv else None

def friend_need(p):
    # 친밀도 진화(골뱃→크로뱃 등)까지 남은 친밀도. 데리고 다닐 때만 20분에 1점 오르고, 그 뒤 레벨이 하나 오르면 진화한다.
    # 낮·밤 조건은 그때 시각이 맞아야 하므로 일단 키워 두고, '특정 타입 기술' 조건은 그 기술이 있을 때만 센다.
    # Lv100 이어도 친밀도는 데리고 다녀야 오른다. 다 차면 진화는 사용자가 수동으로(이상한사탕 등) 한다 (2026-10-10 사용자 결정)
    if p.get('noEvolve'): return None
    need = [e['happiness'] for e in (SPECIES.get(p['species']) or {}).get('evo') or []
            if e.get('mode') == 'friend' and e.get('happiness')
            and (not e.get('moveType') or any((MOVES.get(m) or {}).get('type') == e['moveType'] for m in p.get('moves') or []))]
    return max(0, min(need) - (p.get('happiness') or 0)) if need else None

def can_levelup(x):
    # 진화가 다 끝났어도 Lv100 전이면 레벨업 육성 후보 (공격 기술 2개 이상 - 관장 주력이 될 수 있는 것)
    natk = sum(1 for m in x.get('moves') or [] if (MOVES.get(m) or {}).get('cat') not in (None, 'status') and (MOVES.get(m) or {}).get('power'))
    return x['level'] < 100 and natk >= 2 and iv_sum(x) >= GROW_IV_MIN

GROW_IV_MIN = 60   # (10/13 사용자: 90→60, 센 후보가 바닥나 라플레시아 등을 넣음) 레벨업만 남은 후보는 개체값 합(최대 186) 60 이상만 - 관장 주력감만 키운다. 진화(도감용) 후보는 개체값을 안 본다
def iv_sum(x):
    try:
        root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
        if root not in sys.path: sys.path.insert(0, root)
        from common import pokelogic as PL
        return sum((PL.effective_ivs(x) or {}).values())   # 병뚜껑 반영
    except Exception: return sum((x.get('ivs') or {}).values())

def grow_key(x, mine=()):
    # 육성 순서: 친밀도가 이미 찬 것(레벨 하나면 진화) → 레벨 진화(가까운 순) → 친밀도 진화(가까운 순)
    #          → 레벨업만(키우던 것 먼저, 최종 종족값 높은 순 - 나중에 주력 점검이 고를 만한 강한 종부터)
    lv, fr = evo_need(x), friend_need(x)
    if fr == 0: return (0, 0, -x['level'])
    if lv is not None: return (1, lv, -x['level'])
    if fr is not None: return (2, fr, -x['level'])
    return (3, 0 if x['id'] in mine else 1, -final_bst(x['species'], x.get('gender')), -iv_sum(x), -x['level'])

# 육성 우선순위 (2026-10-10 사용자 결정): 'Lv100 + 갈 수 있는 진화까지 마쳤을 때 얼마나 센가'가 높은 순.
# 도감 채우기용 진화(루리리→마릴리 종족값 420 등)보다 최종적으로 주력감이 되는 포켓몬을 먼저 키운다.
# 진화는 레벨·친밀도·돌 등 방법을 가리지 않고 센다 (2026-10-10 사용자 결정: 돌·사탕 진화는 사용자가 수동으로 시킨다).
# 친밀도로 진화해 지금보다 세지는 포켓몬은 Lv100 이어도 친밀도를 채우려고 육성 자리를 차지할 가치가 있다
def final_species(x):
    sp, gender = x['species'], x.get('gender')
    for _ in range(3):
        nxt = [e['to'] for e in (SPECIES.get(sp) or {}).get('evo') or []
               if (not e.get('gender') or e['gender'] == gender) and e.get('to') in SPECIES]
        if not nxt or x.get('noEvolve'): break
        sp = max(nxt, key=lambda t: sum(SPECIES[t].get('base', {}).values()))
    return sp

def grow_ok(x):
    # 육성 자리에 둘 가치: 개체값 90 이상이고, (Lv100 전) 또는 (Lv100 이지만 친밀도 진화가 남아 아직 채울 친밀도가 있음)
    if iv_sum(x) < GROW_IV_MIN: return False
    evolves = final_species(x) != x['species']
    if x['level'] < 100: return evolves or can_levelup(x)
    if evolves and bool(friend_need(x)): return friend_hold_worth(x)
    # 메가 유대: 친밀도만 채우려고 Lv100 이 자리를 지키지는 않는다 - 255까지 34~50시간이면 그동안 다른 포켓몬 5마리+를
    # Lv100 으로 키울 수 있다(최종 성장값 목표, 10/10 결정). 친밀도는 주력 자리에서도 오른다.
    # 이미 시작한 유대 미션(처치 30·포획 10)은 데리고 다녀야 채워지므로 끝날 때까지만 지킨다
    if MEGA_OF.get(x['species']):
        try: return bond_live(x)
        except Exception: return False
    return False

def bond_prog(b):
    return sum(min(m.get('value', 0), m.get('target', 1)) / max(m.get('target', 1), 1) for m in b.get('missions') or [])
def bond_live(x, P=None):
    # 진행 중이고 받을 스톤이 남은 유대 미션인가. 11/11: 한 종의 스톤은 계정에 하나씩(서버 mega.py) → 같은 종 개체가 여럿 미션 중이면
    # 남은 스톤 수(missing)만큼, 많이 채운 순(같으면 id 작은 순)으로만 친다 — 플라엣테 2마리가 이틀 자리를 차지, 둘째는 받을 게 없었음
    b = bond_info(x)
    if not (b.get('started') and not b.get('done') and b.get('missing')): return False
    P = P if P is not None else api('/api/pokemon')['pokemon']
    rank = lambda y, by: (-bond_prog(by), y['id'])
    me = rank(x, b)
    ahead = 0
    for y in P:
        if y['id'] == x['id'] or y['species'] != x['species']: continue
        by = bond_info(y)
        if by.get('started') and not by.get('done') and rank(y, by) < me: ahead += 1
    return ahead < len(b['missing'])

def species_power(x, sp, level=100, mega=True):
    # 그 개체(개체값·노력치·성격)가 종 sp·레벨 level 일 때의 힘. 메가진화할 수 있는 종이면 메가 폼까지 센다
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
    if root not in sys.path: sys.path.insert(0, root)
    from common import pokelogic as PL
    ivs = PL.effective_ivs(x) or {}
    def power(base):
        st = {k: PL.calc_stat(k, base.get(k, 50), ivs.get(k, 0), (x.get('evs') or {}).get(k, 0), level, x.get('nature')) for k in ('hp', 'atk', 'def', 'spa', 'spd', 'spe')}
        # 관장·랭크 점수와 같은 꼴: 센 쪽 공격 x 버티기 x 빠르기 (주력 리자몽 ≈ 기준값)
        return max(st['atk'], st['spa']) * (st['hp'] * (st['def'] + st['spd']) / 2) ** 0.5 * (1 + st['spe'] / 400) / 1000
    # 메가진화할 수 있는 종이면 메가 폼까지 센다 (2026-10-10 사용자 요청) - 유대 미션으로 스톤을 받으면 배틀마다 메가진화
    return max([power((SPECIES.get(sp) or {}).get('base') or {})] + [power(m.get('base') or {}) for m in (MEGA_OF.get(sp, []) if mega else [])])

def final_power(x):
    return species_power(x, final_species(x))

_grow_pool = []   # grow_step 이 넘겨 주는 전체 포켓몬(친밀도 자리 판단에서 대기 후보를 볼 때 씀)
def slot_levels_per_hour():
    # 육성 자리 하나가 1시간에 올리는 레벨(최근 3시간 시간별 지표의 실측, Lv100 에 닿은 것은 뺌). 자료가 없으면 10
    try: rows = json.load(open(METRIC, encoding='utf-8')).get('rows', [])[-4:]
    except Exception: rows = []
    ups = [b['육성'][k] - a['육성'][k] for a, b in zip(rows, rows[1:]) for k in b.get('육성', {})
           if k in a.get('육성', {}) and a['육성'][k] < b['육성'][k] < 100]
    return sum(ups) / len(ups) if ups else 10

def friend_hold_worth(x):
    # Lv100 친밀도 진화 대기가 육성 자리를 지킬 가치 (10/11 사용자: '친밀도를 채우는 게 최종적으로 더 강해지면 유지,
    # 다른 포켓몬이 들어와 Lv100 이 되는 게 더 강해지면 교체'). 자리 1시간당 얻는 힘을 비교한다.
    #  유지 = (친밀도 진화 뒤 힘 − 지금 힘) ÷ 남은 시간(데리고 다닐 때 20분에 1점)
    #  교체 = 대기 후보 1등의 (Lv100·진화·메가 힘 − 지금 힘) ÷ Lv100 까지 걸리는 시간(실측 레벨/시간)
    # 10/11 09시 두르쿤·꼬몽울이 31~46시간 두 자리를 차지해 육성 효율 약 40% 손해
    fr = friend_need(x) or 0
    hold = (final_power(x) - species_power(x, x['species'])) / max(fr / 3, 0.5)
    rate = slot_levels_per_hour()
    alt = [(final_power(c) - species_power(c, c['species'], c['level'])) / max((100 - c["level"]) / rate, 1.0)
           for c in _grow_pool if c['level'] < 100 and c['id'] != x['id'] and grow_ok(c)]
    best = max(alt, default=0)
    friend_why[x['id']] = (hold, best)
    return hold >= best
friend_why = {}

# 육성 자리 값 (2026-10-13 사용자: '팀에 들어갈 만큼 세지는지'로) - 자리 1시간당 '지금 팀 최약체를 넘는' 힘.
# 레벨: Lv100·진화 뒤 힘이 팀 최약체보다 낮으면 0 (라플레시아 72·쉐이미 87 은 팀 150~170 에 못 듦).
# 친밀도: Lv100 메가 가능 종(스톤 없음)을 데리고 다녀 255 → 유대 미션 → 메가스톤. 보스로라 124→메가 167 등.
# 1시간당 친밀도 [방울 없음, 평온의방울]. 10/13 실측: 곤율거니 152→161(3.6h)·가디안 96→101 / 보스로라 230→245(3.6h)·찌르호크 86→93.
# happy_measure 가 데리고 다니는 메가 후보를 2시간 넘게 지켜 저절로 고친다 (친밀도기록.json)
HAPPY_PER_H = [2.6, 4.2]
HAPPYF = os.path.join(HERE, '친밀도기록.json')
def happy_measure(P):
    try: d = json.load(open(HAPPYF, encoding='utf-8'))
    except Exception: d = {}
    now, r, live = time.time(), ([], []), {}
    for x in P:
        if not (x['onDesktop'] and x['level'] >= 100 and MEGA_OF.get(x['species']) and not holds_stone(x)): continue
        h, bell = x.get('happiness') or 0, int(x.get('held') == 'SOOTHEBELL')
        t0, h0, b0 = d.get(str(x['id'])) or (now, h, bell)
        if b0 != bell or h < h0 or h >= 255: t0, h0, b0 = now, h, bell   # 방울을 바꿨거나 가득 차면 새로 잰다
        live[str(x['id'])] = [t0, h0, b0]
        if now - t0 >= 7200: r[bell].append((h - h0) / ((now - t0) / 3600))
    json.dump(live, open(HAPPYF, 'w', encoding='utf-8'))
    for b in (0, 1):
        if r[b]:
            v = round(max(0.5, sum(r[b]) / len(r[b])), 1)
            if abs(v - HAPPY_PER_H[b]) >= 0.3: say(f"친밀도 속도 다시 잼: {'방울' if b else '방울 없음'} 1시간당 {HAPPY_PER_H[b]} → {v} ({len(r[b])}마리)")
            HAPPY_PER_H[b] = v
_bond_cache = {}
def bond_info(x):
    t, b = _bond_cache.get(x['id'], (0, None))
    if time.time() - t > 600:
        try: b = api(f"/api/bond/{x['id']}")
        except Exception: b = {}
        _bond_cache[x['id']] = (time.time(), b)
    return b or {}

def is_legend(x):
    sp = SPECIES.get(x['species']) or {}
    return bool(sp.get('legendary') or sp.get('mythical'))

def legend_due(x):
    return is_legend(x) and (x['level'] < 100 or bool(MEGA_OF.get(x['species'])) and bool(bond_info(x).get('missing')))

def holds_stone(x):
    return bool(x.get('held')) and any(m.get('megaStone') == x['held'] for m in MEGA_OF.get(x['species'], []))

def now_power(x):
    return species_power(x, x['species'], x['level'], mega=holds_stone(x))

def team_floor(P, mine):
    ids = set(api('/api/pvp/team').get('ids') or []) | {x['id'] for x in P if x['onDesktop'] and x['id'] not in mine}
    return min((now_power(x) for x in P if x['id'] in ids), default=0)

def slot_value(x, floor, rate, locked=()):
    """(자리 1시간당 팀에 쓸 만한 힘, 종류)"""
    now = now_power(x)
    if x['level'] < 100:
        return max(0, final_power(x) - max(now, floor)) / max((100 - x['level']) / rate, 1.0), '레벨'
    if MEGA_OF.get(x['species']) and not holds_stone(x):
        b = bond_info(x)
        if b.get('done') or not b.get('missing'): return 0, ''
        h = max(255 - (x.get('happiness') or 0), 0) / HAPPY_PER_H[x['id'] not in locked] + 2   # 랭크 고정 팀은 방울을 못 받음   # +2시간: 유대 미션(처치 30·포획 10) 대략
        return max(0, species_power(x, x['species'], 100) - max(now, floor)) / h, '친밀도'
    return 0, ''

def mega_name(x):
    fs = final_species(x)
    return ', '.join(m.get('kr', '') for m in MEGA_OF.get(fs, []))

grow_val = {}
def grow_note(x):
    if x['id'] in ev_ids:
        use, _ = ev_side(x); ev = x.get('evs') or {}; return f"랭크 팀 노력치 채우기 — {EV_KR[use]} {ev.get(use, 0)}/252 · 스피드 {ev.get('spe', 0)}/252, 남은 {ev_room(x)}"
    v = grow_val.get(x['id'])
    if v and v[1] == '친밀도': return f"메가 친밀도 {x.get('happiness') or 0}/255 → 유대 미션 → {mega_name(x)}, 자리 1시간당 힘 {v[0]:.1f}"
    lv, fr = evo_need(x), friend_need(x)
    if lv is not None and not (fr == 0): return f'진화까지 {lv or 1}레벨'
    if fr is not None: return '친밀도 다 참 — 레벨 하나 오르면 진화' if fr == 0 else f'친밀도 진화까지 {fr}점(약 {fr // 3 + 1}시간)'
    fs = final_species(x)
    fr = friend_need(x)
    if x['level'] >= 100 and fr: return f"친밀도 진화까지 {fr}점(약 {fr // 3 + 1}시간) → {(SPECIES.get(fs) or {}).get('kr', fs)}, 예상 전투력 {final_power(x):.0f}"
    return f"Lv{x['level']}→100" + (f", {(SPECIES.get(fs) or {}).get('kr', fs)}까지 진화" if fs != x['species'] else '') \
        + (f", 메가({mega_name(x)}) 포함" if mega_name(x) else '') + f", 예상 전투력 {final_power(x):.0f}, 개체값 {iv_sum(x)}"

def levelup_on():
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('육성_레벨업', True))
    except Exception: return True

# ---------------------------------------------------------------- 기술 배우기 자동 판단 (2026-10-09)
# 게임은 기술이 4개 찬 채 새 기술을 배우려 하면 '기술 배우기' 창으로 묻고, 답할 때까지 서버 기다림 목록(pending)에 둔다.
# 사냥기·게임 자동 배틀 모두 데미지 기술만 쓰므로(안내서 '자동 배틀의 기술 선택'), 4개 묶음의 값을
# '18타입 상대마다 가장 아픈 한 방'의 합으로 잰다 → 위력과 타입 커버를 같이 본다. 변화 기술은 0.
# 조건이 맞아야 나가는 기술은 0 (10/13: 곤율거니 힘껏펀치=맞으면 실패, 가디안 꿈먹기=잠든 상대만이 점수에 들어가 있었음)
COND_MOVES = {'DREAMEATER', 'POLTERGEIST', 'FOCUSPUNCH', 'SNORE', 'SLEEPTALK', 'LASTRESORT', 'BELCH', 'SYNCHRONOISE'}
def move_val(st, types, key, foe):
    mv = MOVES.get(key) or {}
    if mv.get('cat') == 'status' or not mv.get('power') or key in COND_MOVES: return 0
    lo, hi = mv.get('hits') or [1, 1]
    v = mv['power'] * (mv.get('acc') or 100) / 100 * st['atk' if mv['cat'] == 'physical' else 'spa']
    v *= (1.5 if mv['type'] in types else 1) * eff(mv['type'], [foe]) * (3.1 if (lo, hi) == (2, 5) else (lo + hi) / 2)
    fl = mv.get('flags') or []
    if 'recharge' in fl: v *= 0.6
    if 'charge' in fl: v *= 0.5
    if key in ('SELFDESTRUCT', 'EXPLOSION', 'MISTYEXPLOSION', 'FINALGAMBIT'): v *= 0.25
    return v

def moveset_val(st, types, keys):
    return sum(max([move_val(st, types, k, t) for k in keys] or [0]) for t in TYPES)

def learn_pick(p, new):
    """(잊을 기술 또는 '' = 안 배움, 바꾸기 전 값, 바꾼 뒤 값)"""
    cur = list(p.get('moves') or [])
    st, types = p['info']['stats'], (SPECIES.get(p['species']) or {}).get('types') or []
    before = moveset_val(st, types, cur)
    # 5개 중 하나씩 빼 보고 남은 4개가 가장 센 것을 고른다. 같으면 새 기술을 안 배우는 쪽(지금 그대로),
    # 그다음 그 기술 혼자 가장 약한 것(변화 기술 먼저) - 안 그러면 쓸모없는 '날려버리기' 대신 '물기'를 버린다
    own = lambda k: sum(move_val(st, types, k, t) for t in TYPES)
    drop = max(cur + [new], key=lambda d: (round(moveset_val(st, types, [k for k in cur + [new] if k != d]), 3), d == new, -own(d)))
    return ('' if drop == new else drop), before, moveset_val(st, types, [k for k in cur + [new] if k != drop])

learn_at = 0
def learn_step(pid):
    global learn_at
    try: on = json.load(open(CONF, encoding='utf-8')).get('기술_자동판단', True)
    except Exception: on = True
    if not on or time.time() - learn_at < 180 or battle or fight or gym_fighting(): return
    learn_at = time.time()
    kr = lambda k: (MOVES.get(k) or {}).get('kr') or k
    for p in api('/api/pokemon')['pokemon']:
        for new in list(p.get('pending') or []):
            if len(p.get('moves') or []) < 4: forget, b, a = '', 0, 0
            else: forget, b, a = learn_pick(p, new)
            r = api_post('/api/pokemon/learn', {'pokemon': p['id'], 'move': new, 'forget': forget, 'skip': forget == '' and len(p['moves']) >= 4})
            name = p['info']['name']
            if r.get('error'): say(f'기술 배우기 실패: {name} {kr(new)} — {str(r["error"])[:50]}'); break
            if forget: p['moves'] = [new if k == forget else k for k in p['moves']]; say(f'기술 배우기: {name} — {kr(new)} 배우고 {kr(forget)} 잊음 (타입별 최고 위력 합 {b:,.0f} → {a:,.0f})')
            elif len(p['moves']) < 4: p['moves'].append(new); say(f'기술 배우기: {name} — {kr(new)} 배움 (빈자리)')
            else: say(f"기술 배우기: {name} — {kr(new)} 안 배움 (지금 기술이 더 셈: {', '.join(kr(k) for k in p['moves'])})")

# ---------------------------------------------------------------- 기술머신 자동 (2026-10-13)
# 기술머신은 써도 안 없어진다(게임 ui_tms) → 하루 한 번, 가진 공격 기술머신으로 2% 넘게 세지는 포켓몬에게 가르친다.
# 잣대는 learn_pick 과 같다(실제 능력치, 18타입 최고 한 방 합). 빼는 것: 고정한 랭크 팀(손으로 맞춤), 설정 '기술머신_제외종'(기본 쉐이미)
tm_day = ''
TM_DAY = os.path.join(HERE, '기술머신_점검일.txt')
def tm_best(cur, new, vals):
    # 가장 좋은 기술 4개 조합. 모든 타입에서 다른 기술보다 못한 새 기술은 답을 못 바꾸므로 빼고, 값은 표로 한 번만 계산 (11/03: 포켓몬당 조합 수만 개라 40분 걸렸다)
    import itertools
    tbl = {k: vals(k) for k in cur + new}
    keep = list(cur)
    for k in sorted(new, key=lambda k: -sum(tbl[k])):
        if not any(all(a >= b for a, b in zip(tbl[j], tbl[k])) for j in keep): keep.append(k)
    return max(itertools.combinations(keep, min(4, len(keep))), key=lambda cm: (round(sum(map(max, zip(*(tbl[k] for k in cm)))), 3), sum(k in cur for k in cm)))

def tm_step(pid):
    global tm_day
    import itertools
    try: c = json.load(open(CONF, encoding='utf-8'))
    except Exception: return
    today = time.strftime('%Y-%m-%d')
    if not tm_day:   # 11/03: 재시작해도 하루 1번 — 점검 중 감시기(기록 20분 멈춤)가 끄면 켤 때마다 처음부터 해 11/01~02 71번 멈췄다
        try: tm_day = open(TM_DAY, encoding='utf-8').read().strip()
        except OSError: pass
    if not c.get('기술머신_자동', True) or tm_day == today or battle or fight or gym_fighting(): return
    tm_day = today
    with open(TM_DAY, 'w', encoding='utf-8') as f: f.write(today)
    skip = set(c.get('기술머신_제외종', ['SHAYMIN']))
    lock = set(api('/api/pvp/team').get('ids') or []) if rank_locked() else set()
    can = {}   # 포켓몬 id → {기술: 기술머신 번호}
    for x in api('/api/tms').get('tms') or []:
        if not x['have'] or x['cat'] == 'status': continue
        for q in api(f"/api/tms/{x['no']}/learners").get('learners') or []:
            if not q.get('known'): can.setdefault(q['id'], {})[x['move']] = x['no']
    kr = lambda k: (MOVES.get(k) or {}).get('kr') or k
    n = 0
    for p in api('/api/pokemon')['pokemon']:
        if p['id'] not in can or p['id'] in lock or p['species'] in skip or p.get('pending'): continue
        st, types, cur = p['info']['stats'], (SPECIES.get(p['species']) or {}).get('types') or [], list(p.get('moves') or [])
        best = tm_best(cur, list(can[p['id']]), lambda k: [move_val(st, types, k, t) for t in TYPES])
        b, a = moveset_val(st, types, cur), moveset_val(st, types, best)
        if a <= b * 1.02: continue
        new, drop = [k for k in best if k not in cur], [k for k in cur if k not in best]
        for i, mv in enumerate(new):
            r = api_post('/api/tms/use', {'no': can[p['id']][mv], 'pokemon': p['id'], 'forget': drop[i] if i < len(drop) else ''})
            if not r.get('ok'): say(f"기술머신 실패: {p['info']['name']} {kr(mv)} — {str(r.get('detail') or r.get('error') or r)[:50]}"); break
        else:
            n += 1
            say(f"기술머신: {p['info']['name']} +{'·'.join(map(kr, new))}" + (f" −{'·'.join(map(kr, drop))}" if drop else '') + f" ({a / max(b, 1) * 100 - 100:+.0f}%)")
    say(f'기술머신 점검: {n}마리 배움' if n else '기술머신 점검: 더 세질 포켓몬 없음')

# ---------------------------------------------------------------- 랭크 팀 자동 편성 + 랜덤 배틀 (2026-10-09)
# 랜덤 배틀(랭킹 탭): 하루 20판(한국 자정), 30초 간격, 상대가 꺼져 있어도 서버가 바로 계산해 끝낸다.
# 레벨은 50 넘으면 50으로 내려 싸우고(pvp.capped), 상대는 팀 전력(종족값 x 레벨50상한)^1.5 합이 비슷한 사람(find_opponent).
# 그래서 같은 전력 안에서 실제로 센 팀 - 능력치(개체값·노력치·성격)·기술·타입 커버가 좋은 팀이 이긴다.
def stats50(p):
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')   # 게임의 능력치 공식(common/pokelogic)
    if root not in sys.path: sys.path.insert(0, root)
    from common import pokelogic as PL
    base = (SPECIES.get(p['species']) or {}).get('base') or {}
    ivs = PL.effective_ivs(p)   # 병뚜껑(하이퍼트레이닝) 반영
    lv = min(50, p['level'])
    return {k: PL.calc_stat(k, base.get(k, 50), (ivs or {}).get(k, 0), (p.get('evs') or {}).get(k, 0), lv, p.get('nature')) for k in ('hp', 'atk', 'def', 'spa', 'spd', 'spe')}

def nature_up(pm):
    # 랭크 팀에 같은 종이 있고, 그 개체가 야생의 성격을 가졌다면 랭크 점수가 3% 넘게 오르면 '성격 ○ → △ (+n%)' 문구, 아니면 ''
    nat = pm.get('nature')
    if not nat: return ''
    ids = set(api('/api/pvp/team').get('ids') or [])
    for p in (api('/api/pokemon') or {}).get('pokemon', []):
        if p['id'] in ids and p['species'] == pm.get('species') and p.get('nature') != nat:
            a, b = sum(rank_val(p).values()), sum(rank_val(dict(p, nature=nat)).values())
            if a > 0 and b / a > 1.03: return f"랭크 팀 같은 종 — 성격 {p.get('nature')} → {nat} (+{(b / a - 1) * 100:.0f}%) 라 잡음"
    return ''

def rank_val(p):
    # 타입별 (가장 아픈 한 방 x 버티기 x 빠르기) - core_recheck 의 val 과 같은 꼴, Lv50 능력치로
    st, types, lv = stats50(p), (SPECIES.get(p['species']) or {}).get('types') or [], min(50, p['level'])
    bulk = (st['hp'] * (st['def'] + st['spd']) / 2) ** 0.5 * (1 + st['spe'] / 400) / 100
    out = {}
    for t in TYPES:
        if t == 'STELLAR': continue
        best = 0
        for k in p.get('moves') or []:
            mv = MOVES.get(k) or {}
            if mv.get('cat') == 'status' or not mv.get('power') or k in COND_MOVES: continue
            lo, hi = mv.get('hits') or [1, 1]
            f = (0.25 if k in ('SELFDESTRUCT', 'EXPLOSION', 'MISTYEXPLOSION', 'FINALGAMBIT') else 1) * (0.5 if 'charge' in mv.get('flags', []) else 1) * (0.6 if 'recharge' in mv.get('flags', []) else 1)
            a = st['atk' if mv['cat'] == 'physical' else 'spa']
            best = max(best, ((2 * lv / 5 + 2) * mv['power'] * a / 150 / 50 + 2) * (1.5 if mv['type'] in types else 1) * eff(mv['type'], [t]) * (mv.get('acc') or 100) / 100 * (3.1 if (lo, hi) == (2, 5) else (lo + hi) / 2) * f)
        out[t] = best * bulk / max(max(eff(t, types), 0.25), 0.25)
    return out

def rank_pick(P, w=None, avoid=()):
    import itertools
    legend = lambda p: bool((SPECIES.get(p['species']) or {}).get('legendary'))
    natk = lambda p: sum(1 for k in p.get('moves') or [] if (MOVES.get(k) or {}).get('cat') not in (None, 'status') and (MOVES.get(k) or {}).get('power'))
    # Lv50 미만은 낮은 레벨 그대로 싸워 약하다. 공격 기술 3개 이상 - 2개짜리(네이티오 희망사항·파워스왑, 찌르호크 목숨걸기)를 넣은
    # 10/10 0시 팀이 19패 1승 했다. 서버 자동 배틀은 변화 기술에 턴을 버린다
    cand = [p for p in P if p['level'] >= 50 and natk(p) >= 3]
    V = {p['id']: rank_val(p) for p in cand}
    def score(team):
        sc = 0
        for t in V[team[0]['id']] if team else []:
            vs = sorted((V[p['id']][t] for p in team), reverse=True) + [0, 0]
            sc += (vs[0] + 0.5 * vs[1] + 0.25 * vs[2]) * ((w or {}).get(t, 1))   # w: 최근 진 상대 타입에 무게
        return sc
    pool = sorted(cand, key=lambda p: -sum(V[p['id']].values()))[:14]
    k = min(6, len(pool))
    bad = set(rank_rec().get('blocked') or []) | set(avoid)   # 실제로 많이 진 조합은 다시 안 고른다
    best = max((c for c in itertools.combinations(pool, k) if sum(map(legend, c)) <= 1 and team_key(c) not in bad), key=score, default=())
    best = sorted(best, key=lambda p: -sum(V[p['id']].values()))   # 가장 센 것이 선봉
    return best, score, V

def api_put(path, body):
    tok = json.load(open(os.path.join(GDIR, 'session.json'), encoding='utf-8'))['token']
    base = json.load(open(os.path.join(GDIR, 'settings.json'), encoding='utf-8'))['server']
    return _http.put(base + path, json=body, headers={'Authorization': 'Bearer ' + tok, 'Accept': 'application/json'}, timeout=15).json()

# 팀별 실제 승패 (2026-10-10): 점수는 이론값이라, 바꾼 팀이 실제로 지면 되돌린다
RANK_REC = os.path.join(HERE, '랭크팀_승패.json')
def team_key(ms): return ','.join(str(i) for i in sorted(m if isinstance(m, int) else m['id'] for m in ms))
def rank_locked():   # 10/13 사용자: 기술머신·도구까지 맞춘 팀을 직접 정함 → 자동 재선정·되돌림 안 함 (끄려면 설정에서 지움)
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('랭크팀_고정'))
    except Exception: return True   # 설정을 못 읽으면 바꾸지 않는 쪽
def rank_rec():
    try: return json.load(open(RANK_REC, encoding='utf-8'))
    except Exception: return {}
def rank_record(ids, res):
    d = rank_rec(); k = team_key(ids); w, l = d.setdefault('rec', {}).get(k, [0, 0])
    d['rec'][k] = [w + (res == 'win'), l + (res == 'lose')]
    json.dump(d, open(RANK_REC, 'w', encoding='utf-8'), ensure_ascii=False)
    w, l = d['rec'][k]
    if w + l >= 5 and w / (w + l) < 0.35 and not rank_locked() and d.get('prev') and team_key(d['prev']) != k \
            and team_key(d['prev']) not in (d.get('blocked') or []):   # 전 팀도 진 팀이면 안 되돌린다   # 바꾼 팀이 5판 이상 35% 미만 → 전 팀으로
        d.setdefault('blocked', []).append(k)
        r = api_put('/api/pvp/team', {'ids': d['prev']})
        json.dump(d, open(RANK_REC, 'w', encoding='utf-8'), ensure_ascii=False)
        say(f"랭크 팀 되돌림: 바꾼 팀이 {w}승 {l}패 → 전 팀으로" + (f" (실패: {str(r.get('error') or r.get('detail'))[:50]})" if r.get('error') or r.get('detail') else ''))

rank_day = ''
def rank_team_step():
    global rank_day
    today = time.strftime('%Y-%m-%d')
    if rank_day == today: return
    rank_day = today
    if rank_locked(): say('랭크 팀 점검: 고정됨(조종판설정 랭크팀_고정) — 그대로'); return
    P = api('/api/pokemon')['pokemon']; byid = {p['id']: p for p in P}
    best, score, V = rank_pick(P)
    if not best: return
    cur = [byid[i] for i in (api('/api/pvp/team').get('ids') or []) if i in byid and i in V]
    cs, bs = score(cur) if cur else 0, score(best)
    names = lambda ms: ', '.join(f"{p['info']['name']} Lv{p['level']}" for p in ms)
    if cur and [p['id'] for p in cur] == [p['id'] for p in best]: say(f'랭크 팀 점검: 지금 팀({names(cur)})이 가장 좋음 — 그대로'); return
    if cur and len(cur) >= len(best) and bs < cs * 1.03: say(f'랭크 팀 점검: 지금 팀({names(cur)})과 거의 같음 — 그대로'); return
    r = api_put('/api/pvp/team', {'ids': [p['id'] for p in best]})
    if not (r.get('error') or r.get('detail')) and cur:
        d = rank_rec(); d['prev'] = [p['id'] for p in cur]; json.dump(d, open(RANK_REC, 'w', encoding='utf-8'), ensure_ascii=False)
    if r.get('error') or r.get('detail'): say(f"랭크 팀 바꾸기 실패: {str(r.get('error') or r.get('detail'))[:60]}"); return
    say(f"랭크 팀 바꿈({bs / max(cs, 1) * 100 - 100:+.0f}%): {names(cur) or '없음'} → {names(best)} (Lv50 기준 능력치·기술·타입 커버)")

pvp_at, pvp_done_day, pvp_gap = 0, '', 0
def pvp_step(pid):
    global pvp_at, pvp_done_day
    if LITE: return   # 공유판: 랜덤 배틀 자동 없음 (10/08 사용자)
    try: want = max(0, min(20, int(json.load(open(CONF, encoding='utf-8')).get('랜덤배틀_하루', 20))))
    except Exception: want = 20
    today = time.strftime('%Y-%m-%d')
    # 한꺼번에 20판 몰아 하지 않고 3~4분에 한 판 (2026-10-10 사용자 결정) - 3연패하면 그 사이 팀을 고쳐 다시 붙는다
    if not want or pvp_done_day == today or time.time() - pvp_at < pvp_gap or battle or fight: return
    pvp_at = time.time()
    f = api('/api/pvp/pending').get('fight') or {}
    used = int(f.get('foughtToday') or 0)
    practice = False
    if used >= want or not f.get('left'):
        # 11/09 사용자: 20판 뒤 연습판(점수 없음, 이기면 100원)으로 하루 상금 상한(1만 원)까지 채운다 - 서버엔 practice=1 로 알려야 걸린다
        me_ = ((api('/api/pvp/ranking') or {}).get('me') or {}) if used >= 20 and conf_on('연습판_자동') else {}
        if not me_ or (me_.get('earnedToday') or 0) >= (me_.get('dailyCap') or 0):
            pvp_done_day = today; say(f"랜덤 배틀 오늘 {used}판 — 끝 (목표 {want}판" + (f", 상금 {me_.get('earnedToday'):,}/{me_.get('dailyCap'):,}원)" if me_ else ')')); return
        practice = True
    if f.get('randomCooldownLeft'): return
    rank_team_step()
    r = api_post('/api/pvp/random', {'practice': 1} if practice else {})
    if r.get('detail') or r.get('error'):
        msg = str(r.get('detail') or r.get('error'))
        if '내일' in msg: pvp_done_day = today
        globals()['pvp_gap'] = 120   # 못 하면 2분 뒤 다시 - 예전엔 매초 다시 걸었다(10/16 저렙 시험: 상대 없음 1초마다)
        say(f'랜덤 배틀 못 함: {msg[:60]}'); return
    me = r.get('a') or {}
    try: rank_record(api('/api/pvp/team').get('ids') or [], me.get('result'))
    except Exception as e: say(f'랭크 팀 승패 기록 실패: {e}')
    res = {'win': '승', 'lose': '패', 'draw': '무'}.get(me.get('result'), me.get('result'))
    foes = pvp_foes()
    say(f"{'연습판' if practice else '랜덤 배틀'} {used + 1}/{want}: {res} ({r.get('turns')}턴) · RP {me.get('rp')}({me.get('rpDelta', 0):+d}) · 상금 {me.get('reward', 0)}원"
        + (f" · 상대 {', '.join((SPECIES.get(x) or {}).get('kr', x) for x in foes)}" if foes else ''))
    globals()['pvp_gap'] = random.uniform(180, 240)
    pvp_learn(me.get('result'), foes)

def pvp_foes():
    # 방금 판의 상대 팀(종 이름). 대전 기록의 첫 이벤트 'teams' 에 양쪽 6마리가 있다
    try:
        rec = api('/api/pvp/records?limit=1'); rec = [v for v in rec.values() if isinstance(v, list)][0][0]
        ev = api(f"/api/pvp/match/{rec['matchId']}").get('events') or []
        t = next(e for e in ev if e.get('t') == 'teams')
        return [m['species'] for m in t.get('foe') or []]
    except Exception: return []

def pvp_learn(result, foes):
    # 최근 판 기록을 남기고, 3연패면 진 판 상대들의 타입을 세어 그 타입에 강한 조합으로 바꾼다
    d = rank_rec(); log = d.setdefault('log', [])
    log.append({'at': time.strftime('%m-%d %H:%M'), 'result': result, 'foes': foes, 'team': api('/api/pvp/team').get('ids') or []})
    d['log'] = log[-40:]; json.dump(d, open(RANK_REC, 'w', encoding='utf-8'), ensure_ascii=False)
    tail = d['log'][-3:]
    if len(tail) < 3 or any(x['result'] != 'lose' for x in tail): return
    if rank_locked(): return   # 랭크팀_고정이면 3연패여도 안 바꿈 (10/16: 고정인데 하루 4번 바뀜 - 10승6패 팀이 0시 3연패로 빠짐)
    cnt = {}
    for x in tail:
        for sp in x['foes']:
            for t in (SPECIES.get(sp) or {}).get('types') or []: cnt[t] = cnt.get(t, 0) + 1
    if not cnt: return
    top = sorted(cnt, key=lambda t: -cnt[t])[:3]
    w = {t: 1 + 2 * cnt.get(t, 0) / max(cnt.values()) for t in TYPES}   # 많이 만난 타입일수록 최대 3배
    cur = tail[-1]['team']
    P = api('/api/pokemon')['pokemon']
    best, score, V = rank_pick(P, w, avoid=[team_key(cur)])
    if not best: return
    r = api_put('/api/pvp/team', {'ids': [p['id'] for p in best]})
    if r.get('error') or r.get('detail'): say(f"3연패 팀 바꾸기 실패: {str(r.get('error') or r.get('detail'))[:60]}"); return
    d = rank_rec(); d['prev'] = cur; d.setdefault('blocked', []).append(team_key(cur)); d['log'].append({'at': time.strftime('%m-%d %H:%M'), 'result': 'reset', 'foes': [], 'team': [p['id'] for p in best]})
    json.dump(d, open(RANK_REC, 'w', encoding='utf-8'), ensure_ascii=False)
    kr = lambda t: (TYPES.get(t) or {}).get('kr', t)
    say(f"랜덤 배틀 3연패 분석: 진 상대들에 {', '.join(f'{kr(t)} {cnt[t]}' for t in top)} 타입이 많음 → 그 타입에 강한 조합으로 바꿈: "
        + ', '.join(f"{p['info']['name']} Lv{p['level']}" for p in best))

# ---------------------------------------------------------------- 설정 감시·시간별 지표 (2026-10-10)
# 조종판 설정이 바뀌면 기록에 남긴다 (13:2x 육성 슬롯이 모르게 꺼져 Lv100 들이 1시간 넘게 자리 차지).
# 매시 정각 지표를 시간별_지표.json 에 쌓는다 - 시간별 점검·자리 수 비교의 근거
conf_seen, metric_hour = None, None
METRIC = os.path.join(HERE, '시간별_지표.json')
HUNT_LOG = os.path.join(HERE, '사냥기록.txt')
def conf_watch():
    global conf_seen
    try: c = json.load(open(CONF, encoding='utf-8'))
    except Exception: return
    keys = ('육성슬롯', '육성_자리수', '관장_수련', '포획_시도횟수', '기술_자동판단', '육성_레벨업', '랜덤배틀_하루', '돈_모드', '탐험_자동')
    cur = {k: c.get(k) for k in keys}
    if conf_seen is not None and cur != conf_seen:
        say('설정 바뀜: ' + ', '.join(f'{k} {conf_seen.get(k)}→{cur[k]}' for k in keys if cur[k] != conf_seen.get(k)))
    conf_seen = cur

# 10/20 사용자: 지금 쓸모 순 - 유적(기술머신 x1.6, 358장 중 73장뿐) > 동굴(진화 도구 4종) > 바다·화산(번갈아) > 설산 > 숲(열매는 팔기만 함)
EXP_ORDER = {'ruins': 0, 'cave': 1, 'mine': 2, 'sea': 3, 'volcano': 3, 'snow': 4, 'forest': 5}   # 11/09 사용자: 광산(2.2.2, 골드만 8시간 대성공 4,000원)을 셋째 칸에
exp_flip = 0   # 같은 순위(바다·화산)는 보낼 때마다 번갈아
EXP_HOURS = 8   # 탐험은 8시간 (10/13 사용자). 8시간 대성공 = 물건 3개·귀한 것 잘 나옴
exp_at = 0
exp_said = ''
def expedition_on():
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('탐험_자동', True))
    except Exception: return True

class ExpRules:
    # 게임 common/expedition 의 규칙 중 쓰는 것만 (게임 코드가 없는 공유판용, 1.10.5 기준 — 바뀌면 게임 쪽 것이 우선)
    PLACES = [{'id': i, 'kr': k, 'types': t} for i, k, t in (('forest', '숲', ['GRASS', 'BUG', 'POISON']), ('cave', '동굴', ['ROCK', 'GROUND', 'FIGHTING']),
              ('sea', '바다', ['WATER', 'FLYING', 'ELECTRIC']), ('volcano', '화산', ['FIRE', 'DRAGON', 'STEEL']), ('snow', '설산', ['ICE', 'NORMAL', 'FAIRY']),
              ('ruins', '유적', ['PSYCHIC', 'GHOST', 'DARK']))]
    @staticmethod
    def score(level, types, place_id):
        m = len(set(types) & set(next(p['types'] for p in ExpRules.PLACES if p['id'] == place_id)))
        return min(100, int(level * 0.6 + (40 if m >= 2 else 30 if m else 0)))
    @staticmethod
    def grade(points): return 'great' if points >= 75 else 'good' if points >= 45 else 'normal'
    @staticmethod
    def item_count(hours, grade_id): return {2: (1, 1, 1), 4: (2, 1, 1), 8: (3, 2, 1)}[hours][('great', 'good', 'normal').index(grade_id)]

EXP_GROW = ('lore', 'luck', 'haul', 'speed', 'charm')   # 11/05 사용자: 남은 성장치 자동. 호기심(기술머신 +10%/점) 먼저, 10점 차면 눈썰미(희귀 +5%)…
def exp_grow(st, away):
    # 탐험 레벨이 오르면 생기는 성장치(능력마다 10점까지). 나가 있는 동안은 서버가 거절하므로 돌아온 포켓몬만
    for pid, g in (st.get('growth') or {}).items():
        f = g.get('free') or 0
        if not f or int(pid) in away: continue
        add = {}
        for s in EXP_GROW:
            k = min(f, 10 - (g.get('stats') or {}).get(s, 0))
            if k > 0: add[s] = k; f -= k
            if not f: break
        if add:
            r = api_post('/api/expedition/grow', {'pokemon': int(pid), 'add': add})
            say(f"탐험 성장치: {r.get('message') or r.get('detail') or r.get('error') or add}")

def expedition_step():
    # 탐험 파견 자동 (10/13 사용자): 돌아온 보따리를 받고, 빈 칸마다 '대성공'이 나는 포켓몬·곳 짝을 골라 8시간 보낸다.
    # 성공도는 보낼 때 레벨·타입으로 정해진다 (게임 common/expedition, 서버와 같은 규칙): 레벨×0.6 + 타입 하나 맞으면 30·둘이면 40,
    # 75 이상 = 대성공. 대성공이면 점수가 더 높아도 물건·등급은 같으므로, 같은 곳이 겹치지 않게(특산물이 곳마다 다름) 나눠 보낸다.
    # 박스의 Lv100 을 먼저 쓴다 (육성 자리로 올라올 Lv100 전 포켓몬이 탐험에 묶이지 않게). 다녀온 포켓몬은 24시간 쉰다
    global exp_at, exp_said, exp_flip
    if not expedition_on() or time.time() < exp_at: return
    exp_at = time.time() + 300
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
    if root not in sys.path: sys.path.insert(0, root)
    try: from common import expedition as E
    except ImportError: E = ExpRules   # 공유판 윈도우(_game_pyc 없음)
    st = api('/api/expedition')
    if st.get('ready'):
        r = api_post('/api/expedition/claim', {})
        got = [f"{i.get('kr') or i.get('label') or i.get('id')}" + (f" {i['count']}개" if (i.get('count') or 1) > 1 else '')
               for c in (r.get('claimed') or []) for i in (c.get('items') or [])]
        say(f"탐험 보따리 받음: {', '.join(got) or r.get('message') or '빈 보따리'}")
        st = api('/api/expedition')
    out = st.get('out') or []
    away = {o['pokemon']['id'] for o in out}
    exp_grow(st, away)
    rest = {int(k) for k, g in (st.get('growth') or {}).items() if (g.get('rest') or 0) > 0}
    rank = set(api('/api/pvp/team').get('ids') or []) | oly_ids()   # 올림픽 신청한 포켓몬도 남김. 서버: 랭크 팀은 탐험 못 감 (10-14 리자몽 실패로 칸이 8시간 비었음)
    P = [p for p in api('/api/pokemon')['pokemon'] if not p.get('onDesktop') and p['id'] not in away and p['id'] not in rest and p['id'] not in rank and not legend_due(p)]   # 10/20: Lv100 전 전설은 육성 자리로 (10/24 메가 유대 남은 전설도)
    used = [o['place'] for o in out]
    for _ in range(st.get('free') or 0):
        pairs = [(E.score(p['level'], (SPECIES.get(p['species']) or {}).get('types') or [], pl['id']), p, pl) for p in P for pl in E.PLACES]   # info.types 는 한글('물') - 규칙은 'WATER'
        # 대성공 감이 없으면 성공·보통으로라도 보낸다 (10/16 저렙 시험: Lv75 미만뿐이면 탐험 칸이 늘 비었음)
        gd = next((g for g in ('great', 'good', 'normal') if any(E.grade(x[0]) == g for x in pairs)), None)
        pairs = [x for x in pairs if E.grade(x[0]) == gd]
        if not pairs:
            if exp_said != 'none': say('탐험: 보낼 포켓몬이 박스에 없음 — 빈 칸 그대로'); exp_said = 'none'
            break
        sc, p, pl = min(pairs, key=lambda x: (x[2]['id'] in used, EXP_ORDER.get(x[2]['id'], 9), (x[2]['id'] == 'volcano') != exp_flip, x[1]['level'] < 100, x[1]['level'], -x[0]))   # 같은 등급이면 낮은 레벨부터 (센 것은 육성·주력에 남김)
        r = api_post('/api/expedition/send', {'pokemon': p['id'], 'place': pl['id'], 'hours': EXP_HOURS})
        if r.get('error') or r.get('detail'):
            say(f"탐험 보내기 실패: {p['info']['name']} → {pl['kr']}: {str(r.get('detail') or r.get('error'))[:60]}")
            exp_at = time.time() + 300; return   # 빈 칸이 nextIn(최대 1시간) 동안 묵지 않게 5분 뒤 다시
        say(f"탐험 보냄: {p['info']['name']} Lv{p['level']} → {pl['kr']} {EXP_HOURS}시간 ({ {'great': '대성공', 'good': '성공', 'normal': '보통'}[gd]} {sc}점, {f"골드 {E.gold_for(EXP_HOURS, gd):,}원" if getattr(E, 'is_gold', lambda _: False)(pl['id']) else f"물건 {E.item_count(EXP_HOURS, gd)}개"})")
        if EXP_ORDER.get(pl['id']) == 3: exp_flip ^= 1
        exp_said = ''; used.append(pl['id']); P.remove(p); st = r if 'free' in r else st
    if st.get('nextIn'): exp_at = time.time() + min(max(60, st['nextIn'] + 5), 3600)

# ---------------------------------------------------------------- 포켓몬과 집중하기 · 친구 집 놀러 가기 (11/05 사용자, 게임 2.2.0)
# 집중: 25분 세트마다 고른 능력 노력치 +5, 하루 40(8세트). 집중 중에도 서버 직접 사냥·관장은 그대로 된다(11/05 시험).
#   게임이 1분마다 맥박을 보내지만 게임이 꺼져 있어도 이어지게 사냥기도 보낸다 (3분 끊기면 서버가 닫음).
#   노력치 받을 바탕화면 포켓몬(지킬 능력에 빈칸)이 없으면 주력으로 '기록만' 8세트 (업적 볼·연속 일수).
# 놀러 가기: 집중 중엔 서버가 거절 → 하루 집중을 마친 뒤 하루 한 번, 남는 흔한 열매 1개를 보따리로 두고 VISIT_MIN 분 뒤 돌아온다.
#   놀러 간 동안 친구 파티가 내 화면을 돌아다닌다(11/05 사용자 '포켓몬이 많아졌어') → 짧게. 친구가 두고 간 보따리는 받는다.
FOCUS_SETS, VISIT_MIN, VISIT_IDLE = 8, 5, 20 * 60   # 11/05 사용자 'PC 안 쓰는 시간대에 방문' - 잠김 또는 20분 입력 없을 때만, 돌아오면 바로 끝
FOCUS_KR = {'hp': 'HP', 'atk': '공격', 'def': '방어', 'spa': '특공', 'spd': '특방', 'spe': '스피드'}
focus_at, focus_sets = 0, -1
FOCUS_PID = None
VISIT_DAY = os.path.join(HERE, '놀러가기_날짜.txt')
def focus_pick():
    P = [x for x in api('/api/pokemon')['pokemon'] if x.get('onDesktop')]
    lock = set(api('/api/pvp/team').get('ids') or [])
    c = []
    for x in P:
        ev = x.get('evs') or {}
        if x['id'] not in lock or sum(ev.get(k, 0) for k in ev_keep(x)) >= 510: continue   # 11/11: 지킬 능력만 셈 — 군더더기는 ev_step 이 깎음(자마젠타 스피드 67인데 합 510이라 특공 '기록만' 하던 것)   # 육성 자리는 Lv100 되면 빠져야 하고 배틀로 노력치가 금방 참 → 랭크 팀(주력)만
        for st in sorted(ev_keep(x), key=lambda k: ev.get(k, 0)):
            if ev.get(st, 0) < 252: c.append((x['id'] not in lock, -(252 - ev.get(st, 0)), x, st)); break
    if c: x, st = min(c, key=lambda t: t[:2])[2:]; return x, st, False
    x = next((x for x in P if x['id'] in lock), P[0] if P else None)   # 주력은 바탕화면에서 안 빠진다 (빠지면 집중이 끝남)
    # 11/09: Lv100 은 관장전으로 노력치 510 이 다 차 집중 몫(+5)이 늘 0 → 기록만 하는 날은 능력을 날마다 바꿔 '능력별 25세트' 업적을 노린다
    return (x, list(FOCUS_KR)[time.localtime().tm_yday % 6], True) if x else (None, None, True)
def focus_done_today(f):
    return (f.get('todayEv') or 0) >= (f.get('dailyEv') or 40) or open_day(VISIT_DAY + '.focus') == time.strftime('%Y-%m-%d')
def open_day(path):
    try: return open(path, encoding='utf-8').read().strip()
    except Exception: return ''
def focus_step():
    global focus_at, focus_sets, FOCUS_PID
    if LITE or not conf_on('집중_자동'): FOCUS_PID = None; return
    if time.time() < focus_at: return
    focus_at = time.time() + 60
    f = api('/api/focus') or {}; run = f.get('running')
    FOCUS_PID = run['pokemon']['id'] if run else None
    if run:
        api_post('/api/focus/beat', {})
        if run.get('sets', 0) != focus_sets and focus_sets >= 0:
            say(f"집중: {run['pokemon']['name']} {run.get('statKr')} {run.get('sets')}세트 · 오늘 노력치 {f.get('todayEv')}/{f.get('dailyEv')}")
        focus_sets = run.get('sets', 0)
        if (f.get('todayEv') or 0) >= (f.get('dailyEv') or 40) or run.get('sets', 0) >= FOCUS_SETS:
            r = api_post('/api/focus/stop', {}); focus_sets = -1; FOCUS_PID = None
            open(VISIT_DAY + '.focus', 'w', encoding='utf-8').write(time.strftime('%Y-%m-%d'))
            say(f"집중 마침: {r.get('message') or ''}")
        return
    if focus_done_today(f) or (api('/api/visit') or {}).get('visit'): return
    x, st, only_log = focus_pick()
    if not x: return
    r = api_post('/api/focus/start', {'pokemon': x['id'], 'stat': st})
    if r.get('running'):
        focus_sets = 0; FOCUS_PID = x['id']
        say(f"집중 시작: {x['info']['name']} {FOCUS_KR[st]}" + (' (노력치 빈칸 없음 — 기록만)' if only_log else f" (지금 {x['evs'][st]}/252)"))
    elif r.get('error') or r.get('detail'): focus_at = time.time() + 300   # 배틀 중 등 - 5분 뒤 다시
visit_at, visit_end = 0, 0
def pc_away(sec): return locked_now() or idle_s() >= sec
def visit_gift():
    sh = {i['id']: i for i in (api('/api/shop') or {}).get('items') or []}
    bag = (api('/api/bag') or {}).get('bag') or {}
    c = [(sh[k].get('sell', 0), k) for k, n in bag.items() if k in sh and n >= 3 and sh[k].get('holdable') and sh[k].get('cat') != 'ball'
         and sh[k].get('rarity') in ('common', 'uncommon') and k not in SELL_NEVER and k not in EV_BERRY.values()]
    return min(c)[1] if c else None
def visit_step():
    global visit_at, visit_end
    if LITE or time.time() < visit_at or not conf_on('놀러가기_자동'): return
    visit_at = time.time() + 60
    st = api('/api/visit') or {}; v = st.get('visit')
    if v:
        if v.get('role') == 'host':   # 친구가 놀러 와서 두고 간 보따리
            for b in v.get('bundles') or []:
                r = api_post('/api/visit/claim', {'bundle': b['id']})
                say(f"친구 보따리 받음: {b.get('from')} · " + ', '.join(f"{i.get('kr')} {i.get('count')}개" for i in b.get('items') or []) + f" ({r.get('message') or r.get('error') or ''})")
        elif v.get('role') == 'guest' and visit_end and (time.time() >= visit_end or not pc_away(60)):
            api_post('/api/visit/end', {}); visit_end = 0; say(f"놀러 가기 끝: {v.get('partner')} 님 집에서 돌아옴" + ('' if pc_away(60) else ' (PC 다시 씀)'))
        return
    day = time.strftime('%Y-%m-%d')
    if open_day(VISIT_DAY) == day or not pc_away(VISIT_IDLE) or not focus_done_today(api('/api/focus') or {}): return
    fr = [x for x in (api('/api/friends') or {}).get('friends') or [] if x.get('online') and x.get('visitable') and not x.get('visitBusy') and not x.get('visitFocus')]
    if not fr: return
    x = fr[0]; g = visit_gift(); items = [{'id': g, 'count': 1}] if g else []
    r = api_post('/api/visit/start', {'friend': x['id'], 'items': items, 'look': 0})
    if not r.get('visit'): say(f"놀러 가기 실패: {x['name']} — {str(r.get('error') or r.get('detail'))[:60]}"); visit_at = time.time() + 1800; return
    open(VISIT_DAY, 'w', encoding='utf-8').write(day); visit_end = time.time() + VISIT_MIN * 60
    if items:
        d = api_post('/api/visit/drop', {'items': items})
        g = (d.get('visit') or {}).get('bundles') and f" · 보따리({sh_kr(g)}) 둠" or ' · 보따리 못 둠'
    else: g = ''
    say(f"놀러 감: {x['name']} 님 집 ({VISIT_MIN}분){g}")
def sh_kr(k):
    return next((i.get('kr') for i in (api('/api/shop') or {}).get('items') or [] if i['id'] == k), k)

# ---------------------------------------------------------------- 포스크탑 올림픽 (11/09 사용자, 게임 2.3.0)
# 11/15 0시부터 종목마다(경기 날 14시 전까지 바꿀 수 있음) 기대 점수가 가장 높은 포켓몬으로 신청. 기록 = 종 · 몸무게 · 타입 ·
# 특성 · 그날 응원 · 운 (노력치 · 개체값 · 레벨 무관) - 게임 common/olympics.mods 로 직접 센다. 많이 낸 종은 피로로 깎인다
# (신청 창 'share' 상위 5종) → 3시간마다 다시 보고 더 나은 게 생기면 바꾼다. 신청한 포켓몬은 탐험 · 놓아주기에서 지킨다.
oly_at, _oly = 0, {'at': 0, 'ids': set()}
def oly_ids():
    if time.time() - _oly['at'] > 600:
        _oly['at'] = time.time()
        try: _oly['ids'] = {(e.get('entry') or {}).get('pokemon', {}).get('id') for e in (api('/api/olympics') or {}).get('events') or [] if e.get('entry')} - {None}
        except Exception: pass
    return _oly['ids']
def oly_step():
    global oly_at
    if LITE or time.time() < oly_at or not conf_on('올림픽_자동'): return
    oly_at = time.time() + 3 * 3600
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
    if root not in sys.path: sys.path.insert(0, root)
    try: from common import olympics as O
    except ImportError: return   # 게임 규칙 코드(2.3.0+) 없는 PC
    st = api('/api/olympics') or {}
    evs = [e for e in st.get('events') or [] if e.get('canEnter')]
    if not evs: oly_at = time.time() + min(max(60, (st.get('openIn') or 3600) + 5), 3 * 3600); return
    pct = O.build_pct(list(SPECIES.values()))
    for e in evs:
        c = api(f"/api/olympics/candidates?event={e['key']}") or {}
        kr2int = {sp.get('kr'): k for k, sp in SPECIES.items()}
        sh = {kr2int.get(x['species']): x['pct'] for x in c.get('share') or [] if kr2int.get(x['species'])}
        fat = O.fatigue_map(dict(sh, _rest=max(0, 100 - sum(sh.values())))) if sh else {}   # share 는 상위 5종 % 뿐 - 나머지를 채워 비율을 맞춤
        mine = {x['id']: x for x in api('/api/pokemon')['pokemon']}
        best = []
        for x in c.get('pokemon') or []:
            m = mine.get(x['id'])
            if x.get('away') or not m: continue
            sp = SPECIES.get(m['species']) or {}
            best.append((O.expect(O.mods(e['key'], sp, m.get('ability'), pct, O.cheer_of(e['day']), fat.get(m['species'], 0.0))), x))
        if not best: continue
        sc, x = max(best, key=lambda t: t[0])
        cur = (e.get('entry') or {}).get('pokemon', {}).get('id')
        if cur == x['id']: continue
        cur_sc = next((s for s, y in best if y['id'] == cur), None)
        if cur_sc is not None and sc - cur_sc < 0.005: continue   # 거의 같으면 그대로
        # ponytail: 작전은 늘 승부수 - 메달은 상위 3마리만이라 평균 +0.03·흔들림 큰 쪽이 맨 위에 닿을 일이 훨씬 많다(1판 기준 상위 꼬리 약 4배). 우리 쪽이 압도적 1순위면 안정이 나을 수 있음
        r = api_post('/api/olympics/enter', {'event': e['key'], 'pokemon': x['id'], 'tactic': 'bold'})
        say(f"올림픽 신청: {e['kr']} ← {x['name']} (기대 {sc:.3f}, 별 {x.get('stars')}, 승부수) {r.get('message') or r.get('detail') or ''}")
        _oly['at'] = 0

upd_at = 0
def update_check():
    # 자동 업데이트 (10/13): 드라이브에 새 판이 올라오면 스스로 끝난다 → 고리(run_hunt)가 받아서 다시 켠다. 10분마다 본다
    global upd_at
    if time.time() < upd_at: return
    upd_at = time.time() + 600
    import updater
    p = updater.newer()
    if p: say(f'새 판 {updater.version(p)} 있음 (지금 {updater.version() or "?"}) → 사냥기 다시 켜서 받음'); sys.exit(0)

def metric_step():
    global metric_hour
    h = time.strftime('%Y-%m-%d %H')
    if metric_hour is None:   # 사냥기를 다시 켜도 2시간 안의 기준은 이어 쓴다 (재시작마다 그 시간 앞부분이 빠지지 않게)
        metric_hour = h
        try: old = (json.load(open(METRIC, encoding='utf-8')).get('_snap') or {}).get('t', 0)
        except Exception: old = 0
        if time.time() - old > 7200: metric_snap()
        return
    if h == metric_hour: return
    metric_hour = h
    try: d = json.load(open(METRIC, encoding='utf-8'))
    except Exception: d = {}
    prev = d.get('_snap') or {}
    P = api('/api/pokemon')['pokemon']
    gain = sum(p['exp'] - prev['exp'].get(str(p['id']), p['exp']) for p in P) if prev.get('exp') else None
    t0 = prev.get('t', time.time() - 3600)
    lines = []
    try:
        with open(HUNT_LOG, encoding='utf-8') as f: lines = [l for l in f.readlines()[-4000:]]
    except Exception: pass
    start = time.strftime('%H:%M:%S', time.localtime(t0))
    # 끝에서 거꾸로 읽어 기준 시각 전이나 날짜 경계(시각이 거꾸로 감)에서 멈춘다 — 시각 글자만 비교하면 지난 날 같은 시간대 줄까지 셌다
    # (10/12 09:00 '놓침 81' = 옛 사냥기의 지난 며칠 줄, 실제 0)
    recent, last = [], '99:99:99'
    same_day = time.localtime(t0).tm_mday == time.localtime().tm_mday
    for l in reversed(lines):
        t = l[:8]
        if len(t) == 8 and t[2] == ':' and t[5] == ':':
            if t > last or (same_day and t < start): break
            last = t
        recent.append(l)
    recent.reverse()
    cnt = lambda w: sum(1 for l in recent if w in l)
    import re as _re
    lvls = [int(m.group(1)) for l in recent for m in [_re.search(r'관장(?: (?:수련|다시 이기기|이어 도전)|\(서버 직접(?:, 화면 잠김)?\)): \S+ \S+ Lv\.(\d+)', l)] if m]
    try: mine = json.load(open(GROW, encoding='utf-8')).get('ids') or []
    except Exception: mine = []
    byid = {p['id']: p for p in P}
    row = {'시각': time.strftime('%m-%d %H:00'), '기기': 'mac' if MAC else 'win', '분': round((time.time() - t0) / 60), '경험치합': gain,
           '육성': {byid[i]['info']['name']: byid[i]['level'] for i in mine if i in byid}, '자리수': (conf_seen or {}).get('육성_자리수'),
           '관장판': cnt('관장전 끝') + cnt('관장(서버 직접) 끝'), '육성KO': cnt('(육성)'), '전체KO': cnt('관장 쓰러뜨림'), '관장짐': cnt('관장전 짐'), '관장평균Lv': round(sum(lvls) / len(lvls)) if lvls else None,
           '포획시도': cnt(' 포획 '), '잡음': cnt('→ 잡음'), '놓침': cnt('놓침:'), '오류': sum(1 for l in recent if '오류(' in l and 'requests.exceptions' not in l), '서버끊김': cnt('requests.exceptions'), '육성교체': cnt('육성 시작'), '보유': len(P)}
    d.setdefault('rows', []).append(row); d['rows'] = d['rows'][-24 * 14:]
    json.dump(d, open(METRIC, 'w', encoding='utf-8'), ensure_ascii=False)
    say(f"시간별 지표: 경험치 {gain:,} · 관장 {row['관장판']}판(평균 Lv{row['관장평균Lv']}, {row['관장짐']}패, 육성 포켓몬 KO {row['육성KO']}/{row['전체KO']}) · 포획 {row['잡음']}/{row['포획시도']} · 놓침 {row['놓침']} · 오류 {row['오류']}{f" (서버 끊김 {row['서버끊김']})" if row['서버끊김'] else ''} · 육성 {row['육성']}" if gain is not None else '시간별 지표: 첫 기준 저장')
    metric_snap(P)

def metric_snap(P=None):
    P = P or api('/api/pokemon')['pokemon']
    try: d = json.load(open(METRIC, encoding='utf-8'))
    except Exception: d = {}
    d['_snap'] = {'t': time.time(), 'exp': {str(p['id']): p['exp'] for p in P}}
    json.dump(d, open(METRIC, 'w', encoding='utf-8'), ensure_ascii=False)

# ---------------------------------------------------------------- 지닌 도구 (2026-10-10)
# 가방의 지닐 수 있는 도구를 관장 주력·랭크 팀에게 나눠 준다. 사용자 결정: 소모성(열매·사탕·진화 도구)은 안 쓴다.
# 값 = 그 도구로 '18타입 상대마다 가장 아픈 한 방'의 합이 몇 % 오르나 (기술 배우기 판단과 같은 잣대). 메가스톤은 안 건드린다
HELD_SKIP = {'TOXICORB', 'FLAMEORB', 'STICKYBARB', 'IRONBALL', 'LAGGINGTAIL', 'FULLINCENSE', 'MACHOBRACE',
             'POWERBRACER', 'POWERBELT', 'POWERLENS', 'POWERBAND', 'POWERANKLET', 'POWERWEIGHT', 'EVERSTONE'}
held_at = 0
def held_gain(p, item, TB):
    st, types = p['info']['stats'], (SPECIES.get(p['species']) or {}).get('types') or []
    keys = [k for k in p.get('moves') or [] if (MOVES.get(k) or {}).get('cat') not in (None, 'status') and (MOVES.get(k) or {}).get('power')]
    if not keys: return 0
    def total(mult):
        return sum(max(move_val(st, types, k, t) * mult(MOVES[k]) for k in keys) for t in TYPES if t != 'STELLAR')
    base = total(lambda m: 1) or 1
    if item in TB: return total(lambda m: 1.2 if m['type'] == TB[item] else 1) / base - 1
    if item == 'MUSCLEBAND': return total(lambda m: 1.1 if m['cat'] == 'physical' else 1) / base - 1
    if item == 'WISEGLASSES': return total(lambda m: 1.1 if m['cat'] == 'special' else 1) / base - 1
    if item == 'LIFEORB': return total(lambda m: 1.3) / base - 1 - 0.1
    if item == 'BLACKSLUDGE': return 0.06 if 'POISON' in types else -1
    if item == 'LEFTOVERS': return 0.06
    if item == 'QUICKCLAW': return 0.03
    return 0

def held_step(pid):
    global held_at
    if not conf_on('도구_자동'): return   # 11/02 유저 제보: 손으로 준 도구를 30분마다 바꿈 → 켠 사람만 (거두기·메가스톤·평온의방울 전부)
    if gym_focus(): return   # 관장 올클리어: 도구는 gym_items 가 관장마다 맞춤
    if time.time() - held_at < 1800 or battle or fight or boss_solo(): return   # 관장전은 쉬지 않고 이어져서 기다리면 안 돈다 - 바꾸지 못한 건 실패로 남김
    held_at = time.time()
    root = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
    if root not in sys.path: sys.path.insert(0, root)
    from common import held as HL
    TB = HL.TYPE_BOOST
    shop = api('/api/shop'); shop = {i['id']: i for i in (shop if isinstance(shop, list) else shop.get('items') or [])}
    def usable(i):   # 지닐 수 있고, 열매·진화 도구·메가스톤·해로운 것이 아님
        it = shop.get(i) or {}
        return i in HL.ALL and not it.get('evolves') and it.get('cat') != 'megastone' and i not in HELD_SKIP \
            and i not in HL.HAPPINESS_ITEMS   # 10/19 사용자: 열매도 씀 - 배틀에서 먹어도 판이 끝나면 돌아온다(common/held._consume)
    P = api('/api/pokemon')['pokemon']; byid = {p['id']: p for p in P}
    try: mine = set(json.load(open(GROW, encoding='utf-8')).get('ids') or [])
    except Exception: mine = set()
    rteam = set(api('/api/pvp/team').get('ids') or [])
    locked = rteam if rank_locked() else set()   # 고정한 랭크 팀은 도구를 손으로 맞췄다 - 거두지도 바꾸지도 않는다
    rec = [p for p in P if (p['onDesktop'] or p['id'] in rteam) and p['id'] not in locked]   # 주력·육성 모두 (10/10: 교체 때마다 다시 나눔)
    stones = {m.get('megaStone') for ms in MEGA_OF.values() for m in ms} - {None}
    mega = lambda i: (shop.get(i) or {}).get('cat') == 'megastone' or i in stones
    # 10/19: 유대 미션으로 받은 메가스톤이 가방에만 있었다(가디안·한카리아스·후딘·찌르호크·곤율거니) → 그 종 중 가장 센 개체
    # (스톤 없는 것. 고정 랭크 팀은 빈손일 때만 - 사용자가 맞춘 도구는 안 뺌)에게 지니게 한다. 지니면 주력 점검이 메가 힘으로 다시 고른다
    sdone = []
    for st, n in ((api('/api/bag') or {}).get('bag') or {}).items():
        if st not in stones or n <= 0: continue
        own = [p for p in P if (p['id'] not in locked or not p.get('held')) and not (p.get('held') and mega(p['held'])) and any(m.get('megaStone') == st for m in MEGA_OF.get(p['species'], []))]
        for p in sorted(own, key=lambda p: -species_power(p, p['species'], p['level']))[:n]:
            if p.get('held'): api(f"/api/pokemon/{p['id']}/hold", 'DELETE')
            if api_post(f"/api/pokemon/{p['id']}/hold", {'item': st}).get('ok'):
                p['held'] = st; sdone.append(f"{p['info']['name']}←{(shop.get(st) or {}).get('kr') or HL.name(st)}(메가)"); globals()['core_due'] = True
    rec = [p for p in rec if not (p.get('held') and mega(p['held']))]   # 메가스톤 지닌 포켓몬은 그대로
    # 평온의방울 받을 포켓몬을 먼저 정하고, 그 포켓몬은 다른 도구 배분에서 뺀다 (안 그러면 30분마다 서로 뺏음)
    # 방울은 가진 개수만큼 (10/13 사용자: 3개 더 삼 → 메가 친밀도 육성 여럿에게): 친밀도 진화 육성 먼저, 그다음 메가스톤 못 받은
    # 데리고 다니는 포켓몬 중 255 에 가까운 순 (유대 미션 시작이 빨라진다)
    bells = (api('/api/bag').get('bag') or {}).get('SOOTHEBELL', 0) + sum(1 for p in P if p.get('held') == 'SOOTHEBELL')
    fr = [byid[i] for i in mine if i in byid and friend_need(byid[i])]
    mg = [p for p in P if p['onDesktop'] and p not in fr and p['id'] not in locked and MEGA_OF.get(p['species']) and (p.get('happiness') or 0) < 255
          and not (p.get('held') and mega(p['held'])) and api(f"/api/bond/{p['id']}").get('missing')]
    fr = (fr + sorted(mg, key=lambda p: -(p.get('happiness') or 0)))[:bells]
    frid = {p['id'] for p in fr}
    rec = [p for p in rec if p['id'] not in frid]
    keep = {p['id'] for p in rec} | locked
    for p in P:   # 박스로 간 포켓몬이 지닌 도구는 가방으로 거둬 다시 나눈다 (메가스톤·평온의방울은 usable 이 아니라 그대로)
        if p['id'] not in keep and p.get('held') and usable(p['held']): api(f"/api/pokemon/{p['id']}/hold", 'DELETE')
    pool = {k: v for k, v in (api('/api/bag').get('bag') or {}).items() if usable(k)}
    for p in rec:
        if p.get('held') and usable(p['held']): pool[p['held']] = pool.get(p['held'], 0) + 1
    cand = sorted(((held_gain(p, i, TB), p['id'], i) for p in rec for i in pool), reverse=True)
    want, left = {}, dict(pool)
    # 행복의알(쓰러뜨린 포켓몬 경험치 1.5배, 서버 battle_routes award)은 전투력이 안 올라 늘 0점으로 빠졌다 (10/12)
    # → 육성 포켓몬(Lv100 전) 중 최근 기록에서 관장 상대를 가장 많이 쓰러뜨린 것에게 (같으면 레벨 낮은 것)
    if left.get('LUCKYEGG'):
        try:
            with open(os.path.join(HERE, '사냥기록.txt'), encoding='utf-8', errors='ignore') as f: tail_ = f.readlines()[-600:]
        except OSError: tail_ = []
        ko = lambda p: sum(1 for l in tail_ if '관장 쓰러뜨림' in l and f": {p['info']['name']} →" in l)
        gr = [p for p in rec if p['id'] in mine and p['level'] < 100]
        if gr:
            t = max(gr, key=lambda p: (ko(p), -p['level']))
            want[t['id']] = 'LUCKYEGG'; left['LUCKYEGG'] -= 1
    for g, i, item in cand:
        if g < 0.02 or i in want or not left.get(item): continue
        want[i] = item; left[item] -= 1
    # 10/19: 도구로 +2% 못 받은 포켓몬은 열매 - 가장 크게 약한 타입(×2 이상)의 반감 열매, 없으면 회복 열매 (관장 맞춤 gym_items 와 같은 생각)
    rb = {t: b for b, t in HL.RESIST_BERRY.items()}
    HEAL = ['SITRUSBERRY', 'FIGYBERRY', 'WIKIBERRY', 'MAGOBERRY', 'AGUAVBERRY', 'IAPAPABERRY', 'LUMBERRY', 'ORANBERRY']
    for p in rec:
        if p['id'] in want: continue
        mt = (SPECIES.get(p['species']) or {}).get('types') or []
        weak = sorted((eff(t, mt), t) for t in TYPES if t != 'STELLAR' and eff(t, mt) >= 2 and left.get(rb.get(t), 0) > 0)
        it = rb[weak[-1][1]] if weak else next((h for h in HEAL if left.get(h)), None)
        if it: want[p['id']] = it; left[it] -= 1
    for p in rec:   # 바뀌는 것부터 벗긴다 (같은 도구를 다른 포켓몬에게 옮길 수 있게)
        if p.get('held') and usable(p['held']) and want.get(p['id']) != p['held']:
            api(f"/api/pokemon/{p['id']}/hold", 'DELETE')
    done = sdone
    for i, item in want.items():
        if byid[i].get('held') == item: continue
        r = api_post(f'/api/pokemon/{i}/hold', {'item': item})
        if r.get('ok'): done.append(f"{byid[i]['info']['name']}←{HL.name(item)}" + ('(경험치 ×1.5)' if item == 'LUCKYEGG' else '(열매)' if item.endswith('BERRY') else f"({held_gain(byid[i], item, TB) * 100:+.0f}%)"))
        else: say(f"도구 지니기 실패: {byid[i]['info']['name']} {item} — {str(r.get('detail') or r.get('error'))[:50]}")
    for f in fr:
        if f.get('held') == 'SOOTHEBELL': continue
        if not (api('/api/bag').get('bag') or {}).get('SOOTHEBELL'):   # 가방에 없으면 받을 대상이 아닌 포켓몬 것을 거둔다
            holder = next((p for p in P if p.get('held') == 'SOOTHEBELL' and p['id'] not in frid), None)
            if not holder: break
            api(f"/api/pokemon/{holder['id']}/hold", 'DELETE'); holder['held'] = None
        if api_post(f"/api/pokemon/{f['id']}/hold", {'item': 'SOOTHEBELL'}).get('ok'):
            done.append(f"{f['info']['name']}←평온의방울(친밀도 {f.get('happiness')}{'·진화' if friend_need(f) else '/255·메가 유대'})")
    if done: say('도구 지니게 함: ' + ', '.join(done))

# ---------------------------------------------------------------- 메가 유대 미션 (2026-10-09)
# 친밀도가 가득 찬 메가 가능 포켓몬은 머리 위 '빛나는 돌'을 눌러야 미션이 시작된다(bond_stone). 미션을 다 채웠는데
# X/Y 를 골라야 하면 '스톤 고르기'로 멈춰 있다 → 둘 다 사냥기가 서버에 바로 보낸다.
# X/Y 는 그 개체의 공격·특공 중 높은 쪽(리자몽·뮤츠: X 물리, Y 특수)으로 고른다.
bond_at = 0
def bond_step(pid):
    global bond_at
    if time.time() - bond_at < 600 or battle or fight: return
    bond_at = time.time()
    b = api('/api/me').get('bond') or {}
    P = {x['id']: x for x in api('/api/pokemon')['pokemon']}
    for i in b.get('ready') or []:
        r = api_post(f'/api/bond/{i}/start', {})
        name = (P.get(i) or {}).get('info', {}).get('name', i)
        say(f'메가 유대 미션 시작: {name}' if not r.get('error') else f'메가 유대 미션 시작 실패: {name} — {str(r["error"])[:50]}')
    for i in b.get('claim') or []:
        c = api(f'/api/bond/{i}')
        miss = [x for x in c.get('stones') or [] if x['id'] in (c.get('missing') or [])]
        if not miss: continue
        st = (P.get(i) or {}).get('info', {}).get('stats') or {}
        want = 'X' if st.get('atk', 0) >= st.get('spa', 0) else 'Y'
        pick = next((x for x in miss if x['id'].endswith(want)), miss[0])
        r = api_post(f'/api/bond/{i}/claim', {'stone': pick['id']})
        say(f"메가스톤 받음: {c.get('name', i)} — {pick.get('kr') or pick['id']} ({'공격' if want == 'X' else '특공'}이 더 높아서)" if not r.get('error') else f"메가스톤 받기 실패: {str(r['error'])[:50]}")

# ---------------------------------------------------------------- 전설 우선 (10/19 사용자 '전설이 생기면 무조건 전설 중심으로')
# 악당 출현(시즌 4, 10/17~30): 하루 한 번 09~12시 사이에 나타나 23시까지. 간부 3을 차례로 이기면 전설(볼 X) - 이기면 그날 70% 전설의 알.
# 판은 관장 배틀과 같은 판(/api/gym/battle/{id}/act)이라 gym_api_step 이 그대로 싸운다. 관장보다 먼저 한다.
# 간부에게 같은 자리에서 3번 지면 30분 관장 하고 다시. 전설은 이길 때까지 계속.
boss_at, boss_tries = 0, {}
# 10/25 사용자: 악당은 1마리로. 악당 팀은 우리 바탕화면 마릿수만큼만 앞에서부터 꺼낸다 → 6마리로 3번씩 지던 루자미네를
# 드닐레이브 1마리(상대도 밀로틱 1마리)로, 전설 프리져를 메가보스로라 1마리로 이김. 판 끝나면 원래 바탕화면으로(재시작해도 파일로 이어감)
BOSS_SOLO = os.path.join(HERE, '악당_원래바탕화면.json')
BOSS_PICK = os.path.join(HERE, '악당_지정.json')   # {날짜|단계: [id…]} 내 PC 모의로 미리 고른 1마리(앞에서부터 박스에 있는 것) — 없으면 boss_pick
BOSS_LEAD = os.path.join(HERE, '악당_선두.json')   # {날짜|단계: 상대 선두 종} — 처음 본 간부는 센 1마리로, 다음 판부터 상성 맞춤
def boss_solo(): return os.path.exists(BOSS_SOLO)

def boss_restore():
    # 1마리 출전 뒤 판이 끝났으면 원래 바탕화면으로. 판 중이면 True(다른 단계가 바탕화면을 건드리지 않게)
    if not boss_solo(): return False
    b = api('/api/gym/battle').get('battle') or {}
    if b and not b.get('over'): return True
    orig = json.load(open(BOSS_SOLO, encoding='utf-8'))
    PR = api('/api/pokemon'); P = PR['pokemon']
    e0 = globals().get('boss_eggs0')
    if e0 is not None:
        globals()['boss_eggs0'] = None
        got = [e.get('name') or '알' for e in PR.get('eggs') or [] if e['id'] not in e0]
        say('악당 전설 판 끝: ' + (f"알 받음 — {', '.join(got)}" if got else '알 없음 (이겨도 70%)'))
    for p in P:
        if p['onDesktop'] and p['id'] not in orig: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': False})
    for p in P:
        if not p['onDesktop'] and p['id'] in orig: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': True})
    api_post('/api/pokemon/order', {'ids': orig})
    os.remove(BOSS_SOLO); globals()['gym_party_for'] = None   # 다음 맞춤 파티는 다시 꾸림
    by = {p['id']: p['info']['name'] for p in P}
    say('판 끝 → 바탕화면 원래대로: ' + ', '.join(by.get(i, str(i)) for i in orig))
    return False

def boss_pick(P, lead):
    # 상대 선두를 알면 상성 맞춤(gym_pair), 모르면 센 순(final_power). 공격기 2개 이상·Lv90 이상·탐험 안 간 것
    away = {o['pokemon']['id'] for o in (api('/api/expedition').get('out') or [])}
    natk = lambda p: sum(1 for k in p['moves'] if (MOVES.get(k) or {}).get('cat') not in (None, 'status') and (MOVES.get(k) or {}).get('power'))
    C = [p for p in P if p['level'] >= 90 and natk(p) >= 2 and p['id'] not in away] or P
    f = {'species': lead, 'level': 100} if lead in SPECIES else None
    return max(C, key=lambda p: ((gym_pair(p, f) if f else 0), final_power(p)))

def boss_try():
    global boss_at
    if time.time() < boss_at: return False
    c = api('/api/boss') or {}
    if not c.get('active') or c.get('done'): boss_at = time.time() + 300; return False
    st = c.get('stage') or 0; k = (c.get('day'), st); n = boss_tries.get(k, 0)
    if n >= 3 and st < 3:
        boss_tries[k] = 0; boss_at = time.time() + 1800; say("악당: 간부에게 3번 짐 → 30분 관장 하고 다시"); return False
    try: seen = json.load(open(BOSS_LEAD, encoding='utf-8'))
    except Exception: seen = {}
    lk = f"{c.get('day')}|{st}"
    lead = seen.get(lk) or (next((s for s, v in SPECIES.items() if v.get('kr') == (c.get('legend') or {}).get('name')), None) if st >= 3 else None)
    PR = api('/api/pokemon'); P = PR['pokemon']
    # 10/27: 전설을 이기면 70% 알 — 받았는지 기록에 안 남아 10/26 미라이돈 뒤를 확인 못 했다 → 판 전 알 목록을 두고 boss_restore 에서 비교
    if st >= 3: globals()['boss_eggs0'] = {e['id'] for e in PR.get('eggs') or []}
    orig = [p['id'] for p in sorted(P, key=lambda p: p.get('slot') or 0) if p['onDesktop']]
    try: fix = json.load(open(BOSS_PICK, encoding='utf-8')).get(lk) or []
    except Exception: fix = []
    away = {o['pokemon']['id'] for o in (api('/api/expedition').get('out') or [])} if fix else set()
    byid = {p['id']: p for p in P}
    one = next((byid[i] for i in fix if i in byid and i not in away), None) or boss_pick(P, lead)
    if not boss_solo(): json.dump(orig, open(BOSS_SOLO, 'w', encoding='utf-8'))
    for p in P:
        if p['onDesktop'] and p['id'] != one['id']: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': False})
    if not one['onDesktop']: api_post(f"/api/pokemon/{one['id']}/desktop", {'on': True})
    api_post('/api/pokemon/order', {'ids': [one['id']]})
    say(f"악당 1마리 출전: {one['info']['name']} Lv{one['level']}" + (' (미리 고른 표)' if one['id'] in fix else '') + (f" (상대 선두 {(SPECIES.get(lead) or {}).get('kr', lead)} 맞춤)" if lead else ' (상대 선두 모름 → 가장 센 것)'))
    r = api_post('/api/boss/start', {})
    if not r.get('battle'): boss_at = time.time() + 600; globals()['boss_eggs0'] = None; say(f"악당 시작 실패: {str(r.get('detail'))[:60]}"); boss_restore(); return False
    fb = r['battle'].get('foe') or {}
    fl = ((fb.get('team') or [{}])[fb.get('slot') or 0] or {}).get('species')
    if fl and st < 3 and seen.get(lk) != fl:
        seen[lk] = fl; json.dump(seen, open(BOSS_LEAD, 'w', encoding='utf-8'))
    boss_tries[k] = n + 1
    who = f"전설 {(c.get('legend') or {}).get('name') or ''}" if st >= 3 else f"간부 {((c.get('members') or [{}] * 3)[st] or {}).get('name')}"
    say(f"악당 출현({c.get('team')} · {c.get('sidoName')}): {who} 도전 ({n + 1}번째, 전설 우선)"); globals()['gym_gap'] = False
    status(관장=f"악당: {who}")
    return True

# 길드전 공격 (시즌 4, 전쟁 기간 10/24~29): 우리 칸과 맞닿은 칸 중 우리가 많이 이긴 칸(3승이면 넘어옴), 같으면 방어팀이 약한 칸부터.
# 공격팀은 길드전에 등록한 팀(안 짰으면 랭크 팀)으로 서버가 고정해 둔 것. 판 진행은 관장과 같은 길.
# ---------------------------------------------------------------- 길드전 시즌 준비 (11/09 사용자: 신청 · 공격 분배 · 팀 자동)
# 시즌 5 교훈: 공격 30번을 고르게 나눴더니 길드원 10명이 하나도 안 써 27번이 버려졌다(사냥기 3번 3승).
# ① 신청 기간: 길드장이면 바로 신청 ② 신청·전략 기간: 이번 시즌 팀을 안 짰으면 지난 시즌 내 방어 · 공격팀 그대로
# ③ 전략 기간(한 번): 지난 시즌에 공격을 1번이라도 쓴 사람 3번, 안 쓴 사람 최소 1번, 남는 것 전부 나(사냥기)
# ④ 전쟁 · 끝: 길드원마다 쓴 공격 수와 내 팀을 적어 둔다 (다음 시즌 ②③ 의 근거). 칸 배치 · 조커는 서버 기본 그대로
GW_REC = os.path.join(HERE, '길드전_시즌기록.json')
gws_at = 0
def gw_season_step():
    global gws_at
    if LITE or time.time() < gws_at or not conf_on('길드전_자동'): return
    gws_at = time.time() + 1800
    w = api('/api/guild/war') or {}; ph = w.get('phase'); s = str(w.get('season'))
    try: rec = json.load(open(GW_REC, encoding='utf-8'))
    except Exception: rec = {}
    if ph in ('war', 'done') and w.get('entered'):
        t = w.get('teams') or {}
        rec[s] = dict(rec.get(s) or {}, used={str(m['userId']): m.get('used', 0) for m in w.get('mates') or []},
                      teams={k: [x['id'] for x in (t.get(k) or {}).get('mons') or []] for k in ('def', 'atk')})
        json.dump(rec, open(GW_REC, 'w', encoding='utf-8'), ensure_ascii=False); return
    if ph not in ('apply', 'plan'): return
    prev = rec.get(max((k for k in rec if k != s and k.isdigit()), key=int, default='')) or {}
    if ph == 'apply' and not w.get('entered') and (w.get('can') or {}).get('apply'):
        r = api_post('/api/guild/war/apply', {})
        say(f"길드전 시즌 {s} 참가 신청: {r.get('detail') or '됨'}")
    t = w.get('teams') or {}
    for k in ('def', 'atk'):
        ids = (prev.get('teams') or {}).get(k)
        if ids and not (t.get(k) or {}).get('set'):
            r = api_post('/api/guild/war/team', {'kind': k, 'ids': ids})
            say(f"길드전 {'방어' if k == 'def' else '공격'}팀 지난 시즌 그대로: {r.get('detail') or r.get('message') or '됨'}")
    if ph == 'plan' and (w.get('can') or {}).get('manage') and (rec.get(s) or {}).get('planned') != 1:
        me = next((m['id'] for m in (api('/api/guild') or {}).get('members') or [] if m.get('me')), None)
        mates = [m['userId'] for m in w.get('mates') or []]
        if not me or me not in mates: return
        used = prev.get('used') or {}
        plan = {u: (3 if used.get(str(u), 0) else 1) for u in mates if u != me}
        plan[me] = int(w.get('total') or 30) - sum(plan.values())
        r = api_post('/api/guild/war/attacks', {'plan': {str(k): v for k, v in plan.items()}})
        if r.get('detail'): say(f"길드전 공격 분배 실패: {str(r['detail'])[:60]}"); return
        rec[s] = dict(rec.get(s) or {}, planned=1); json.dump(rec, open(GW_REC, 'w', encoding='utf-8'), ensure_ascii=False)
        say(f"길드전 공격 분배: 나 {plan[me]}번 · 지난 시즌 공격한 사람 {sum(1 for u, v in plan.items() if u != me and v == 3)}명 3번 · 나머지 {sum(1 for u, v in plan.items() if u != me and v == 1)}명 1번")

gw_at = 0
def gw_try():
    global gw_at
    if time.time() < gw_at: return False
    s_ = api('/api/guild/war') or {}
    if s_.get('phase') != 'war': gw_at = time.time() + 1800; return False
    gw_at = time.time() + 300
    if not (s_.get('can') or {}).get('attack'): return False
    m = api('/api/guild/war/map') or {}; cells = m.get('cells') or {}
    hit = m.get('hit') or []
    if not hit: return False
    # 10/20: 승수 많은 칸 먼저, 같으면 방어팀이 약한 칸 (보이는 앞 3마리로 6마리 전력 추정). AI 수비대는 Lv50 중간값이라 약하지 않다
    def gw_pow(r):
        v = api(f'/api/guild/war/tile/{r}') or {}; ms = v.get('team') or []
        if not ms: return 1e18
        p = sum((sum((SPECIES.get(x['species']) or {'base': {'hp': 500}})['base'].values()) * min(50, x.get('level') or 50)) ** 1.5 for x in ms)
        return p * (v.get('size') or len(ms)) / len(ms)
    t = min(hit, key=lambda r: (-(cells.get(r) or {}).get('wins', 0), gw_pow(r)))
    r = api_post('/api/guild/war/attack', {'region': t})
    if not r.get('battle'): say(f"길드전 공격 실패: {t} {str(r.get('detail'))[:60]}"); return False
    gw_at = time.time() + 20
    c = cells.get(t) or {}
    say(f"길드전 공격: {c.get('name') or t} (우리 {c.get('wins', 0)}승/{m.get('need', 3)}승, {'AI 수비대' if c.get('ai') else '사람'})")
    globals()['gym_gap'] = False
    return True

# 알(전설·환상, 48시간): 데리고 다녀야 자란다. 6자리가 차 있으면 박스에 들어가 멈춰 있다 → 육성 자리를 하나 비워 올린다.
# 깨면 Lv5 전설 - 육성이 키우고, 바탕화면 최저 레벨이 낮아져 야생도 진화 전 모습이 나온다(도감 순환)
egg_at, eggs_desk = 0, 0
def egg_step():
    global egg_at, eggs_desk
    if time.time() < egg_at or boss_solo(): return
    egg_at = time.time() + 600
    E = [e for e in (api('/api/me') or {}).get('eggs') or [] if not e.get('hatched')]
    eggs_desk = sum(1 for e in E if e.get('onDesktop'))
    for e in E:
        if e.get('onDesktop'): continue
        try: mine = json.load(open(GROW, encoding='utf-8')).get('ids') or []
        except Exception: mine = []
        P = {x['id']: x for x in api('/api/pokemon')['pokemon']}
        if sum(1 for x in P.values() if x['onDesktop']) + eggs_desk >= 6:
            out = next((i for i in reversed(mine) if i in P and P[i]['onDesktop']), None)
            if out is None: say(f"알을 올릴 자리 없음: {e.get('name')} — 육성 자리가 없음"); return
            api_post(f'/api/pokemon/{out}/desktop', {'on': False}); mine.remove(out); json.dump({'ids': mine}, open(GROW, 'w', encoding='utf-8'))
        r = api_post(f"/api/eggs/{e['id']}/desktop", {'on': True})
        if r.get('detail') or r.get('error'): say(f"알 올리기 실패: {e.get('name')} — {str(r.get('detail') or r.get('error'))[:50]}"); return
        eggs_desk += 1
        say(f"알 데리고 다님: {e.get('name')} (부화까지 약 {(e.get('leftSec') or 0) // 3600}시간, 전설 우선)")

# ---------------------------------------------------------------- 랭크 팀 노력치 (10/19 사용자: 깎고 육성 자리 1개로 채우기)
# 랭크·길드전은 Lv50 이라 노력치 차이가 그대로 난다. 공격 기술이 물리면 공격, 특수면 특공이 '쓸 쪽', 반대쪽은 낭비.
# 1) 하루 몇 번 낭비 쪽을 열매(80원, −10)로 0까지 깎는다(배틀에서 다시 들어오므로)
# 2) 육성 자리 1개에 '쓸 쪽 빈칸 + 전체 빈칸'이 가장 큰 랭크 팀원을 데리고 다녀 관장 배틀 노력치(바탕화면 전원이 나눠 받음)로 채운다
# 10/28 사용자 '노력치 공짜로 채우기': 목표 = 쓸 쪽 252 + 스피드 252 (모의 sim8: 4마리 모두 이 배분이 최선, 방어·HP 쪽은 손해).
#   채우는 중인 팀원(노력치 자리 + 주력으로 바탕화면에 있는 팀원)은 목표 밖 능력치를 20분마다 전부 깎는다 — 관장 노력치가
#   여러 능력치로 섞여 들어와 510 이 금방 차므로. 하루 열매 값 ≈ 1~2만 원(약 89만 원어치 비타민 대신).
#   기술이 2개 이상인 반대쪽(진짜 섞어 쓰는 팀원)은 깎지 않는다
EV_BERRY = {'hp': 'POMEGBERRY', 'atk': 'KELPSYBERRY', 'def': 'QUALOTBERRY', 'spa': 'HONDEWBERRY', 'spd': 'GREPABERRY', 'spe': 'TAMATOBERRY'}
EV_KR = {'hp': 'HP', 'atk': '공격', 'def': '방어', 'spa': '특공', 'spd': '특방', 'spe': '스피드'}
ev_ids, ev_at = set(), 0
def conf_on(k):
    try: return bool(json.load(open(CONF, encoding='utf-8')).get(k, False))
    except Exception: return False
def ev_cats(x, cat): return sum(1 for m in x.get('moves') or [] if (MOVES.get(m) or {}).get('cat') == cat and (MOVES.get(m) or {}).get('power'))
def ev_side(x):
    return ('atk', 'spa') if ev_cats(x, 'physical') >= ev_cats(x, 'special') else ('spa', 'atk')
def ev_keep(x):
    use, other = ev_side(x)
    return {use, 'spe'} | ({other} if ev_cats(x, 'physical' if other == 'atk' else 'special') >= 2 else set())
def ev_room(x):
    ev = x.get('evs') or {}; use, _ = ev_side(x)
    return min(sum(max(0, 252 - ev.get(s, 0)) for s in (use, 'spe')), 510 - sum(ev.get(s, 0) for s in ev_keep(x)))
def ev_pick(P, mine):
    # 주력으로 이미 데리고 다니는 팀원(가디안 등)은 따로 자리를 안 써도 채워진다
    lock = set(api('/api/pvp/team').get('ids') or [])
    c = [x for x in P if x['id'] in lock and ev_room(x) >= 8 and not x.get('away') and (not x['onDesktop'] or x['id'] in mine)]
    # 데리고 있는 팀원은 다 찰 때까지 그대로 (10/19 09:32~ 빈칸 1~2 차이로 1분마다 골루그·악비아르·파라블레이즈가 번갈아 들락거림)
    return next((x for x in c if x['id'] in mine and x['id'] in ev_ids), None) or max(c, key=ev_room, default=None)
def ev_cuts(x, filling):
    """깎을 {능력치: 열매 수}. 채우는 중이면 목표 밖 전부, 아니면 예전처럼 안 쓰는 공격 쪽만(그쪽 기술이 하나도 없을 때)."""
    ev = x.get('evs') or {}; _, other = ev_side(x)
    if filling: stats = [s for s in EV_BERRY if s not in ev_keep(x)]
    else: stats = [other] if not ev_cats(x, 'physical' if other == 'atk' else 'special') else []
    return {s: -(-ev.get(s, 0) // 10) for s in stats if ev.get(s, 0) > 0}
def ev_set(x, cuts):
    # 11/05 (게임 2.2.0 노력치 조정): 열매 사기·쓰기를 서버가 한 번에 (POST /api/pokemon/{id}/evs, dry 로 값 묻고 그 값으로 적용).
    # 옛 서버·돈 부족이면 False → 예전처럼 열매를 하나씩 쓴다
    want = dict(x['evs']); want.update({s: 0 for s in cuts})
    u = f"/api/pokemon/{x['id']}/evs"
    r = api_post(u, {'evs': want, 'buy': True, 'dry': True})
    if not r.get('ok') or not r.get('affordable'): return False
    return bool(api_post(u, {'evs': want, 'buy': True, 'dry': False, 'cost': r.get('cost', 0)}).get('ok'))
def ev_step():
    global ev_at
    if LITE or time.time() < ev_at or not conf_on('노력치_자동'): return   # 설정에서 켠 사람만 (공유받은 사람은 기본 꺼짐 - 열매를 사고 노력치를 바꿈)
    ev_at = time.time() + 20 * 60
    lock = set(api('/api/pvp/team').get('ids') or [])
    if not lock: return
    bag = (api('/api/bag') or {}).get('bag') or {}
    done = []
    for x in [x for x in api('/api/pokemon')['pokemon'] if x['id'] in lock]:
        if sum((x.get('evs') or {}).values()) < 500: continue   # 11/11: 안 막혔으면 안 깎음 — 20분마다 열매 사서 깎아 11/09~11 1만 원대 → 수천 원 남음. 510 에 닿을 때만
        if not ev_room(x): continue   # 11/09: 다 찬 팀원은 남는 노력치 6 이하(Lv50 능력치 0점) - 20분마다 열매 사서 깎던 것(가디안 하루 70번) 그만
        cuts = ev_cuts(x, x['id'] in ev_ids or x['onDesktop'])
        msg = f"{x['info']['name']} " + '·'.join(f"{EV_KR[s]} {x['evs'][s]}" for s in cuts) + '→0'
        if cuts and ev_set(x, cuts): done.append(msg); continue
        for s, n in cuts.items():
            b = EV_BERRY[s]
            if bag.get(b, 0) < n:
                r = api_post('/api/shop/buy', {'item': b, 'count': n - bag.get(b, 0)})
                if r.get('detail'): say(f"노력치 열매 사기 실패: {str(r['detail'])[:40]}"); return
            for _ in range(n):
                if api_post('/api/bag/use', {'item': b, 'pokemon': x['id'], 'stat': '', 'hour': time.localtime().tm_hour}).get('detail'): break
            bag = (api('/api/bag') or {}).get('bag') or {}
        if cuts: done.append(msg)
    if done: say('노력치 정리(랭크 팀 목표 밖 깎음): ' + ', '.join(done))

# ---------------------------------------------------------------- 중복 도구 팔기 (10/19 사용자 C3: 자동 판매)
# 하루 한 번. 팔 물건(진주·버섯 등 'sell')은 다 팔고, 지닐 도구·열매는 종류마다 SELL_KEEP 개만 남긴다.
# 안 파는 것: 볼·진화 도구·메가스톤·노력치 열매·깃털·병뚜껑·변함없는돌·이로치사탕·행복의알 (cat/kind 로 거른다)
SELL_KEEP, SELL_NEVER = 2, {'LUCKYEGG', 'SOOTHEBELL'}
sell_day = ''
def sell_step():
    global sell_day
    day = time.strftime('%Y-%m-%d')
    if LITE or sell_day == day or not conf_on('도구_자동판매'): return   # 설정에서 켠 사람만 (공유받은 사람은 기본 꺼짐)
    sh = api('/api/shop') or {}; bag = sh.get('bag') or {}; it = {i['id']: i for i in sh.get('items') or []}
    if not it: return
    sell_day = day
    lines = []
    for k, v in bag.items():
        i = it.get(k) or {}; kind = (i.get('effect') or {}).get('kind')
        if k in SELL_NEVER or (i.get('sell') or 0) <= 0 or i.get('evolves'): continue
        if i.get('cat') == 'misc' and kind == 'sell': n = v
        elif i.get('cat') == 'held' and kind == 'held': n = v - SELL_KEEP
        else: continue
        if n > 0: lines.append({'item': k, 'count': n})
    if not lines: return
    r = api_post('/api/shop/sell-many', {'lines': lines[:100]})
    if r.get('detail'): say(f"도구 팔기 실패: {str(r['detail'])[:60]}"); return
    got = sum((it[l['item']].get('sell') or 0) * l['count'] for l in lines[:100])
    say(f"중복 도구 팖: {len(lines)}종 {sum(l['count'] for l in lines)}개 약 {got:,}원 (" + ', '.join(f"{it[l['item']].get('kr')}×{l['count']}" for l in lines[:8]) + (' …' if len(lines) > 8 else '') + ')')

# ---------------------------------------------------------------- 박스 정리 (10/19 사용자 '박스 정리도 준비해봐')
# 서버 보유 상한 960 이 차면 풀숲이 안 돋는다(새 종을 못 만남). 모두 잡기로 하루 30~40마리씩 늘어서
# BOX_CLEAN_AT 마리가 되면 겹치는 종 중 약한 개체를 놓아주어 BOX_CLEAN_TO 마리로 줄인다. 놓아주기는 되돌릴 수 없어서
# 설정 '박스_정리' 를 켠 사람만 실제로 하고, 꺼져 있으면 하루 한 번 '정리하면 몇 마리' 만 기록한다.
# 지키는 것: 데리고 다니는 것·탐험 중·랭크 팀·길드전 팀·관장 고정 파티·육성 목록·이로치·전설/환상·별명·진화 잠금·
# 메가스톤 지님·유대 미션 진행 중, 그리고 종마다 '최종 힘' 상위 BOX_KEEP_PER 마리 + 개체값 합 1등.
# 지닌 도구는 서버가 가방으로 돌려준다(main.release). 놓아준 것은 박스정리_기록.json 에 남긴다.
BOX_CLEAN_AT, BOX_CLEAN_TO, BOX_KEEP_PER, BOX_PER_RUN = 800, 780, 1, 40   # 10/19 사용자: 800마리부터 놓아주기 · 10/25 사용자: 종마다 힘 1등만(+개체값 1등)
BOXLOG = os.path.join(HERE, '박스정리_기록.json')
box_at, box_said = 0, ''
def box_protect(P):
    keep = {x['id'] for x in P if x['onDesktop'] or x.get('away') or x.get('shiny') or x.get('nickname') or x.get('noEvolve')}
    keep |= set(api('/api/pvp/team').get('ids') or []) | oly_ids()
    try:
        t = (api('/api/guild/war') or {}).get('teams') or {}
        keep |= {m.get('id') for k in ('def', 'atk') for m in (t.get(k) or {}).get('mons') or []}
    except Exception: pass
    try:
        c = json.load(open(CONF, encoding='utf-8'))
        keep |= {i for v in (c.get('관장_고정파티') or {}).values() for i in v} | set(c.get('육성_목록') or [])
    except Exception: pass
    for x in P:
        sp = SPECIES.get(x['species']) or {}
        if sp.get('legendary') or sp.get('mythical') or holds_stone(x): keep.add(x['id'])
    try: keep |= {i for v in json.load(open(BOSS_PICK, encoding='utf-8')).values() for i in v}   # 악당 날짜별로 미리 고른 것
    except Exception: pass
    return keep
def box_plan(P, keep, target):
    """놓아줄 것 목록 (약한 것부터). 종마다 최종 힘 상위 BOX_KEEP_PER + 개체값 1등은 남긴다."""
    by = {}
    for x in P: by.setdefault(x['species'], []).append(x)
    out = []
    for sp, xs in by.items():
        if len(xs) <= BOX_KEEP_PER: continue
        strong = sorted(xs, key=lambda x: -final_power(x))
        stay = {x['id'] for x in strong[:BOX_KEEP_PER]} | {max(xs, key=iv_sum)['id']}
        out += [x for x in strong[BOX_KEEP_PER:] if x['id'] not in stay and x['id'] not in keep]
    out.sort(key=lambda x: final_power(x))
    return out[:max(0, len(P) - target)]
def box_step():
    global box_at, box_said
    if LITE or time.time() < box_at or boss_solo(): return   # 악당 1마리 출전 중엔 바탕화면에서 내린 것도 지킴
    box_at = time.time() + 3600
    P = (api('/api/pokemon') or {}).get('pokemon') or []
    if len(P) < BOX_CLEAN_AT: return
    plan = box_plan(P, box_protect(P), BOX_CLEAN_TO)[:BOX_PER_RUN]
    if not plan: return
    if not conf_on('박스_정리'):
        day = time.strftime('%Y-%m-%d')
        if box_said != day: box_said = day; say(f"박스 {len(P)}마리 — 정리하면 겹치는 종 {len(plan)}마리를 놓아줄 수 있음 (설정 '박스_정리' 가 꺼져 있어 안 함)")
        return
    try: log = json.load(open(BOXLOG, encoding='utf-8'))
    except Exception: log = []
    done = []
    for x in plan:
        if x['onDesktop'] or x.get('away'): continue
        r = api(f"/api/pokemon/{x['id']}", 'DELETE')
        if not (r or {}).get('ok'): say(f"놓아주기 실패: {x['info']['name']} — {str((r or {}).get('detail'))[:40]}"); break
        done.append(x['info']['name'])
        log.append({'at': time.strftime('%m-%d %H:%M'), 'id': x['id'], 'species': x['species'], 'name': x['info']['name'], 'level': x['level'], 'iv': iv_sum(x), 'power': round(final_power(x), 1), 'held': x.get('held')})
    json.dump(log[-5000:], open(BOXLOG, 'w', encoding='utf-8'), ensure_ascii=False)
    if done: say(f"박스 정리: {len(done)}마리 놓아줌 ({len(P)}→{len(P) - len(done)}마리) — " + ', '.join(done[:10]) + (' …' if len(done) > 10 else ''))

gym_gap = False
_lock_at, _lock_v = 0, False
def locked_now():
    global _lock_at, _lock_v
    if time.time() - _lock_at > 20: _lock_at, _lock_v = time.time(), screen_locked()
    return _lock_v

_mode_at, _mode = 0, {}
def server_mode(key):
    # 조종판의 '관장 방식'·'포획 방식'(조종판설정.json: '서버' 기본 / '화면'). 화면이 잠기면 '화면'이어도 서버로 한다 (10/11 사용자: 따로 고르게)
    global _mode_at, _mode
    if time.time() - _mode_at > 5:
        try: _mode = json.load(open(CONF, encoding='utf-8'))
        except Exception: pass
        _mode_at = time.time()
    return _mode.get(key, '서버') != '화면' or locked_now()
wild_api_at, wild_api_done = 0, {}   # 서버로 처리한 야생 id → 시각
def pick_ball(opts):
    # 화면과 같은 순서: 추천(서버가 고른 제일 잘 듣는 볼, 마스터볼 제외) > 슈퍼볼 > 몬스터볼
    have = [o for o in opts or [] if o.get('count', 0) > 0 and o['id'] != 'MASTERBALL']
    return ([o for o in have if o.get('best')] or [o for o in have if o['id'] == 'GREATBALL'] or [o for o in have if o['id'] == 'POKEBALL'] or [None])[0]

dex_caught_at, dex_caught = 0, set()
BALL_KEEP, BOX_KEEP = 20, 900
def dex_mode():
    # 도감 모드(10/15 사용자 '도감 400종·얼음·드래곤 수집가'): 이미 잡은 종(이색 아님)은 볼을 안 던지고 보내 준다 — 볼 절약.
    # 야생 레벨 = 바탕화면 최저 레벨(서버 _wild_levels)이고 Lv100 이면 레벨 진화가 끝난 모습만 나와 새 종이 19%뿐
    # → 저레벨 하나(쉐이미 Lv30, 새 종 37%)를 바탕화면에 두고, 잡을 때 경험치를 안 받아(exp=False) 그 레벨을 지킨다
    try: return bool(json.load(open(CONF, encoding='utf-8')).get('도감_모드', False))
    except Exception: return False

def dex_has(sp):
    global dex_caught_at, dex_caught
    if time.time() - dex_caught_at > 600:
        try: dex_caught = set((api('/api/dexbook') or {}).get('caught') or []); dex_caught_at = time.time()
        except Exception: pass
    return (SPECIES.get(sp or '') or {}).get('num') in dex_caught

# ---------------------------------------------------------------- 하루 계획 (10/15 사용자: 관장 올클리어 대신 게임 목표)
# 목표 = 도감(400종 → 600·800, 얼음·드래곤 수집가) + 길드 미션 매일 10/10 + 돈은 벌어서 볼값으로 + 그러면서 성장.
# 바탕화면 6 = 주력 3(관장을 이김) + 육성 3(도감 우선: 레벨로 진화하면 도감에 없는 종이 되는 것, grow_step).
#  · 관장 경험치는 데리고 다니는 6마리 전원이 받는다(10/08 실측) → 육성은 싸우지 않아도 오르고, 높은 관장일수록 경험치·상금(레벨×5)이 크다.
#    그래서 '낮은 관장은 낮은 포켓몬으로'가 아니라 주력이 이길 수 있는 가장 높은 관장을 돌고 육성은 따라 오르게 한다.
#  · 야생 레벨 = 바탕화면 최저 레벨(서버 _wild_levels) → 육성(저레벨)이 있으면 진화 전 모습이 나와 새 종이 늘어난다(Lv100 19% / Lv30 37%).
#  · 돈 모드: 상금 남은 이긴 관장(255곳 ≈ 7.6만 원/일) 먼저, 다 받으면 수련 — 길드 '관장 3승'도 여기서.
#  · 도감 모드: 이미 잡은 종은 볼 없이 보내 줌. 단 길드 '싸워 이기기 5'가 남았으면 쓰러뜨림.
# 볼: 슈퍼볼이 BALL_LOW 아래면 BALL_BUY 개 산다 — 하루 지출 SPEND_CAP 이하, 남는 돈 MONEY_FLOOR 이상일 때만.
# 수입 ≈ 상금 7.6만 + 랜덤 배틀 최대 6천/일, 볼값 = 슈퍼볼 600원 × 하루 100개 이하 → 흑자 유지.
# 10/19 사용자: 하루 볼값 상한 = 최근 하루 평균 수입의 60% (수입 = 그날 가진 돈 변화 + 그날 볼값, 지난 3일 평균). 기록이 없으면 6만.
# ponytail: 사람이 상점에서 산 돈도 '수입 감소'로 잡혀 상한이 그만큼 낮아짐 - 문제 되면 사냥기 밖 지출을 따로 셀 것
BALL_LOW, BALL_BUY, SPEND_CAP, MONEY_FLOOR, SPEND_RATE = 30, 50, 60000, 50000, 0.8   # 10/24 사용자: 하한 15만→5만, 도감 모드 아니어도 삼 · 10/27 사용자: 상한 60→80%(돈이 하루 3만씩 쌓임)
SPEND = os.path.join(HERE, '지출기록.json')

def spend_cap(sp, day, money):
    m, inc = sp.setdefault('_m', {}), sp.setdefault('_inc', {})
    for d in [d for d in m if d < day and d not in inc]: inc[d] = m[d][1] - m[d][0] + sp.get(d, 0)   # 끝난 날의 수입
    m[day] = [m.get(day, [money])[0], money]
    for d in sorted(m)[:-4]: m.pop(d)
    last = [inc[d] for d in sorted(inc) if inc[d] > 0][-3:]   # 10/24: PC 꺼 둔 날(10/21 수입 -80)이 평균을 끌어내려 상한 2.8만 → 수입 0 이하인 날은 뺌
    return max(0, int(SPEND_RATE * sum(last) / len(last))) if last else SPEND_CAP
plan_at, plan_phase = 0, None
def plan_step():
    global plan_at, plan_phase
    if time.time() - plan_at < 60: return
    plan_at = time.time()
    ball_step()
    if not dex_mode(): return
    if not os.path.exists(CHAIN): open(CHAIN, 'w').close()   # 관장은 늘 돈다 (상금 → 수련할 게 있을 때만 수련, money_rest_ok)
    unpaid = sum(1 for r in api('/api/gym').get('regions') or [] if r['cleared'] and not r.get('today'))
    ph = '상금' if unpaid else '수련'
    if ph != plan_phase:
        say(f"하루 계획: 관장 {ph} — " + (f'상금 남은 곳 {unpaid}' if unpaid else '오늘 상금 다 받음 → ' + ('경험치 수련' if money_rest_ok([p for p in api('/api/pokemon')['pokemon'] if p['onDesktop']]) else '관장 쉼')))
        plan_phase = ph

def ball_step():
    bag = (api('/api/bag') or {}).get('bag') or {}
    n = bag.get('GREATBALL', 0)
    if n >= BALL_LOW: return
    # 11/09 사용자: 길드 코인(슈퍼볼 3코인 = 600원어치)을 먼저 쓴다 - 돈 상한과 따로라 볼이 모자라던 날도 채워진다
    if conf_on('길드코인_볼'):
        c = int((api('/api/guild/shop') or {}).get('coin') or 0) // 3
        if c:
            r = api_post('/api/guild/shop/buy', {'item': 'GREATBALL', 'count': min(c, BALL_BUY)})
            if not r.get('detail'): say(f"슈퍼볼 {min(c, BALL_BUY)}개 길드 코인으로 삼 ({min(c, BALL_BUY) * 3}코인) — 남은 {n}→{n + min(c, BALL_BUY)}개"); return
            say(f"길드 코인 볼 사기 실패: {str(r.get('detail'))[:50]}")
    try: sp = json.load(open(SPEND, encoding='utf-8'))
    except Exception: sp = {}
    day = time.strftime('%Y-%m-%d'); spent = sp.get(day, 0)
    money = (api('/api/mypage').get('user') or {}).get('money')
    if money is None: return   # 서버가 돈을 안 줬음 (10/17 01:58 '가진 돈 0' 오판)
    cap = spend_cap(sp, day, money); json.dump(sp, open(SPEND, 'w', encoding='utf-8'))
    k = int(min(BALL_BUY, (cap - spent) // 600, (money - MONEY_FLOOR) // 600))   # 50개 묶음이 한도를 넘으면 남은 한도만큼만 (10/19 12:21 29개에서 못 삼)
    cost = 600 * k
    if k < 1:
        if sp.get('_said') != day: say(f"볼 사기 멈춤: 슈퍼볼 {n}개 · 오늘 쓴 돈 {spent:,} / 상한 {cap:,}(평균 수입의 {SPEND_RATE:.0%}) · 가진 돈 {money:,} (하한 {MONEY_FLOOR:,})"); sp['_said'] = day; json.dump(sp, open(SPEND, 'w', encoding='utf-8'))
        return
    r = api_post('/api/shop/buy', {'item': 'GREATBALL', 'count': k})
    if r.get('detail'): say(f"볼 사기 실패: {str(r.get('detail'))[:50]}"); return
    sp[day] = spent + cost; json.dump(sp, open(SPEND, 'w', encoding='utf-8'))
    say(f"슈퍼볼 {k}개 삼 ({cost:,}원) — 남은 {n}→{n + k}개, 오늘 {sp[day]:,}원 / 상한 {cap:,}(평균 수입의 {SPEND_RATE:.0%})")

guild_at, guild_gm = 0, None
def guild_mission_left(key):
    global guild_at, guild_gm
    if time.time() - guild_at > 300:
        try: guild_gm = {x['key']: x for x in ((api('/api/guild') or {}).get('mission') or {}).get('missions', [])}; guild_at = time.time()
        except Exception: pass
    if guild_gm is None: return True
    return key in guild_gm and not guild_gm[key].get('done')
def guild_battle_left(): return guild_mission_left('battle')

def bond_catch_left():
    # 바탕화면 포켓몬 중 유대 미션 '야생 잡기'가 남은 포켓몬 이름 (서버 on_catch: 어떤 종을 잡아도 데리고 다니는 개체마다 +1)
    for p in api('/api/pokemon')['pokemon']:
        if not p['onDesktop'] or not MEGA_OF.get(p['species']): continue
        if not bond_live(p): continue   # 11/11: 같은 종 둘째(받을 스톤 없음)는 빼고
        b = bond_info(p)
        if b.get('started') and not b.get('done') and any(m.get('key') == 'wild' and m.get('value', 0) < m.get('target', 1) for m in b.get('missions') or []):
            return p['info']['name']
    return ''

def wild_api_step(pid):
    # 풀숲·야생 배틀·포획을 게임 창 대신 서버 요청으로 (10/11 09시 사용자: '풀숲 누르고 배틀하고 포획하는 것도 서버 직접으로').
    # 게임의 잡기 모드와 같은 흐름: 풀숲 누르기(/reveal) → 배틀(/api/wild/{id}/battle, 파티 첫 자리가 나감)
    #  → 기술은 서버 잡기 모드(move=AUTO, catch=always: 상대를 안 쓰러뜨리고 잠재우기·마비·체력 깎기)
    #  → 서버가 'hold'(이제 던질 때)를 주면 볼(/api/battle/{id}/ball, exp=True) — 체력이 낮고 상태이상이면 포획률이 최대 3~6배
    # 예전(03:4x~)엔 잠긴 동안만, 배틀 없이 체력 꽉 찬 상대에게 볼만 던졌다(몬스터볼로는 5번 다 빠짐이 잦음, 볼 자동 구매 안 함).
    # 한 야생에는 한 번만(포획 시도 횟수까지) — 야생은 서버에 한동안 남아 있어서, 예전엔 5번 다 빠지면 10초 뒤 또 5번을 던졌다(04:09 이븐곰)
    global wild_api_at
    if time.time() - wild_api_at < 10: return
    wild_api_at = time.time()
    w = (api('/api/wild') or {}).get('wild')
    if not w or w['id'] in wild_api_done: return
    wild_api_done[w['id']] = time.time()
    for k in [k for k, t in wild_api_done.items() if time.time() - t > 3600]: wild_api_done.pop(k)
    h = time.localtime().tm_hour
    r = api_post(f"/api/wild/{w['id']}/reveal", {})
    if not r.get('wild'): return
    pm = r['wild'].get('pokemon') or {}
    name = (pm.get('name') or (SPECIES.get(pm.get('species') or '') or {}).get('kr') or pm.get('species') or '?') + (f" Lv{pm['level']}" if pm.get('level') else '')
    tag = '(서버 직접' + (', 화면 잠김)' if locked_now() else ')')
    out, throws = [], 0
    dexm = dex_mode()
    bondm = bond_catch_left()   # 11/03 사용자: 유대 미션 '야생 잡기'가 남았으면 이미 가진 종도 잡는다 (보내 주기·볼 몫·길드 쓰러뜨리기보다 먼저)
    if bondm: out.append(f'{bondm} 유대 미션 — 잡음')
    if dexm and not bondm and not pm.get('shiny') and dex_has(pm.get('species')) and not guild_battle_left():
        # 10/19 사용자 '도감에 없는 종만이 아니라 모두 잡도록': 이미 잡은 종도 잡는다. 단 볼이 BALL_KEEP 개 아래면 새 종 몫으로 남기고,
        # 박스가 BOX_KEEP 마리 넘으면 안 잡는다 (서버 보유 상한 960 이 차면 풀숲이 안 돋아 새 종도 못 만난다)
        # 10/16: 랭크 팀 종이고 좋은 성격(rank_val 3%↑)이면 기록에 표시 (nature_up)
        up = nature_up(pm)
        bag = (api('/api/bag') or {}).get('bag') or {}
        balls = sum(v for k, v in bag.items() if k.endswith('BALL') and k != 'MASTERBALL')
        box = (api('/api/pokemon') or {}).get('pokemon', []); nbox = len(box)
        why = f'볼 {balls}개 — {BALL_KEEP}개는 새 종 몫' if balls < BALL_KEEP else (f'박스 {nbox}마리 — {BOX_KEEP}마리부터는 새 종만' if nbox >= BOX_KEEP else '')
        # 10/27: 박스 정리(box_plan)는 종마다 최종 힘 1등·개체값 1등만 남긴다 — 둘 다 못 넘는 개체는 잡아도 곧 놓아준다
        # (10/26~27 잡은 47마리 중 30마리가 그랬다, 볼값의 2/3). 야생은 드러나면 개체값·성격이 보이므로 미리 거른다
        same = [x for x in box if x['species'] == pm.get('species')]
        if not why and same and pm.get('ivs'):
            try:
                if final_power(pm) <= max(map(final_power, same)) and iv_sum(pm) <= max(map(iv_sum, same)): why = '힘·개체값 모두 가진 것 이하 — 잡아도 박스 정리에서 놓아줌'
            except Exception: pass
        # 11/11 효율 점검: 11/09~11 이미 잡은 종 65마리를 잡음(볼 약 110개 ≈ 6.6만 원) — 거의 다 팀에 못 드는 박스용. 돈이 볼 사기 하한 밑이면
        # (볼을 못 사니 새 종 몫이 줄어듦) 팀 최약(주력·랭크 팀)보다 약한 개체는 길드 '잡기' 미션이 남았을 때만 잡는다. 돈이 넉넉하면 예전처럼 모두 잡기
        if not why and not guild_mission_left('catch'):
            try:
                if ((api('/api/me') or {}).get('money') or 0) < MONEY_FLOOR:
                    try: mine_ = json.load(open(GROW, encoding='utf-8')).get('ids') or []
                    except Exception: mine_ = []
                    fl, fp = team_floor(box, mine_), final_power(pm)
                    if fl and fp < fl: why = f'돈 {MONEY_FLOOR:,}원 밑이라 볼 아낌 — 팀 최약보다 약함(힘 {fp:.0f} < {fl:.0f})'
            except Exception: pass
        if why and not up:
            api_post(f"/api/wild/{w['id']}/flee", {}); say('포획', f"{tag} {name}: 이미 잡은 종 → 보내 줌 ({why})"); return
        out.append(up or '이미 잡은 종 — 잡음')
    # 선두는 파티 첫 자리 — 야생 레벨보다 한참 높은 선두(Lv99 로즈레이드 vs Lv92 토게피)는 어떤 기술도 한 방이라 서버 잡기 모드가
    # 체력 100%에서 바로 'nosafe'(던질 때)를 줘 몬스터볼 6개가 다 빠졌다(10/11 11:35). 배틀 걸기 직전에 '야생 레벨-5 이상 중 가장 낮은 레벨'을
    # 첫 자리로(교체 규칙 after_lost 와 같음), 배틀이 시작되면(선두는 그때 정해짐) 원래 순서로 되돌린다
    ALL = (api('/api/pokemon') or {}).get('pokemon', [])
    wl, P0 = pm.get('level') or 0, [p for p in ALL if p['onDesktop']]
    # 길드 미션 '야생 포켓몬과 싸워 이기기'는 쓰러뜨려야 오른다 — 잡기 모드(always)는 안 쓰러뜨려서 하루 2/5에 그쳤다(10/13).
    # 미션이 남았고 이미 가진 종(이색 아님)이면 끝까지 싸운다(off): 미션도 채우고 박스에 겹치는 종도 안 늘어난다
    gm = {x['key']: x for x in ((api('/api/guild') or {}).get('mission') or {}).get('missions', [])}
    fight = not bondm and 'battle' in gm and not gm['battle'].get('done') and not pm.get('shiny') and pm.get('species') in {p['species'] for p in ALL}
    if fight: out.append('길드 미션용 — 쓰러뜨림')
    order0 = [p['id'] for p in sorted(P0, key=lambda p: (p.get('slot') if p.get('slot') is not None else 99, p['id']))]
    # 레벨만 보면 센 기술뿐인 선두가 체력 47~49%에서 멈춰(서버 'nosafe': 급소면 쓰러뜨림) 6번 다 빠졌다(11:55 비비용, 12:13 하마돈 —
    # 약한 솜솜코로 바뀌자 22%까지 깎음). 서버는 '급소·최대 난수로도 안 쓰러지는' 기술로만 깎으므로, 가장 약한 기술의 급소 최대 피해가
    # 상대 최대 체력의 25%(서버가 멈추는 선) 이하인 포켓몬을 먼저 — 그중 레벨 낮은 것, 없으면 그 피해가 가장 작은 것
    fsp = SPECIES.get(pm.get('species') or '') or {}
    foe = {'species': pm.get('species'), 'level': wl or 50, 'typeIds': fsp.get('types') or []}
    fhp = ((2 * (fsp.get('base') or {}).get('hp', 80) + 31) * (wl or 50) / 100) + (wl or 50) + 10
    def chip(p):   # 가장 약한 공격 기술의 급소(×1.5)·최대 난수(÷0.925) 피해 / 상대 최대 체력
        me = {'stats': p['info']['stats'], 'level': p['level'], 'typeIds': (SPECIES.get(p['species']) or {}).get('types') or []}
        ds = [damage(me, dict(MOVES[k], key=k), foe) for k in p.get('moves') or [] if k in MOVES]
        ds = [d for d in ds if d > 0]
        return min(ds) * 1.5 / 0.925 / fhp if ds else 9
    fit = sorted((p for p in P0 if p['level'] >= wl - 5), key=lambda p: (chip(p) > 0.25, p['level'] if chip(p) <= 0.25 else chip(p)))
    moved = bool(fit and order0 and fit[0]['id'] != order0[0]) and bool(api_post('/api/pokemon/order', {'ids': [fit[0]['id']] + [i for i in order0 if i != fit[0]['id']]}).get('ok'))
    st = api_post(f"/api/wild/{w['id']}/battle", {})
    if moved: api_post('/api/pokemon/order', {'ids': order0})
    bt = st.get('battle') or {}
    if not bt.get('id'):   # 배틀을 못 걸면 예전처럼 볼만 던짐
        opts = r.get('ballOptions') or []
        for n in range(catch_tries()):
            pick = pick_ball(opts)
            if not pick: out.append('던질 볼 없음'); break
            c = api_post(f"/api/wild/{w['id']}/catch", {'ball': pick['id'], 'hour': h, 'exp': True})
            if 'caught' not in c: out.append(f"{pick['kr']} 실패({str(c.get('detail') or c)[:40]})"); break
            out.append(('추천 ' if pick.get('best') else '') + pick['kr'] + ' 던짐')
            if c['caught']: out.append('잡음'); break
            out.append('빠짐'); opts = c.get('ballOptions') or opts
        say('포획', f"{tag} {name}: 배틀 못 걺({str(st.get('detail'))[:30]}) →", ' → '.join(out)); return
    bid, opts = bt['id'], st.get('ballOptions') or []
    lead = ((bt.get('me') or {}).get('name')) or '?'
    out.append(f'{lead} 출전')
    down = set()
    def after_lost(m):   # 내 포켓몬이 쓰러지면 남은 파티 중 레벨 높은 것을 내보냄
        # 볼을 던진 턴에 쓰러지면 서버 답에 다음 파티 목록(party)이 없다(기술 턴만 실어 줌) → 데리고 다니는 포켓몬에서 직접 고른다.
        # 예전엔 '다 쓰러짐'으로 끝내 야생을 놓쳤다(10/11 09:55 불비달마)
        down.update(m.get('fainted') or [])
        cur = ((m.get('battle') or {}).get('me') or {}).get('id')
        if cur: down.add(cur)
        party = m.get('party')
        if party is None:
            party = [q for q in api('/api/pokemon')['pokemon'] if q['onDesktop'] and q['id'] not in down and q.get('hp', 1) > 0]
        if not party: out.append('다 쓰러짐'); return False
        # 너무 센 포켓몬(Lv100 메가 주력)은 어느 기술이든 한 방에 쓰러뜨려서 서버 잡기 모드가 체력을 못 깎고 바로 '던질 때'를 준다
        # → 체력 50~70%에 볼만 6개 던지고 놓쳤다(10/11 10:20 그랑블루·10:38 나무킹, 리자몽 교체). 야생 레벨−5 이상인 것 중 가장 낮은 레벨, 없으면 가장 높은 것
        fl = pm.get('level') or 0
        ok = sorted((q for q in party if q.get('level', 0) >= fl - 5), key=lambda q: q.get('level', 0))
        nx = ok[0] if ok else max(party, key=lambda q: q.get('level', 0))
        down.add(nx['id'])
        sw = api_post(f'/api/battle/{bid}/switch', {'pokemon': nx['id']})
        out.append(f"{nx.get('name') or nx.get('info', {}).get('name', '?')}로 교체")
        return bool((sw.get('battle') or {}).get('id')) and not (sw.get('battle') or {}).get('over')
    for _ in range(25):
        m = api_post(f'/api/battle/{bid}/move', {'move': 'AUTO', 'catch': 'off' if fight else 'always', 'hour': h})
        b2 = m.get('battle') or {}
        opts = m.get('ballOptions') or opts
        if not b2: out.append(f"기술 실패({str(m.get('detail'))[:30]})"); break
        if b2.get('over'):
            res = b2.get('result')
            if res == 'lost' and after_lost(m): continue
            if res != 'lost': out.append({'won': '이김' if fight else '쓰러뜨림(못 잡음)', 'fled': '도망감'}.get(res, str(res)))
            break
        if not m.get('hold'): continue
        if throws >= catch_tries(): api_post(f'/api/battle/{bid}/run', {}); out.append(f'{throws}번 다 빠짐 → 보내 줌'); break
        pick = pick_ball(opts)
        if not pick: api_post(f'/api/battle/{bid}/run', {}); out.append('던질 볼 없음'); break
        c = api_post(f'/api/battle/{bid}/ball', {'ball': pick['id'], 'hour': h, 'exp': True}); throws += 1
        if 'caught' not in c: out.append(f"{pick['kr']} 실패({str(c.get('detail') or c)[:40]})"); break
        hp = (b2.get('foe') or {}).get('hp'), (b2.get('foe') or {}).get('maxhp')
        out.append(('추천 ' if pick.get('best') else '') + pick['kr'] + ' 던짐' + (f"(체력 {round(100 * c['hpRatio'])}%)" if c.get('hpRatio') is not None else ''))
        if c['caught']: out.append('잡음' + (' (도감 새 종)' if dexm and not dex_has(pm.get('species')) else '')); globals()['dex_caught_at'] = 0; break   # 10/19: 이미 잡은 종도 '새 종'으로 찍혔음
        out.append('빠짐'); opts = c.get('ballOptions') or opts
        cb = c.get('battle') or {}
        if cb.get('over'):
            if cb.get('result') == 'lost' and after_lost(c): continue
            if cb.get('result') == 'fled': out.append('도망감')
            break
    say('포획', f"{tag} {name}:", ' → '.join(out))

gym_api_at = 0
def money_rest_ok(P):
    # 10/27 사용자 '관장전은 돈 모으는 데 집중': 상금 없는 수련 판은 얻을 게 있을 때만 — 바탕화면에 Lv100 아래(알에서 나온 전설 등)가
    # 있어 경험치가 쓰이거나, 길드 '관장 이기기' 미션이 남았을 때. 10/26엔 6마리 다 Lv100이라 하루 1,700판이 경험치 0이었다
    # 11/11: 노력치 자리가 채울 능력이 남았거나 유대 '직접 쓰러뜨리기'가 남은 것도 얻을 것
    return any(p['level'] < 100 for p in P) or guild_mission_left('gym') or bool(ev_need(P)) or any(p.get('id') in bond_ko for p in P)

def money_hard(r, paid, run):
    # 10/30 사용자 '50곳도 이겨서 돈 벌어야지': 이긴 곳(상금)은 바탕화면 4마리(육성 악비아르 선두)로만 싸워 Lv90~100 약 50곳이 5연패·쉼
    # → 상금 관장 중 Lv90 이상이거나 진 적 있는 곳은 박스 전체 맞춤 파티(gym_party), 판 끝나면 boss_restore 가 바탕화면 원래대로
    return r in paid and (r['level'] >= 90 or run.get(r['region'], 0) > 0)

def money_left(regions, lost):
    return sorted((r for r in regions if r['cleared'] and not r.get('today') and r['region'] not in lost and r['region'] not in gym_skip), key=lambda r: -r['level'])

def gym_api_step(pid):
    # 화면이 잠기면 진짜 클릭이 게임에 안 닿는다(10/11 01:20~ 잠김 화면에서 관장·풀숲 1시간 넘게 멈춤). 관장전은 게임 창이 하는 일을
    # 서버 요청(/api/gym/{region}/start · /api/gym/battle/{id}/act)으로 그대로 할 수 있다 → 잠긴 동안만 서버로 직접 진행.
    # 고르는 규칙은 화면 관장전과 같다: 수련 = 상한 안 가장 높은 이긴 곳, 육성 포켓몬 앞자리·우대, 관장전 끝에 육성 교체 빈틈
    global gym_api_at, gym_team_max
    if not os.path.exists(CHAIN) or time.time() - gym_api_at < 3: return
    gym_api_at = time.time()
    safe('악당 되돌림', boss_restore)   # 1마리로 싸운 악당 판이 끝났으면(사냥기 재시작 뒤 포함) 바탕화면 원래대로
    j = api('/api/gym/battle'); b = j.get('battle') or {}
    if (not b or b.get('over')) and (safe('악당', boss_try) or safe('길드전', gw_try)): return   # 10/19 전설 우선: 판 진행은 아래와 같은 길
    if not b or b.get('over'):
        info = api('/api/gym'); judge(info)
        P = [p for p in api('/api/pokemon')['pokemon'] if p['onDesktop']]
        cap = min(max((p['level'] for p in P), default=0), 999 if gym_focus() else gym_cap()); lost = lost_today()
        # 고르는 순서는 화면 관장(gym_next)과 같다: 유대 미션 타입 관장(안 이긴 곳 > 높은 곳) > 안 이긴 곳(낮은 순) > 수련(train_pick)/다시 이기기
        can = lambda r: r['region'] not in lost and r['region'] not in gym_skip and r['level'] <= cap
        bt = bond_gym_types() or set()
        bond = sorted((r for r in info['regions'] if can(r) and r.get('type') in bt), key=lambda r: (r['cleared'], bool(r.get('today')), -r['level'] if r['cleared'] else r['level']))   # 11/11: 상금 남은 곳 먼저
        new = sorted((r for r in info['regions'] if can(r) and not r['cleared']), key=lambda r: r['level'])
        done = rewin_done()
        # 10/29 사용자: 상금 관장은 상한(수련용, 질 때마다 5씩 내려감)을 안 본다 — 04시 Lv95·100 몇 판 지자 상한 90 → 남은 21곳(10,300원)을
        # '다 받음'으로 치고 하루 종일 쉼. 진 관장은 30분 쉼(gym_skip)·5연패 3일 쉼(lost)으로 충분
        paid = money_left(info['regions'], lost) if money_on() else []
        global money_said
        if money_on() and not paid and money_said != time.strftime('%Y-%m-%d'):
            money_said = time.strftime('%Y-%m-%d')
            got = [r for r in info['regions'] if r['cleared'] and r.get('today')]
            say(f"돈 모드: 오늘 상금 다 받음 ({len(got)}곳, {sum(r['level'] * 5 for r in got):,}원) → " + ('수련으로' if money_rest_ok(P) else '관장 쉼 (0시에 상금 다시)'))
        rest = [] if money_on() and not money_rest_ok(P) else \
            train_pick([r for r in info['regions'] if can(r) and r['cleared']], P) if train_on() \
            else sorted((r for r in info['regions'] if can(r) and r['cleared'] and r['region'] not in done), key=lambda r: -r['level'])
        global money_n
        paid = ev_sort(paid, P)   # 11/11: 노력치 자리에 필요한 능력을 주는 상금 관장 먼저 (받는 상금 합은 같음)
        hi = [r for r in paid if r['level'] >= cap - MONEY_HI]
        lo = [r for r in paid if r['level'] < cap - MONEY_HI]
        every = money_every(len(lo))
        # 11/11 사용자 '낮은 관장 찾아서 하면 되잖아': 유대 '직접 30번 쓰러뜨리기'가 남았으면 그 포켓몬이 때릴 수 있는 가장 낮은 이긴 관장
        # (상금 남은 곳 먼저). 낮은 곳은 맞춤 파티(money_hard, Lv90+) 대신 바탕화면 파티 + 선두(gym_lead) → 혼자 6마리를 쓰러뜨려 5~6판이면 참
        kp = [p for p in P if p['id'] in bond_ko]
        kob = [] if bond or not kp else sorted((r for r in info['regions'] if can(r) and r['cleared'] and r['level'] < 90 and all(grow_hit(p, r.get('type')) for p in kp)),
                                                key=lambda r: (bool(r.get('today')), r['level']))
        if kob: say(f"유대 미션(직접 쓰러뜨리기): {', '.join(p['info']['name'] for p in kp)} → 낮은 관장 {kob[0]['region']} {kob[0].get('name')} Lv.{kob[0]['level']}")
        ok = bond or kob or new or hi or (lo if money_n >= every - 1 or not rest else []) or rest
        if not ok: gym_api_at = time.time() + 57; return   # 갈 관장이 없으면 1분 뒤 (10/16 저렙 시험: Lv20 미만이면 3초마다 요청 3개씩만 보냄)
        r0 = ok[0]; lv, code = r0['level'], r0['region']
        if not bond and not kob and not new and paid and r0 in paid:
            if r0 in lo: money_n = 0
            say(f"돈 모드: 상금 {lv * 5:,}원 관장 (오늘 남은 {len(paid)}곳{f', 낮은 곳 {every}판에 1판 — 마감까지 맞춤' if r0 in lo else ''})")
        elif not bond and not kob and not new: money_n += 1
        if bond: say(f"유대 미션: {', '.join((TYPES.get(t) or {}).get('kr', t) for t in bt)} 타입 관장 먼저 → {code} {r0.get('name')}")
        hard = money_hard(r0, paid, gym_state_load().get('loss_run') or {})
        if hard and not boss_solo():
            json.dump([p['id'] for p in sorted(P, key=lambda p: (p.get('slot') if p.get('slot') is not None else 99, p['id']))], open(BOSS_SOLO, 'w', encoding='utf-8'))
        if (gym_focus() and not r0['cleared']) or hard: safe('관장 맞춤 파티', gym_party, code)
        else: safe('관장 선두', gym_lead, r0.get('type'))
        r = api_post(f'/api/gym/{code}/start', {})
        if not r.get('battle'): gym_skip.add(code); say(f"관장(서버 직접) 시작 실패: {code} {str(r.get('detail'))[:50]}"); return
        st = gym_state_load(); st['target'] = {'region': code, 'cleared': r0['cleared'], 'wins': r0.get('wins', 0), 'level': lv}; gym_state_save(st)   # 안 이긴 곳도 True 로 적어 judge 가 30분 쉬게 했다(10/14 올클리어 5분이 30분이 됨)
        say(f"관장(서버 직접{', 화면 잠김' if locked_now() else ''}): {code} {r0.get('name')} Lv.{lv} 시작"); globals()['gym_gap'] = False
        status(관장=f"진행 중: {r0.get('name')} Lv{lv} (서버)")
        return
    try: grow_ids = set(json.load(open(GROW, encoding='utf-8')).get('ids') or [])
    except Exception: grow_ids = set()
    team, slot = b['me']['team'], b['me']['slot']
    me, foe = team[slot], b['foe']['team'][b['foe']['slot']]
    growing = lambda m: gym_pref(m, grow_ids)
    gb = lambda m: 3 if growing(m) else 1
    bench = sorted(((value(m, foe) * gb(m), i) for i, m in enumerate(team) if i != slot and not m.get('fainted') and m.get('hp', 0) > 0), reverse=True)
    if b.get('needSwitch'):
        if not bench: return
        pick = grow_first(bench, team, foe, growing)
        r = api_post(f"/api/gym/battle/{j['id']}/act", {'kind': 'switch', 'slot': pick, 'hour': time.localtime().tm_hour})
        say(f"관장(서버 직접) {b['turn']}턴: {foe['name']} 상대로 {team[pick]['name']} 내보냄" + ('' if r.get('battle') else f" 실패 {str(r.get('detail'))[:40]}"))
        return
    sc, mi = best_move(me, foe)
    if sc < 0: mi = 0
    mv = me['moves'][mi]
    mega = bool(b.get('canMega') and not b.get('megaUsed'))
    # 10/19 Z기술(시즌 4): 고른 공격기가 Z로 바뀔 수 있으면(Z크리스탈을 지님) 그 판 한 번 쓴다 - 메가와 같은 턴엔 안 씀
    gm = b.get('gimmick') or {}
    zon = not mega and not gm.get('zUsed') and mv['key'] in {z.get('key') for z in gm.get('zMoves') or [] if not z.get('status')}
    r = api_post(f"/api/gym/battle/{j['id']}/act", {'kind': 'move', 'move': mv['key'], 'mega': mega, 'z': zon, 'hour': time.localtime().tm_hour})
    nb = r.get('battle') or {}
    say(f"관장(서버 직접) {b['turn']}턴: {me['name']} → {mv['kr']} (상성 ×{eff(mv['type'], foe['typeIds']):g}, 상대 {foe['name']})" + (' +메가진화' if mega else '') + (' +Z기술' if zon else '') + ('' if nb else f" 실패 {str(r.get('detail'))[:40]}"))
    nf = ((nb.get('foe') or {}).get('team') or [])
    fs = b['foe']['slot']
    if fs < len(nf) and (nf[fs].get('fainted') or nf[fs].get('hp', 1) <= 0):   # 이번 수로 상대가 쓰러짐 → 시간별 지표의 '육성 포켓몬이 직접 쓰러뜨린 비율'
        say(f"관장 쓰러뜨림(서버 직접): {me['name']} → {foe['name']} ({'육성' if me.get('id') in grow_ids and me.get('level', 100) < 100 else '주력'})")
    if nb.get('over'):
        say(f"관장(서버 직접) 끝: {({'won': '이김', 'lost': '짐', 'draw': '비김'}).get(nb.get('result'), nb.get('result'))}"); globals()['gym_gap'] = True
        safe('악당 되돌림', boss_restore)
        status(관장=f"대기: 방금 {'이김' if nb.get('result') == 'won' else {'lost': '짐', 'draw': '비김'}.get(nb.get('result'), nb.get('result'))}")
        if nb.get('result') == 'draw':
            # 비김 = 상대를 다 쓰러뜨렸는데 마지막 수의 반동(플레어드라이브)으로 내 마지막 포켓몬도 쓰러짐 → 경험치는 다 받았다.
            # 서버 기록상 승리가 아니라 judge 가 '짐'으로 보고 상한을 내리고 있었다(10/11 09:37~09:46 달리아 3번) → 판정 없이 넘김
            st = gym_state_load(); st['target'] = None; gym_state_save(st); say('관장 비김: 상대는 다 쓰러뜨림 — 상한 그대로')

def gym_fighting():
    # 관장 배틀이 실제로 진행 중인가. 관장 창(gym_window)은 이어 도전 내내 열려 있어서 그것으로 막으면
    # 육성 교체·기술 배우기가 몇 시간씩 안 돌았다 (10/10 08:03 이후) → 판과 판 사이에는 돌게 한다
    # 관장 판 사이 빈틈(약 16초)엔 사냥기가 다음 관장을 고르느라 바빠서, 이 검사만으로는 육성 교체가 거의 안 돌았다
    # (10/10 13:42 4자리로 바꿨는데 8분째 그대로) → '관장전 끝'을 누른 직후(gym_gap)엔 진행 중이 아닌 것으로 본다
    if globals().get('gym_gap'): return False
    try:
        b = api('/api/gym/battle').get('battle') or {}
        return bool(b) and not b.get('over')
    except Exception: return True

# 11/11 사용자: 육성 자리에서 2시간 동안 진행(레벨·경험치·친밀도·지킬 노력치·유대 미션)이 하나도 안 오르면 이유를 남기고 박스로, 그날은 다시 안 올림
# (플라엣테·자마젠타가 이틀 넘게 자리를 막았음). 사냥기가 자주 재시작해서 파일에 둔다
STALL, STALL_SEC = os.path.join(HERE, '육성_정체.json'), 2 * 3600
def grow_sig(x):
    ev = x.get('evs') or {}
    b = bond_info(x) if MEGA_OF.get(x['species']) else {}
    return [x['level'], x.get('exp') or 0, x.get('happiness') or 0, sum(ev.get(k, 0) for k in ev_keep(x)), round(bond_prog(b), 3) if b.get('started') else 0]
def grow_stall(mine, byid, now=None):
    # 육성 자리 각 포켓몬의 진행 서명이 STALL_SEC 동안 같으면 그날 금지 목록에 올린다. 돌려줌: 오늘 금지 id → 이유
    now, today = now or time.time(), time.strftime('%Y-%m-%d')
    try: st = json.load(open(STALL, encoding='utf-8'))
    except Exception: st = {}
    seen, ban = st.get('seen') or {}, {k: v for k, v in (st.get('ban') or {}).items() if v.get('day') == today}
    for i in mine:
        k, sig = str(i), grow_sig(byid[i])
        if k in ban: continue
        if (seen.get(k) or {}).get('sig') != sig: seen[k] = {'sig': sig, 't': now}
        elif now - seen[k]['t'] >= STALL_SEC:
            why = f"{grow_note(byid[i])} — {int((now - seen[k]['t']) // 60)}분 동안 레벨·친밀도·노력치·유대 미션 그대로"
            ban[k] = {'day': today, 'why': why}; seen.pop(k, None)
    seen = {k: v for k, v in seen.items() if int(k) in mine}
    try: json.dump({'seen': seen, 'ban': ban}, open(STALL, 'w', encoding='utf-8'), ensure_ascii=False)
    except Exception: pass
    return {int(k): v['why'] for k, v in ban.items()}

def grow_step(pid):
    global grow_at
    if LITE: return
    try: c = json.load(open(CONF, encoding='utf-8'))
    except Exception: return
    if not c.get('육성슬롯', False) or (time.time() - grow_at < 120 and not gym_gap) or battle or fight or boss_solo() or gym_fighting(): return
    grow_at = time.time()
    n, plist, goal = max(1, min(6, int(c.get('육성_자리수', 1)))), c.get('육성_목록', []), int(c.get('육성_목표레벨', 60))
    n0, n = n, max(0, n - eggs_desk)   # 10/19: 알이 육성 자리를 쓴다 (egg_step)   # 4까지 (10/10: 주력 Lv100 이 쓰러뜨린 경험치는 버려짐)
    P = [x for x in api('/api/pokemon')['pokemon'] if not x.get('away')]; byid = {x['id']: x for x in P}   # 탐험 중은 못 꺼냄 (10/16 저렙 시험: 박스 최고 레벨이 탐험에 나감)
    desk0 = {x['id'] for x in P if x['onDesktop']}
    try: g = json.load(open(GROW, encoding='utf-8')); mine = g.get('ids') or ([g['id']] if g.get('id') else [])
    except Exception: mine = []
    mine = [i for i in mine if i in byid and byid[i]['onDesktop']]
    if sum(1 for x in P if x['onDesktop'] and x['id'] not in mine) > 6 - n0: globals()['core_due'] = True   # 게임이 새로 잡은 것을 빈자리에 넣음
    try: ban = grow_stall(mine, byid)
    except Exception: ban = {}

    want = [byid[i] for i in plist if i in byid and byid[i]['level'] < goal and (not byid[i]['onDesktop'] or i in mine)]
    if dex_mode():   # 도감 우선(10/15): 레벨로 진화하면 도감에 없는 종이 되는 것을, 남은 레벨이 적은 순으로 (개체값 무관)
        lock = set(api('/api/pvp/team').get('ids') or [])
        def dex_need(x):
            es = [e for e in (SPECIES.get(x['species']) or {}).get('evo') or [] if e.get('mode') == 'level' and e.get('level')
                  and not dex_has(e.get('to')) and (not e.get('gender') or e['gender'] == x.get('gender'))]
            return min((max(1, int(e['level']) - x['level']) for e in es), default=None)
        dw = sorted((x for x in P if x['level'] < 100 and x['id'] not in lock and (not x['onDesktop'] or x['id'] in mine)
                     and x not in want and dex_need(x)), key=lambda x: (dex_need(x), -(x['id'] in mine)))
        # 키울 진화 전 포켓몬이 아직 없으면 저레벨 하나(설정 '도감_저레벨', 쉐이미 Lv30)를 육성 자리에 둬 야생 레벨을 낮춘다 →
        # 진화 전 모습이 나와 잡히면 그것들이 다음 육성이 된다
        low = c.get('도감_저레벨')
        if not dw and low in byid and byid[low]['level'] < 100 and byid[low] not in want: dw = [byid[low]]
        want = want + dw
    lvup = levelup_on()
    # 키울 거리가 있는 것(Lv100 전) 중 최종 예상 전투력 높은 순. 키우던 것은 5% 얹어 자주 바뀌지 않게
    globals()['_grow_pool'] = [x for x in P if not x['onDesktop'] or x['id'] in mine]
    # 1) 팀에 들 만큼 세지는 것(레벨·메가 친밀도)을 자리 1시간당 값 순으로, 2) 남는 자리는 예전처럼 최종 힘 순
    pool = [x for x in P if (not x['onDesktop'] or x['id'] in mine) and lvup and x not in want and x['id'] not in ban]
    floor, rate = team_floor(P, mine), slot_levels_per_hour()
    locked = set(api('/api/pvp/team').get('ids') or []) if rank_locked() else set()
    happy_measure(P)
    val = {x['id']: slot_value(x, floor, rate, locked) for x in pool if grow_ok(x) or (x['level'] >= 100 and MEGA_OF.get(x['species']) and (x.get('happiness') or 0) < 255)}   # 11/11: 255 부터는 유대 미션(grow_ok→bond_live)만 — 둘째 플라엣테가 이 길로 남았음
    globals()['grow_val'] = val
    rel = sorted((x for x in pool if val.get(x['id'], (0,))[0] > 0), key=lambda x: -val[x['id']][0] * (1.05 if x['id'] in mine else 1))
    # 친밀도 자리는 최대 2 (10/13 13시: 5자리 다 Lv100 친밀도 → 경험치 0). ponytail: 고정값, 방울 수 따라 바꿀 일 생기면 그때
    fr = [x for x in rel if val[x['id']][1] == '친밀도'][2:]
    rel = [x for x in rel if x not in fr]
    auto = rel + sorted((x for x in pool if grow_ok(x) and x not in rel), key=lambda x: -final_power(x) * (1.05 if x['id'] in mine else 1))
    want = (want + auto)[:n]
    # 10/19: 육성 자리 하나는 랭크 팀 노력치 채우기 (ev_pick) - 맨 앞에 두고 나머지를 한 칸 민다
    ev_prev = set(ev_ids)
    evm = ev_pick(P, mine) if n >= 1 and not LITE and conf_on('노력치_자동') else None
    globals()['ev_ids'] = {evm['id']} if evm else set()
    if evm and evm not in want: want = ([evm] + want)[:n]
    # 10/20 사용자: 전설·환상은 Lv100 까지 최우선 - 육성 자리 수를 넘어도(주력을 줄여서라도) 데리고 다닌다. 레벨 높은 것부터(빨리 끝남)
    # 10/24 사용자: 전설 친밀도·유대도 최우선 - 메가 되는 전설(라티오스·뮤츠 등)은 Lv100 뒤에도 스톤 받을 때까지(친밀도 255 → 유대 미션) 데리고 다닌다.
    # 메가 없는 전설은 친밀도가 진화·메가에 안 쓰여(은혜갚기 위력뿐) 자리를 안 준다
    legs = sorted((x for x in P if legend_due(x) and (not x['onDesktop'] or x['id'] in mine)), key=lambda x: (x['level'] >= 100, -x['level'], -(x.get('happiness') or 0)))[:6 - eggs_desk]
    legs = [x for x in legs if x['id'] not in ban]
    if ban:   # 오늘 금지(2시간 정체)는 목록·노력치·도감 몫에서도 빼고 빈자리는 다음 후보로
        want = [x for x in want if x['id'] not in ban]
        want += [x for x in auto if x not in want][:max(0, n - len(want))]
        if evm and evm['id'] in ban: globals()['ev_ids'] = set()
    if legs:
        n = min(6 - eggs_desk, n + len([x for x in legs if x not in want])); n0 = max(n0, n + eggs_desk)   # 원래 육성 자리는 그대로 두고 더 얹는다
        want = (legs + [x for x in want if x not in legs])[:n]
    wid = [x['id'] for x in want]
    for i in mine:
        if i not in wid:
            x = byid[i]; api_post(f'/api/pokemon/{i}/desktop', {'on': False})
            fs = final_species(x)
            say(f"육성 끝: {x['info']['name']} Lv{x['level']} → 박스로" + (f" (2시간 진행 없음, 오늘은 다시 안 올림: {ban[i]})" if i in ban else
                f" (메가스톤 {x.get('heldKr') or x.get('held')} 지님 — 진화시키면 메가진화 못 함, 그대로 두세요)" if holds_stone(x) else f' (노력치 다 채움)' if i in ev_prev else f' (목표 Lv{goal})' if i in plist else
                f" (Lv100 — 친밀도 채우기보다 다른 포켓몬 키우기가 더 이득: 자리 1시간당 힘 {friend_why[i][0]:.1f} < {friend_why[i][1]:.1f})" if i in friend_why and friend_why[i][0] < friend_why[i][1] and x['level'] >= 100 and friend_need(x) else
                f" (Lv100·친밀도 다 참 — {(SPECIES.get(fs) or {}).get('kr', fs)}(으)로 수동 진화시켜 주세요)" if x['level'] >= 100 and fs != x['species'] and friend_need(x) == 0 else
                f" (Lv100 — {(SPECIES.get(fs) or {}).get('kr', fs)}(으)로 수동 진화 가능)" if x['level'] >= 100 and fs != x['species'] else
                (f" (Lv100 — 친밀도 채우기보다 다른 포켓몬 키우기가 더 이득: 자리 1시간당 힘 {friend_why[i][0]:.1f} < {friend_why[i][1]:.1f})" if i in friend_why and friend_why[i][0] < friend_why[i][1] and x['level'] >= 100 else ' (Lv100 달성)') if x['level'] >= 100 else ' (더 센 포켓몬에게 자리 양보)'))
            globals()['core_due'] = True
    room = 6 - sum(1 for x in P if x['onDesktop'] and x['id'] not in mine) - len([i for i in mine if i in wid]) - eggs_desk
    short = sum(1 for x in legs if x['id'] not in mine) - room
    if short > 0:   # 전설 자리가 모자라면 가장 약한 주력부터 박스로 (core_step 이 남은 자리로 주력을 다시 고른다)
        for x in sorted((x for x in P if x['onDesktop'] and x['id'] not in mine), key=now_power)[:short]:
            api_post(f"/api/pokemon/{x['id']}/desktop", {'on': False}); room += 1
            say(f"주력 비킴: {x['info']['name']} → 박스로 (전설 육성 최우선)")
    for x in want:
        if x['id'] in mine: continue
        if room <= 0: status(육성=f'데리고 다니는 자리가 모자람 — 육성 {n}자리를 쓰려면 주력을 {6 - n}마리로 줄여 주세요'); break
        r = api_post(f"/api/pokemon/{x['id']}/desktop", {'on': True})
        if r.get('error'): say('육성 자리 바꾸기 실패:', str(r.get('error'))[:60]); continue
        room -= 1; mine.append(x['id'])
        say(f"육성 시작: {x['info']['name']} Lv{x['level']}" + (f' → 목표 Lv{goal}' if x['id'] in plist else f' ({grow_note(x)})'))
    mine = [i for i in mine if i in wid]
    json.dump({'ids': mine}, open(GROW, 'w', encoding='utf-8'))
    core_step(pid, [x for x in api('/api/pokemon')['pokemon'] if not x.get('away')], mine, n0)
    P = {x['id']: x for x in api('/api/pokemon')['pokemon']}
    if {i for i, x in P.items() if x['onDesktop']} != desk0: globals()['held_at'] = 0   # 데리고 다니는 얼굴이 바뀌면 도구를 바로 다시 나눈다 (10/10 사용자)
    status(육성=' · '.join(f"{P[i]['info']['name']} Lv{P[i]['level']}" + (f'/{goal}' if i in plist else '') for i in mine if i in P) or '키울 포켓몬 없음')


global core_due, core_day; core_due, core_day = False, ''
def final_bst(sp, gender=None):
    best = sum((SPECIES.get(sp) or {}).get('base', {}).values() or [0])
    for e in (SPECIES.get(sp) or {}).get('evo') or []:
        if not e.get('gender') or e['gender'] == gender: best = max(best, final_bst(e['to'], gender))
    return best

def core_recheck(P, mine, k, info):
    import itertools
    SELFKO = {'EXPLOSION', 'SELFDESTRUCT', 'MISTYEXPLOSION', 'FINALGAMBIT'}
    kr2id = {v['kr']: t for t, v in TYPES.items()}
    def mon(p):
        mv = [(m, MOVES[m]) for m in p['moves'] if m in MOVES]
        return dict(p=p, types=[kr2id.get(x, x) for x in p['info']['types']], st=p['info']['stats'], lv=p['level'], mv=mv,
                    natk=sum(1 for m, v in mv if v['cat'] != 'status' and v['power'] and m not in SELFKO),
                    pot=(1 + max(0, final_bst(p['species'], p.get('gender')) - 450) / 2000)
                    # 10/19: 메가스톤을 지녔으면 메가 힘 비율만큼 (ponytail: 한 판에 메가는 하나뿐인데 여럿 다 쳐 줌 - 주력에 스톤 둘 이상이면 손볼 것)
                    * (species_power(p, p['species'], p['level']) / max(1e-9, species_power(p, p['species'], p['level'], mega=False)) if holds_stone(p) else 1))
    def off(m, dt):
        best = 0
        for key, v in m['mv']:
            if v['cat'] == 'status' or not v['power']: continue
            lo, hi = v.get('hits', [1, 1]); hits = 3.1 if (lo, hi) == (2, 5) else (lo + hi) / 2
            f = (0.25 if key in SELFKO else 1) * (0.5 if 'charge' in v.get('flags', []) else 1) * (0.6 if 'recharge' in v.get('flags', []) else 1)
            a = m['st']['atk' if v['cat'] == 'physical' else 'spa']
            best = max(best, ((2 * m['lv'] / 5 + 2) * v['power'] * a / 150 / 50 + 2) * (1.5 if v['type'] in m['types'] else 1) * eff(v['type'], [dt]) * (v['acc'] or 100) / 100 * hits * f)
        return best
    tlist = [t for t in TYPES if t != 'STELLAR']
    # 관장 상한(gym_cap)은 이기고 질 때마다 ±5 오르내린다 → 상한 75엔 리자몽, 85엔 가디안이 더 좋다고 나와 주력이 몇 분마다 오갔다
    # (10/11 12:07~13:37 7번, 바뀔 때마다 도구도 다시 나눔). 주력은 상한이 아니라 내 팀 레벨 기준 관장 전체로 평가 → 포켓몬 구성이 바뀔 때만 바뀜
    cap = gym_team_max or 100
    tg = [r for r in info['regions'] if not r['cleared'] and r['level'] <= cap + 10] + sorted((r for r in info['regions'] if r['cleared']), key=lambda r: -r['level'])[:10]
    w = {t: sum(1 for r in tg if r.get('type') == t) + sum(1 for r in tg if not r.get('type')) / len(tlist) + 0.3 for t in tlist}
    def val(m, t):
        bulk = (m['st']['hp'] * (m['st']['def'] + m['st']['spd']) / 2) ** 0.5
        return off(m, t) / max(max(eff(t, m['types']) for _ in (0,)), 0.25) * bulk / 100 * (1 + m['st']['spe'] / 400) * m['pot']
    # 주력 = 육성 자리(mine)를 뺀 나머지. 원본은 'in mine' 이라 육성 포켓몬만 놓고 골라서 진짜 주력은 한 번도
    # 평가하지 않았다(기록에 '주력()'). 박스·파티 전체에서 고르고, 새로 잡혀 빈자리에 저절로 들어온 것도 여기서 정리된다.
    allm = [mon(p) for p in P if p['id'] not in mine]
    ms = [m for m in allm if m['natk'] >= 2]
    V = {m['p']['id']: {t: val(m, t) for t in tlist} for m in allm}
    def score(team):
        sc = 0
        for t in tlist:
            vs = sorted((V[m['p']['id']][t] for m in team), reverse=True) + [0]
            sc += w[t] * (vs[0] + 0.5 * vs[1])
        return sc / sum(w.values())
    cur = [m for m in allm if m['p']['onDesktop']]
    pool = sorted(ms, key=lambda m: -sum(V[m['p']['id']][t] * w[t] for t in tlist))[:14]
    for m in cur:
        if m not in pool and m in ms: pool.append(m)
    legend = lambda m: bool((SPECIES.get(m['p']['species']) or {}).get('legendary') or (SPECIES.get(m['p']['species']) or {}).get('mythical'))
    best = max((c for c in itertools.combinations(pool, k) if sum(map(legend, c)) <= 1), key=score, default=None)   # 관장: 전설·환상 팀당 1마리
    if best is None: return cur, [], 0, 0   # 박스로 보낸 직후 등 후보가 k 마리보다 적음 (원본은 ValueError)
    cs, bs = score(cur) if cur else 0, score(best)
    return cur, list(best), cs, bs

def core_step(pid, P, mine, n):
    global core_due, core_day
    today = time.strftime('%Y-%m-%d')
    if not (core_due or core_day != today): return
    core_due, core_day = False, today
    if 6 - n <= 0:   # 6자리 모두 육성 (10/10 시험): 주력을 전부 박스로
        out = [p for p in P if p['onDesktop'] and p['id'] not in mine]
        for p in out: api_post(f"/api/pokemon/{p['id']}/desktop", {'on': False})
        if out: say(f"주력 정리: {', '.join(p['info']['name'] for p in out)} → 박스로 (6자리 모두 육성)")
        return
    cur, best, cs, bs = core_recheck(P, set(mine), 6 - n, api('/api/gym'))
    names = lambda ms: ', '.join(f"{m['p']['info']['name']} Lv{m['lv']}" for m in ms)
    if not best or (bs < cs * 1.05 and len(cur) <= 6 - n):   # 주력이 자리 수(6-육성)보다 많으면 점수와 상관없이 정리 → 육성 자리 확보
        say(f'주력 점검: 지금 주력({names(cur)})이 가장 좋음 — 그대로'); return
    out = [m for m in cur if m not in best]; inn = [m for m in best if m not in cur]
    for m in out: api_post(f"/api/pokemon/{m['p']['id']}/desktop", {'on': False})
    for m in inn: api_post(f"/api/pokemon/{m['p']['id']}/desktop", {'on': True})
    if inn and not cur: say(f'주력 채움: {names(inn)}')
    elif inn: say(f'주력 교체({bs / max(cs, 1) * 100 - 100:+.0f}%): {names(out)} → {names(inn)} / 새 주력 {names(best)}')
    else: say(f'주력 정리: {names(out)} → 박스로 (주력 {6 - n}자리 초과 — 육성 자리 비움) / 주력 {names(best)}')

def api_post(path, body):
    # 11/05: 집중 중인 포켓몬은 바탕화면에서 안 뺀다 (빠지면 서버가 집중을 끝내고 진행 중 세트를 버림) - 관장 맞춤 파티 등 빼는 곳이 여럿이라 여기 한 곳에서
    if FOCUS_PID and path == f'/api/pokemon/{FOCUS_PID}/desktop' and body.get('on') is False: return {'skip': '집중 중'}
    tok = json.load(open(os.path.join(GDIR, 'session.json'), encoding='utf-8'))['token']
    base = json.load(open(os.path.join(GDIR, 'settings.json'), encoding='utf-8'))['server']
    return _http.post(base + path, json=body, headers={'Authorization': 'Bearer ' + tok, 'Accept': 'application/json'}, timeout=15).json()


_err_last = {}
def safe(name, f, *a):
    try: return f(*a)
    except Exception:
        tb = traceback.extract_tb(sys.exc_info()[2])[-1]
        msg = f'오류({name}, 계속 진행) {traceback.format_exc().strip().splitlines()[-1]} @줄 {tb.lineno}'
        if 'NameResolution' in msg or 'nodename nor servname' in msg: dns_trouble()
        _errs.append(time.time())
        if _err_last.get(name) != msg or time.time() - _err_last.get(name + 't', 0) > 300:
            say(msg); _err_last[name] = msg; _err_last[name + 't'] = time.time()

# ---------------------------------------------------------------- 이상 감지·자동 복구 (2026-10-10)
# 일어날 수 있는 문제를 경우별로 감지하고, 안전한 것은 스스로 고치고, 모두 '이상 감지:' + 이상_기록.json 에 남긴다
ANOM = os.path.join(HERE, '이상_기록.json')
_errs, _anom_last, _gym_seen_turn, _gym_stalls, _nogame_since, _lv100_since, wd_at = [], {}, (None, 0), [], 0, {}, 0
def anomaly(kind, msg, every=1800):
    if time.time() - _anom_last.get(kind, 0) < every: return False
    _anom_last[kind] = time.time(); say(f'이상 감지[{kind}]: {msg}')
    try: d = json.load(open(ANOM, encoding='utf-8'))
    except Exception: d = []
    d.append({'at': time.strftime('%m-%d %H:%M:%S'), 'kind': kind, 'msg': msg}); json.dump(d[-500:], open(ANOM, 'w', encoding='utf-8'), ensure_ascii=False)
    return True

def watchdog(pid):
    global _gym_seen_turn, _lv100_since, wd_at
    now = time.time()
    # 1) 관장전이 같은 턴에서 3분 넘게 멈춤 (예: 기술 3개 포켓몬 → 13:20~27) - 사람이 쓰는 중(잠시 멈춤)은 제외
    top = gym_window(pid) if now - _anom_last.get('_gymchk', 0) > 20 else None   # 20초마다만 (서버 부담)
    if top: _anom_last['_gymchk'] = now
    if top and not gym_paused:
        j = api('/api/gym/battle'); b = j.get('battle') or {}
        k = (j.get('id'), b.get('turn'), b.get('needSwitch')) if b and not b.get('over') else None
        if k != _gym_seen_turn[0]: _gym_seen_turn = (k, now)
        elif k and now - _gym_seen_turn[1] > 180:
            me = (b.get('me') or {}).get('team', [{}])[(b.get('me') or {}).get('slot', 0)] if b.get('me') else {}
            diag = f"턴 {b.get('turn')} 교체필요 {b.get('needSwitch')} {me.get('name')} 기술 {len(me.get('moves') or [])}개 · 기술단추 {len(kids(top, 304, 91, 12, 8))} · 교체단추 {len(kids(top, 201, 73, 12, 8))}"
            _gym_stalls[:] = [t for t in _gym_stalls if now - t < 1800] + [now]; _gym_seen_turn = (k, now)
            if len(_gym_stalls) >= 2:
                anomaly('관장 멈춤', f'{diag} → 30분 안에 두 번째, 게임 다시 켬', 60); game_restart_mac('관장전 멈춤 반복')
            else:
                anomaly('관장 멈춤', f'{diag} → 관장 창 닫고 다시 이어 함', 60)
                try: win32gui.PostMessage(top, 16, 0, 0)
                except Exception: pass
    if now - wd_at < 60: return
    wd_at = now
    # 2) Lv100(자리 지킬 이유 없음)이 육성 자리에 15분 넘게 → 육성 교체 강제
    try: mine = json.load(open(GROW, encoding='utf-8')).get('ids') or []
    except Exception: mine = []
    P = {p['id']: p for p in api('/api/pokemon')['pokemon']}
    stuck = [i for i in mine if i in P and P[i]['level'] >= 100 and not grow_ok(P[i]) and grow_val.get(i, (0, ''))[1] != '친밀도' and i not in ev_ids]   # 노력치 자리는 Lv100 이어도 지킴
    for i in list(_lv100_since):
        if i not in stuck: _lv100_since.pop(i)
    for i in stuck: _lv100_since.setdefault(i, now)
    old = [i for i in stuck if now - _lv100_since[i] > 900]
    if old:
        c = {}
        try: c = json.load(open(CONF, encoding='utf-8'))
        except Exception: pass
        why = '조종판 육성 슬롯이 꺼져 있음' if not c.get('육성슬롯') else '교체가 안 돔 → 다음 빈틈에 강제 실행'
        anomaly('육성 정체', f"Lv100 {', '.join(P[i]['info']['name'] for i in old)} 이 15분 넘게 육성 자리 · {why}")
        globals()['grow_at'] = 0; globals()['gym_gap'] = True
    # 3) 오류가 쏟아짐 (10분 30건+) → 사냥기 새로 시작
    _errs[:] = [t for t in _errs if now - t < 600]
    if len(_errs) >= 30 and anomaly('오류 폭주', f'10분 동안 오류 {len(_errs)}건 → 사냥기 새로 시작', 1800): raise SystemExit
    # 4) 30분마다: 볼·박스·캡처·잠자기 방지
    if now - _anom_last.get('_slow', 0) > 1800:
        _anom_last['_slow'] = now
        bag = api('/api/bag').get('bag') or {}
        balls = sum(v for k2, v in bag.items() if k2.endswith('BALL') and k2 != 'MASTERBALL')
        if balls < BALL_LOW:
            # 10/27: 예전 문구는 하루 상한을 빼고 '5만 원 이상이면 자동 구매'라고만 해서, 상한에 걸려 멈춘 것을 '안 산다'로 보이게 했다
            try: sp = json.load(open(SPEND, encoding='utf-8'))
            except Exception: sp = {}
            capped = sp.get('_said') == time.strftime('%Y-%m-%d')
            anomaly('볼 부족', f'던질 볼 {balls}개 남음 — ' + (f'오늘 볼값 상한(평균 수입의 {SPEND_RATE:.0%}, {sp.get(time.strftime("%Y-%m-%d"), 0):,}원) 다 씀 → 0시에 다시 삼' if capped
                    else f'자동 구매 대기 (가진 돈 {MONEY_FLOOR:,}원 아래면 상점에서 사 주세요)'), 7200)
        if len(P) > 900: anomaly('박스 거의 참', f'보유 {len(P)}/960', 7200)
        shots = sorted(f for f in os.listdir(HERE) if f.startswith('메뉴없음_') and f.endswith('.png'))
        for f in shots[:-30]:
            try: os.remove(os.path.join(HERE, f))
            except OSError: pass
        if MAC and not any('caffeinate' in ' '.join(q.info['cmdline'] or []) and '-s' in (q.info['cmdline'] or []) for q in psutil.process_iter(['cmdline'])):
            import subprocess
            subprocess.Popen(['caffeinate', '-i', '-s', '-w', str(os.getppid())], start_new_session=True)
            anomaly('잠자기 방지 꺼짐', 'caffeinate 다시 켬', 3600)

# 야생 배틀 선두 (2026-10-10): 야생은 파티 첫 자리(slot 0)가 싸우는데, 볼이 빠진 사이 상대 공격에 약한 선두가 쓰러지면
# 판이 끝나 못 잡는다(오늘 놓친 20번 중 6번). 풀숲이 뜨면 가장 튼튼한 포켓몬을 첫 자리로, 배틀이 끝나면 원래 순서로
lead_saved = None
def lead_strong():
    global lead_saved
    P = [p for p in api('/api/pokemon')['pokemon'] if p['onDesktop']]
    if len(P) < 2: return
    order = [p['id'] for p in sorted(P, key=lambda p: (p.get('slot') if p.get('slot') is not None else 99, p['id']))]
    st = lambda p: p['info']['stats']
    best = max(P, key=lambda p: (p['level'], st(p)['hp'] * (st(p)['def'] + st(p)['spd']) * max(st(p)['atk'], st(p)['spa'])))
    if order[0] == best['id']: return
    lead_saved = order
    r = api_post('/api/pokemon/order', {'ids': [best['id']] + [i for i in order if i != best['id']]})
    if not r.get('ok'): lead_saved = None; say(f"야생 선두 바꾸기 실패: {str(r.get('detail') or r.get('error'))[:50]}")
    else: say(f"야생 선두: {best['info']['name']} Lv{best['level']} (배틀 끝나면 원래 순서로)")

def lead_restore():
    global lead_saved
    if not lead_saved: return
    ids, lead_saved = lead_saved, None
    api_post('/api/pokemon/order', {'ids': ids})

global tried, appeared, wild
raid_at = 0
tried = {}
appeared = 0
wild = None
battle = 0
fight = 0

_recent = log_since(time.time() - 90)
_last = lambda ws: max((_recent.rfind(w) for w in ws), default=-1)
if _last(('튀어나왔다',)) > _last(('배틀 종료', '도망', '떠나버렸다', '날려가')): fight = battle = time.time()
elif _last(('나타났다',)) > _last(('배틀 종료', '도망', '떠나버렸다', '날려가')): battle = appeared = time.time()
say(time.strftime('%Y-%m-%d'), '자동사냥 시작 (끄려면 Ctrl+C)')

def wild_clicks(pid):
    global tried, wild, appeared
    if fight: return
    ts = targets(pid)
    keys = {}
    for h in ts:
        r = rect(h)
        if r: keys[h] = (h, r[2] - r[0], r[3] - r[1])
    tried = {k: v for k, v in tried.items() if k in keys.values()}
    now = time.time()
    for h, k in keys.items():
        seen, last = tried.setdefault(k, [now, 0])

        if now - last_click < 1.5: break
        if (not last and now - seen >= 1) or (last and not battle and now - last >= 6):
            tried[k][1] = now
            if not battle: wild = h
            r = click(h, seen)
            if not r.startswith('안 누름'): say('재클릭' if last else '클릭', k[1:], r)

    if appeared and time.time() - appeared > 3 and time.time() - last_click > 3:
        if not alive(wild) and ts: wild = ts[-1]
        if alive(wild): say('재클릭(야생)', click(wild, appeared - 3))
        elif battle and time.time() - battle > 8 and battle != globals().get('_diag_at'):
            globals()['_diag_at'] = battle
            say('진단: 야생 창을 못 찾음 — 게임 작은 창', [(r[2] - r[0], r[3] - r[1], '동행' if h in companions else '') for h, _, r in wins(pid) if r[2] - r[0] < 200 and r[3] - r[1] < 200])
        appeared = time.time()

# 게임 고착 감지 (2026-10-10): 서버가 잠깐 끊기면(01:52 '동기화 실패') 게임의 풀숲 요청이 응답 없이 멈춰
# revealing 표시가 켜진 채 남고, 그 뒤 풀숲을 아무리 눌러도 무시된다(02:00~02:20 6번 연속 놓침, 관장도 0판).
# 눌렀는데도 풀숲을 2번 연속 놓치면 게임을 탐지기와 함께 다시 켜고 사냥기도 새로 시작한다 (맥 전용 - 조종판 [게임 다시 켜기]와 같음)
grass_miss = 0
lock_said = 0
def screen_locked():
    # 맥 화면 잠김(로그인 창) — 진짜 클릭이 게임에 안 닿아 풀숲 무반응·관장 멈춤으로 보인다.
    # 10/11 01:20부터 잠긴 화면에서 '게임 고착'으로 오판해 게임을 8분마다 다시 켬(다시 켜도 그대로)
    if not MAC:   # 윈도우: 잠긴 화면(Winlogon 데스크톱)이면 입력 데스크톱으로 전환이 안 된다
        h = ctypes.windll.user32.OpenInputDesktop(0, False, 0x0100)
        if not h: return True
        ok = ctypes.windll.user32.SwitchDesktop(h); ctypes.windll.user32.CloseDesktop(h)
        return not ok
    import subprocess
    try: return b'CGSSessionScreenIsLocked</key>\n\t\t\t<true/>' in subprocess.run(['ioreg', '-n', 'Root', '-d1', '-a'], capture_output=True, timeout=5).stdout
    except Exception: return False

def game_exe_win():
    # 게임 exe 경로: 레지스트리 Run(게임 '자동 시작' 설정 - 게임이 업데이트하면 새 판 경로로 바꿔 둔다) 먼저, 없으면 켜진 프로세스
    # (10/19: 프로세스 먼저였을 때 업데이트로 멈춘 옛 판 exe 를 다시 켤 수 있었다)
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Microsoft\Windows\CurrentVersion\Run') as k:
            for i in range(winreg.QueryInfoKey(k)[1]):
                v = str(winreg.EnumValue(k, i)[1])
                if 'poketdesktop' in v.lower() and os.path.isfile(v.split(' --')[0].strip('"')): return v.split(' --')[0].strip('"')
    except OSError: pass
    for p in psutil.process_iter(['name', 'exe']):
        if (p.info['name'] or '').lower().startswith('poketdesktop') and p.info['exe']: return p.info['exe']

game_update_wait = ''
def game_update_step(pid):
    # 게임 새 버전 안내 창 (10/13 사용자: '선택창이 뜨면 게임이 멈춘다'). 게임은 켜 둔 동안 몇 시간마다 새 판을 찾아
    # '포스크탑 — 새 버전' 창(지금 받기 / 나중에)을 띄우고 답이 올 때까지 기다린다(wait_window) — 그동안 풀숲·포켓몬이 멈춘다.
    # 닫기(WM_CLOSE) = [나중에] 와 같다(ui_update.NewVersionAsk). 게임은 켤 때는 묻지 않고 새 판을 받으므로(app.check_update),
    # 창을 닫고 게임을 다시 켜면 새 판으로 계속 돈다. 화면이 잠겨 있으면 닫기만 하고(게임은 계속 돎), 풀린 뒤 다시 켠다
    global game_update_wait
    for h, title, _ in wins(pid):
        if title == '포스크탑 — 새 버전':
            try: win32gui.PostMessage(h, 16, 0, 0)
            except Exception: pass
            game_update_wait = game_update_wait or time.strftime('%H:%M')
            say("게임 '새 버전' 안내 창 닫음 (멈춤 방지) → 게임을 다시 켜서 새 판 받게 함")
            time.sleep(2)
    if game_update_wait and not screen_locked():
        why = f'게임 새 버전 받기 ({game_update_wait} 안내)'
        game_update_wait = ''
        game_restart_mac(why)   # 켤 때 새 판을 받고 스스로 다시 켜진다

def game_restart_mac(why):
    global lock_said
    if screen_locked():
        if time.time() - lock_said > 1800:
            lock_said = time.time(); say(f'게임 다시 켜기 안 함: 화면이 잠겨 있음({why}) — 암호로 풀어 주세요(사냥기가 도는 동안은 화면이 안 꺼지게 함)')
        return
    say(f'게임 다시 켬: {why}')
    if not MAC:
        exe = game_exe_win()
        if not exe: say('게임 exe 를 못 찾아 다시 켜지 못함'); return
        for p in psutil.process_iter(['name']):
            if (p.info['name'] or '').lower().startswith('poketdesktop'):
                try: p.kill()
                except Exception: pass
        time.sleep(3)
        import subprocess
        subprocess.Popen([exe, '--autostart'], cwd=os.path.dirname(exe), creationflags=0x00000008)
        time.sleep(25)
        raise SystemExit
    gdir = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop')
    for p in psutil.process_iter(['cmdline']):
        c = ' '.join(p.info['cmdline'] or [])
        if 'game_probe.py' in c or 'run.pyw' in c or '포스크탑.app/Contents/MacOS' in c:   # 설치된 앱(/Applications/포스크탑.app)도 끄고 탐지기 붙은 게임으로
            try: p.kill()
            except Exception: pass
    time.sleep(3)
    import subprocess
    subprocess.Popen([os.path.join(gdir, '.venv', 'bin', 'python'), os.path.join(HERE, 'game_probe.py'), gdir], cwd=gdir,
                     start_new_session=True, stdout=open('/tmp/poketdesktop.log', 'a'), stderr=subprocess.STDOUT)
    time.sleep(25)
    raise SystemExit   # run_hunt 가 5초 뒤 사냥기를 새로 켠다 (창 번호 등 옛 상태를 버림)

paused = False
while True:
    if os.path.exists(PAUSE):
        if not paused: say('잠깐 멈춤'); paused = True
        safe('로그', new_log); time.sleep(1); continue
    if paused: say('다시 진행'); paused = False
    pid = safe('게임 찾기', game_pid)
    if not pid:   # 5) 게임이 2분 넘게 안 보이면 다시 켠다 (맥)
        _nogame_since = _nogame_since or time.time()
        if time.time() - _nogame_since > 120 and anomaly('게임 꺼짐', '게임이 2분 넘게 안 보임 → 다시 켬', 600): game_restart_mac('게임이 꺼져 있음')
        time.sleep(5); continue
    _nogame_since = 0
    log = safe('로그', new_log) or ''
    screen_wild = not server_mode('포획_방식')   # 서버 직접 포획이면 화면 풀숲용 처리(야생 선두 바꾸기·화면 볼·고착 판정)는 안 함
    if '풀숲이 흔들리고' in log and screen_wild: safe('야생 선두', lead_strong)   # 서버 직접일 때 이것이 관장 선두(gym_lead)를 막았다(10/11 08:46)
    if '나타났다' in log: appeared = time.time(); battle = time.time()
    if '튀어나왔다' in log: fight = time.time(); appeared = 0
    if any(w in log for w in ('배틀 종료', '도망', '떠나버렸다', '날려가')): appeared = 0; battle = 0; fight = 0
    if any(w in log for w in ('배틀 종료', '도망', '떠나버렸다', '날려가', '풀숲이 잠잠')): safe('야생 선두 되돌림', lead_restore)
    if fight and time.time() - fight > 180: fight = 0
    if battle and time.time() - battle > 180: battle = 0
    # 서버로 직접 잡은 뒤엔 게임 창에 남은 풀숲이 1~2분 뒤 '풀숲이 잠잠'으로 사라진다 — 놓친 게 아니다(04시 놓침 13건이 거의 이것)
    api_wild = not screen_wild or any(time.time() - t < 240 for t in wild_api_done.values())
    for w in ('풀숲이 잠잠', '도망가 버렸'):
        if w in log and not api_wild: say('놓침:', w)
    if '나타났다' in log: grass_miss = 0
    if '풀숲이 잠잠' in log and time.time() - last_click < 120 and not api_wild:
        grass_miss += 1
        if grass_miss >= 2: game_restart_mac(f'풀숲을 눌러도 반응 없음 {grass_miss}번 연속 (게임 고착)')
    if '오른쪽 클릭으로 볼을' in log and screen_wild:
        say('포획', safe('포획', throw_ball, pid, wild, time.time() - 2))
    if grass_on() or appeared or battle: safe('알림 창', clear_learn, pid, True)   # 업적·선물 창의 grab 이 풀숲·야생 클릭까지 막는다
    safe('하루 계획', plan_step)
    safe('풀숲', wild_api_step if server_mode('포획_방식') else wild_clicks, pid)
    # 관장전은 늘 서버로 직접(10/11 08시): 화면 관장은 1시간 25판 남짓, 서버 직접은 60판대(잠긴 화면 03~08시) — 고르는 규칙·기술·교체는 같다
    safe('관장전', gym_api_step if server_mode('관장_방식') else gym_step, pid)
    safe('육성', grow_step, pid)
    safe('기술 배우기', learn_step, pid)
    safe('기술머신', tm_step, pid)
    safe('유대 미션', bond_step, pid)
    safe('랜덤 배틀', pvp_step, pid)
    safe('게임 새 버전', game_update_step, pid)
    safe('지닌 도구', held_step, pid)
    safe('탐험', expedition_step)
    safe('알', egg_step)
    safe('노력치', ev_step)
    safe('집중', focus_step)
    safe('놀러 가기', visit_step)
    safe('올림픽', oly_step)
    safe('길드전 준비', gw_season_step)
    safe('도구 팔기', sell_step)
    safe('박스 정리', box_step)
    safe('업데이트', update_check)
    safe('설정 감시', conf_watch)
    safe('시간별 지표', metric_step)
    safe('이상 감지', watchdog, pid)
    gym_gap = False
    if '빛기둥을 눌러 참가' in log:
        raid_at = time.time(); say('레이드 안내 - 정각에 빛기둥 누름')

    if raid_at and ((time.localtime().tm_min < 50 and time.time() - raid_at > 120 and time.localtime().tm_sec >= 20) or time.time() - raid_at > 900):
        def raid():
            h = pillar(pid)
            if not h: say('레이드 빛기둥이 안 보임'); return
            p = hit_point(h) or (lambda r: ((r[0] + r[2]) // 2, (r[1] + r[3]) // 2))(rect(h))
            real_click(*p); time.sleep(5)
            say('레이드 빛기둥 클릭 →', '배틀 창 열림' if raid_open(pid) else '배틀 창 없음')
        safe('레이드', raid); raid_at = 0
    time.sleep(1)
