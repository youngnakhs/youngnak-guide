# -*- coding: utf-8 -*-
"""맥용 win32process 대역 - GetWindowThreadProcessId 만 쓴다."""
import win32gui


def GetWindowThreadProcessId(h):
    if h < 0 or win32gui._top(h):
        return (0, win32gui._game_pid() or 0)
    w = win32gui._cg_one(h)
    return (0, (w or {}).get('kCGWindowOwnerPID', 0))
