# -*- coding: utf-8 -*-
"""맥용 win32gui 대역 - 자동사냥(posk_hunt)이 쓰는 함수만 같은 이름·같은 뜻으로 흉내 낸다.

창 번호(hwnd)
  - Tk 최상위 창 : 맥 CG 창 번호 (NSWindow.windowNumber, 양수)
  - Tk 자식 위젯  : 탐지기(game_probe.py)가 알려 준 위젯 경로에 붙인 음수 번호
  - 팝업 메뉴     : 게임 프로세스의 CG 메뉴 창 번호 (GetClassName -> '#32768')
좌표는 전부 맥 포인트(pyautogui 와 같은 단위).
"""
import json, os, socket, time
import Quartz
from AppKit import NSWorkspace, NSRunningApplication

GDIR = os.path.expanduser('~/Library/Application Support/poketdesktop')
INFO = os.path.join(GDIR, 'hunt_probe.json')
MENU_LAYER = Quartz.CGWindowLevelForKey(Quartz.kCGPopUpMenuWindowLevelKey)

_cache = {'t': 0, 'snap': None}
_child = {}          # 음수 hwnd -> (경로, 최상위 hwnd)
_child_id = {}       # 경로 -> 음수 hwnd


# ---------------------------------------------------------------- 탐지기
def probe_info():
    try:
        with open(INFO, encoding='utf-8') as f:
            d = json.load(f)
        os.kill(d['pid'], 0)
        return d
    except Exception:
        return None


def _ask(req, timeout=3):
    d = probe_info()
    if not d:
        return None
    try:
        with socket.create_connection(('127.0.0.1', d['port']), timeout=timeout) as s:
            s.sendall(json.dumps(req).encode('utf-8') + b'\n')
            buf = b''
            while not buf.endswith(b'\n'):
                b = s.recv(65536)
                if not b:
                    break
                buf += b
        return json.loads(buf.decode('utf-8'))
    except Exception:
        return None


def snap(max_age=0.3):
    if time.time() - _cache['t'] > max_age or _cache['snap'] is None:
        s = _ask({'op': 'snap'})
        _cache.update(t=time.time(), snap=s or {'tops': []})
    return _cache['snap']


def _tops():
    return [t for t in snap()['tops'] if (t.get('wnum') or 0) > 0]


def _top(h):
    for t in _tops():
        if t['wnum'] == h:
            return t


def _cid(path, top):
    if path not in _child_id:
        n = -(len(_child_id) + 1)
        _child_id[path] = n
    _child[_child_id[path]] = (path, top)
    return _child_id[path]


# ---------------------------------------------------------------- CG 창 목록
def _cg(on_screen=True):
    opt = Quartz.kCGWindowListOptionOnScreenOnly if on_screen else Quartz.kCGWindowListOptionAll
    return Quartz.CGWindowListCopyWindowInfo(opt | Quartz.kCGWindowListExcludeDesktopElements, Quartz.kCGNullWindowID) or []


def _cg_one(n):
    for w in _cg(False):
        if w.get('kCGWindowNumber') == n:
            return w


def _cg_rect(w):
    b = w['kCGWindowBounds']
    x, y, ww, hh = int(b['X']), int(b['Y']), int(b['Width']), int(b['Height'])
    return (x, y, x + ww, y + hh)


def _game_pid():
    d = probe_info()
    return d['pid'] if d else None


def _menus():
    pid = _game_pid()
    return [w for w in _cg() if w.get('kCGWindowOwnerPID') == pid and w.get('kCGWindowLayer') == MENU_LAYER]


# ---------------------------------------------------------------- win32gui 함수들
def GetWindowRect(h):
    if h < 0:
        path, top = _child.get(h, (None, None))
        for t in _tops():
            for k in t['kids']:
                if k[0] == path:
                    x, y, w, hh = k[2:6]
                    return (x, y, x + w, y + hh)
        raise OSError('창 없음')
    t = _top(h)
    if t:
        x, y, w, hh = t['geo']
        return (x, y, x + w, y + hh)
    w = _cg_one(h)
    if w:
        return _cg_rect(w)
    raise OSError('창 없음')


def IsWindow(h):
    try:
        GetWindowRect(h)
        return True
    except Exception:
        return False


def IsWindowVisible(h):
    if h < 0:
        return IsWindow(h)
    t = _top(h)
    if t:
        return t['viewable'] and t['state'] == 'normal'
    w = _cg_one(h)
    return bool(w and w.get('kCGWindowIsOnscreen'))


def GetWindowText(h):
    t = _top(h)
    if t:
        return t['title']
    w = _cg_one(h)
    return (w or {}).get('kCGWindowName') or ''


def GetClassName(h):
    if h < 0:
        return 'TkChild'
    w = _cg_one(h)
    if w and w.get('kCGWindowLayer') == MENU_LAYER:
        return '#32768'
    return 'TkTopLevel'


def EnumWindows(cb, extra):
    for t in _tops():
        if cb(t['wnum'], extra) is False:
            return
    for w in _menus():
        if cb(w['kCGWindowNumber'], extra) is False:
            return


def EnumChildWindows(top, cb, extra):
    t = _top(top)
    if not t:
        return
    for k in t['kids']:
        if cb(_cid(k[0], top), extra) is False:
            return


def WindowFromPoint(p):
    """그 점에서 맨 앞에 있는 창(다른 프로그램 창 포함). CG 목록은 앞->뒤 순서."""
    x, y = p
    for w in _cg():
        if w.get('kCGWindowLayer', 0) >= 1000 or w.get('kCGWindowAlpha', 1) == 0:
            continue
        if w.get('kCGWindowOwnerName') in ('Window Server', 'Dock') and w.get('kCGWindowLayer', 0) > 0:
            continue
        l, t, r, b = _cg_rect(w)
        # 알림센터: 알림(블루투스 연결 등)이 뜨면 화면 위쪽을 넓게 덮는 투명 창이 생기는데, 실제 배너는 오른쪽 끝
        # 약 400px 뿐이다. 그 밖(풀숲·동행 도트 자리)까지 '가림'으로 보면 클릭을 포기해 풀숲을 놓친다 (2026-10-09 23시 55번)
        if w.get('kCGWindowOwnerName') == 'NotificationCenter' and x < r - 420:
            continue
        if l <= x < r and t <= y < b:
            return w['kCGWindowNumber']
    return 0


def GetAncestor(h, flag=2):
    if h < 0:
        return _child.get(h, (None, 0))[1]
    return h


def _path(h):
    t = _top(h)
    return t['path'] if t else (_child.get(h, (None,))[0])


def SetWindowPos(h, after, x, y, cx, cy, flags):
    p = _path(h)
    if p:
        _ask({'op': 'topmost', 'path': p})
        _cache['t'] = 0


def _activate():
    pid = _game_pid()
    if pid:
        app = NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
        if app:
            app.activateWithOptions_(1 << 1)   # NSApplicationActivateIgnoringOtherApps


def SetForegroundWindow(h):
    p = _path(h)
    _activate()
    if p:
        _ask({'op': 'front', 'path': p})
        _cache['t'] = 0


BringWindowToTop = SetForegroundWindow


def GetForegroundWindow():
    app = NSWorkspace.sharedWorkspace().frontmostApplication()
    if app is None or app.processIdentifier() != _game_pid():
        return 0
    for w in _cg():           # 게임 프로세스 창 중 맨 앞(일반 층)
        if w.get('kCGWindowOwnerPID') == _game_pid() and w.get('kCGWindowLayer') == 0:
            return w['kCGWindowNumber']
    return 0


def IsIconic(h):
    t = _top(h)
    return bool(t and t['state'] == 'iconic')


def ShowWindow(h, cmd):
    p = _path(h)
    if p:
        _ask({'op': 'restore', 'path': p})
        _cache['t'] = 0


def PostMessage(h, msg, wp=0, lp=0):
    if msg == 16:                         # WM_CLOSE
        p = _path(h)
        if p:
            _ask({'op': 'close', 'path': p})
            _cache['t'] = 0


# ---------------------------------------------------------------- 창 캡처 (PrintWindow 대신)
def window_image(h):
    """CG 창 하나를 포인트 해상도(1배)로 찍어 PIL 이미지로."""
    from PIL import Image
    img = Quartz.CGWindowListCreateImage(Quartz.CGRectNull, Quartz.kCGWindowListOptionIncludingWindow, h,
                                         Quartz.kCGWindowImageBoundsIgnoreFraming | Quartz.kCGWindowImageNominalResolution)
    if img is None:
        raise OSError('창을 찍지 못함 (화면 기록 권한 확인)')
    w, hh = Quartz.CGImageGetWidth(img), Quartz.CGImageGetHeight(img)
    bpr = Quartz.CGImageGetBytesPerRow(img)
    data = Quartz.CGDataProviderCopyData(Quartz.CGImageGetDataProvider(img))
    return Image.frombuffer('RGBA', (w, hh), bytes(data), 'raw', 'BGRA', bpr, 1).convert('RGB')


# ---------------------------------------------------------------- 맥 전용: 관장 단추를 '역할'로 찾기
# 윈도우판 kids(top, w, h) 는 단추를 픽셀 크기로 찾는다. 맥은 글꼴·단추 모양이 달라 크기가
# 전혀 다르므로(실측: 기술 칸·교체 칸·시도 칸 0개), 같은 단추를 글자·구조로 찾는다.
import re as _re

def _kid_rows(top):
    t = _top(top)
    return t['kids'] if t else []

def _up(path, n):
    return path.rsplit('.', n)[0] if path.count('.') > n else path

def find_text(top, text, exact=True):
    """글자가 같은(또는 포함하는) 위젯 hwnd 목록 (위→아래, 왼→오른 순)."""
    rows = [k for k in _kid_rows(top) if len(k) > 6 and (k[6] == text if exact else text in k[6])]
    rows.sort(key=lambda k: (k[3], k[2]))
    return [_cid(k[0], top) for k in rows]

def _cells(top, pattern, up):
    rows = _kid_rows(top)
    byp = {k[0]: k for k in rows}
    out = []
    for k in rows:
        if len(k) > 6 and _re.match(pattern, k[6]):
            cp = _up(k[0], up)
            if cp in byp and cp not in [c[0] for c in out]:
                out.append(byp[cp])
    out.sort(key=lambda k: (k[3], k[2]))
    return [_cid(k[0], top) for k in out]

def _canvases(top):
    """(지도 캔버스들, 스크롤 칸 캔버스들). 크기로 가르면 창을 줄였을 때 오른쪽 정보 칸이 지도보다 넓어져 뒤바뀐다(10/10).
    지도는 그림만 그리는 빈 캔버스, 정보 칸은 안에 글자·단추 위젯을 담은 스크롤 캔버스 → '안에 위젯이 있나'로 가른다."""
    rows = _kid_rows(top)
    cvs = [k for k in rows if k[1] == 'Canvas']
    has_kids = lambda c: any(r[0].startswith(c[0] + '.') for r in rows)
    maps = sorted((c for c in cvs if not has_kids(c)), key=lambda k: -k[4] * k[5])
    panels = [c for c in cvs if has_kids(c)]
    return maps, panels

ROLES = {   # 윈도우 kids 크기 -> 맥에서 찾는 법
    (683, 496): lambda top: [_cid(k[0], top) for k in _canvases(top)[0][:1]],
    (83, 32):   lambda top: find_text(top, '전국 지도'),
    (71, 53):   lambda top: _cells(top, r'^\d+/\d+$', 1),          # 시·도 바로 가기 칸 (이름 + 이긴수/전체)
    (304, 40):  lambda top: find_text(top, '도전하기') + find_text(top, '승부 이어하기'),   # 서버에 남은 승부면 '승부 이어하기'
    (304, 91):  lambda top: _cells(top, r'^PP \d+/\d+$', 3),       # 기술 칸 (PP 글자 -> 칸)
    (201, 73):  lambda top: _cells(top, r'^Lv\.\d+', 3),            # 교체 칸 (Lv 글자 -> 칸)
    (142, 42):  lambda top: find_text(top, '지도로 돌아가기'),
    (200, 44):  lambda top: find_text(top, '포켓몬 교체'),
}

def scroll_panels(top, frac):
    """지도(가장 큰 캔버스)를 뺀 스크롤 캔버스들을 frac(0=맨 위, 1=맨 아래)으로. 창이 작아 단추가 스크롤 밖일 때."""
    cvs = _canvases(top)[1]
    for k in cvs:
        _ask({'op': 'yview', 'path': k[0], 'xy': [frac]})
    _cache['t'] = 0
    return len(cvs)

def kids_role(top, w, h):
    f = ROLES.get((w, h))
    return f(top) if f else []


def plate_rects():
    """포켓몬 이름표 창들의 (l, t, r, b). 맥은 이름표가 29px(윈도우 25px)이라 높이 대신 구조로 고른다:
    테두리 없는 작은 창 안에 글자 있는 Label 하나만 있는 것 (overlay.make_nameplate)."""
    out = []
    for t in _tops():
        ks = t['kids']
        x, y, w, h = t['geo']
        if t['viewable'] and h <= 45 and len(ks) == 1 and ks[0][1] == 'Label' and len(ks[0]) > 6 and ks[0][6]:
            out.append((x, y, x + w, y + h))
    return out


# ---------------------------------------------------------------- 맥 전용: 볼 메뉴
# 맥 게임은 tk.Menu(NSMenu)를 못 써서 볼 메뉴를 테두리 없는 Tk 창(ui_common.PopupMenu)으로 그린다.
# 그래서 윈도우의 '#32768' 메뉴 창도, 견본 그림도 소용없다 → 줄 글자(ball_menu.rows)로 찾는다.
_BALL_ROW = _re.compile(r'^(추천\s+)?\S*볼\s+\d+개')

def ball_menu():
    """떠 있는 볼 메뉴의 [(글자, (l, t, r, b)), ...] (위→아래). 없으면 []."""
    for t in _tops():
        if not t['viewable']:
            continue
        rows = [k for k in t['kids'] if k[1] == 'Label' and len(k) > 6 and _BALL_ROW.match(k[6].lstrip('✓ '))]
        if rows:
            rows.sort(key=lambda k: k[3])
            return [(k[6], (k[2], k[3], k[2] + k[4], k[3] + k[5])) for k in rows]
    return []


# ---------------------------------------------------------------- 맥 전용: 풀숲·야생 창
# 원본은 '창 바로 위 6px 안에 25px 이름표가 있나'로 동행/대상을 가르는데, 맥은 이름표 높이·간격이 달라
# 우연히 맞을 때만 동작했다(풀숲 16초 늦게 클릭, 야생은 못 찾음). 위에 붙은 글자 창의 '내용'으로 가른다.
#   내 포켓몬 = 위에 이름표('이름 Lv.n'), 야생 = 위에 표식('야생 …'/'★ 야생 …'), 풀숲 = 위에 아무것도 없음
def small_wins(lo, hi):
    """[(창 번호, (l, t, r, b), 위에 붙은 글자 또는 None)] - 가로·세로 lo~hi 인 그림 창(글자 없는 창)만."""
    tops = [t for t in _tops() if t['viewable']]
    plates = []
    for t in tops:
        ks = t['kids']
        if t['geo'][3] <= 45 and len(ks) == 1 and ks[0][1] == 'Label' and len(ks[0]) > 6 and ks[0][6]:
            x, y, w, h = t['geo']
            plates.append((x, y, x + w, y + h, ks[0][6]))
    out = []
    for t in tops:
        x, y, w, h = t['geo']
        if not (lo <= w <= hi and lo <= h <= hi) or any(k[1] == 'Label' for k in t['kids']):
            continue
        above = [p for p in plates if -2 <= y - p[3] <= 10 and p[0] < x + w and p[2] > x]
        out.append((t['wnum'], (x, y, x + w, y + h), above[0][4] if above else None))
    return out


# ---------------------------------------------------------------- 맥 전용: 가려진 단추 누르기
def owned_by_game(h):
    """이 CG 창이 게임 프로세스 것인가 (동행 도트·이름표 등)."""
    w = _cg_one(h) if h and h > 0 else None
    return bool(w and w.get('kCGWindowOwnerPID') == _game_pid())


def click_in(top, x, y):
    """마우스 없이 탐지기가 최상위 창 top 안 (x, y) 자리 위젯에 누름·뗌을 보낸다."""
    p = _path(top)
    ok = bool(p) and _ask({'op': 'click', 'path': p, 'xy': [int(x), int(y)]}) is not None
    _cache['t'] = 0
    return ok
