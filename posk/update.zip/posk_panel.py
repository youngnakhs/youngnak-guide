# 포스크탑 조종판 (posk_panel) — 윈도우 exe 바이트코드에서 복원 → 맥 겸용 (2026-10-09)
# 사냥기 켜고 끄기, 관장 이어 도전, 상태 표시
import json, os, subprocess, sys, threading, time, tkinter as tk
from tkinter import ttk
import psutil, requests

HERE = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(os.path.abspath(__file__))
FROZEN, ME = getattr(sys, "frozen", False), os.path.basename(sys.executable).lower()
MAC = sys.platform == "darwin"
PB = (0, 4) if MAC else (0, 8)   # 맥: 화면 800px 안에 들어가게 칸 사이를 줄인다
GDIR = os.path.expanduser("~/Library/Application Support/poketdesktop") if MAC else os.path.join(os.environ["APPDATA"], "poketdesktop")
GAME_DIR = os.path.expanduser("~/dev/개발_프로젝트/poketdesktop")          # 맥: 소스로 실행하는 게임 폴더
GAME_PY = os.path.join(GAME_DIR, ".venv", "bin", "python")
BAT, HUNT = os.path.join(HERE, "자동사냥.bat"), os.path.join(HERE, "사냥기록.txt")
PAUSE, CHAIN, CONF = (os.path.join(HERE, f) for f in ("잠깐멈춤.flag", "관장_이어도전중.flag", "조종판설정.json"))
LITE = False
FONT, GREEN, RED, GRAY = "Apple SD Gothic Neo" if MAC else "Malgun Gothic", "#0e7c66", "#c0392b", "#6b7280"

def procs(pred, name_ok=lambda n: True):
    # 실행 명령(cmdline)은 이름이 맞는 프로세스만 읽는다 (10/13: 윈도우에서 305개 전부 읽으니 11초 — 3초마다 두 번이라 조종판이 멈춤)
    out = []
    for p in psutil.process_iter(["name"]):
        try:
            n = p.info["name"] or ""
            if name_ok(n.lower()) and pred(n, " ".join(p.cmdline() or [])): out.append(p)
        except Exception: pass
    return out

if MAC:
    py = lambda n: "python" in n
    hunters = lambda: procs(lambda n, c: "run_hunt.py" in c or "posk_hunt.py" in c, py)
    hunter_shells = lambda: []
    games = lambda: procs(lambda n, c: "game_probe.py" in c or "client/run.pyw" in c, py)
else:
    hunters = lambda: procs(lambda n, c: n.lower() in ("python.exe", "pythonw.exe") and ("run_hunt.py" in c or "posk_hunt.py" in c) or FROZEN and n.lower() == ME and "--hunt" in c,
                            lambda n: n in ("python.exe", "pythonw.exe", ME))
    hunter_shells = lambda: procs(lambda n, c: "자동사냥.bat" in c, lambda n: n == "cmd.exe")
    games = lambda: procs(lambda n, c: True, lambda n: n.startswith("poketdesktop"))
def open_path(p):
    if MAC: subprocess.Popen(["open", p])
    else: os.startfile(p)

def conf():
    for _ in range(5):
        try: return json.load(open(CONF, encoding="utf-8"))
        except FileNotFoundError: return {}
        except Exception: time.sleep(0.1)
    return {}

def save(c):
    for _ in range(10):
        try:
            json.dump(c, open(CONF + ".tmp", "w", encoding="utf-8"), ensure_ascii=False); os.replace(CONF + ".tmp", CONF); return
        except OSError: time.sleep(0.1)

def flag(path, on):
    if on: open(path, "w").close()
    elif os.path.exists(path): os.remove(path)

def api(path):
    tok = json.load(open(os.path.join(GDIR, "session.json"), encoding="utf-8"))["token"]
    base = json.load(open(os.path.join(GDIR, "settings.json"), encoding="utf-8"))["server"]
    return _http.get(base + path, headers={"Authorization": "Bearer " + tok}, timeout=15).json()
_http = requests.Session()   # 10/13: 요청마다 새 연결이면 인증서를 매번 읽어(0.7초, GIL 쥠) 그동안 조종판 화면이 멈췄다 — 연결 하나를 계속 쓴다

def today_lines():
    # 사냥기록.txt 의 오늘 줄만. 줄에는 시각만 있어서, 끝에서 거꾸로 읽다 시각이 커지는 곳(자정을 넘은 곳)에서 멈춘다
    # (시각 글자로 자르면 어제 같은 시각 줄까지 섞인다 — 10/11 09:45 오인)
    try:
        with open(HUNT, encoding="utf-8", errors="ignore") as f: lines = f.readlines()[-60000:]
    except OSError: return []
    out, last = [], "99:99:99"
    for l in reversed(lines):
        t = l[:8]
        if len(t) == 8 and t[2] == ":" and t[5] == ":":
            if t > last: break
            last = t
        out.append(l)
    return out[::-1]

_lock = {"at": 0, "v": False}
def locked():
    if time.time() - _lock["at"] > 20:
        if not MAC:   # 윈도우: 잠긴 화면이면 입력 데스크톱으로 전환이 안 된다
            import ctypes
            h = ctypes.windll.user32.OpenInputDesktop(0, False, 0x0100)
            _lock["v"] = not (h and ctypes.windll.user32.SwitchDesktop(h))
            if h: ctypes.windll.user32.CloseDesktop(h)
            _lock["at"] = time.time(); return _lock["v"]
        try: _lock["v"] = "CGSSessionScreenIsLocked</key>\n\t\t\t<true/>" in subprocess.run(["ioreg", "-n", "Root", "-d1", "-a"], capture_output=True, text=True, timeout=5).stdout
        except Exception: pass
        _lock["at"] = time.time()
    return _lock["v"]

def tail(n=14):
    try:   # 끝 16KB 만 (기록이 수 MB 라 3초마다 통째로 읽지 않는다)
        with open(HUNT, "rb") as f:
            f.seek(0, 2); f.seek(max(0, f.tell() - 16384))
            return b"".join(f.read().splitlines(True)[-n:]).decode("utf-8", "ignore")
    except OSError: return ""


def hunter_on():
    if hunters(): return
    if MAC:   # 맥: run_hunt.py 가 꺼지면 5초 뒤 다시 켜는 고리(윈도우의 --hunt/자동사냥.bat 역할)
        subprocess.Popen([sys.executable, os.path.join(HERE, "run_hunt.py")], cwd=HERE, start_new_session=True,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL); return
    if FROZEN: subprocess.Popen([sys.executable, "--hunt"], cwd=HERE, creationflags=0x08000008)
    else: subprocess.Popen([sys.executable, os.path.join(HERE, "run_hunt.py")], cwd=HERE, creationflags=0x08000008)

def hunter_off():
    for p in hunter_shells() + hunters():
        try: p.kill()
        except Exception: pass

def game_restart():
    if MAC:   # 맥: 게임을 끄고 탐지기(game_probe.py)를 붙여 다시 켠다
        for p in games():
            try: p.kill()
            except Exception: pass
        time.sleep(2)
        subprocess.Popen([GAME_PY, os.path.join(HERE, "game_probe.py"), GAME_DIR], cwd=GAME_DIR, start_new_session=True,
                         stdout=open("/tmp/poketdesktop.log", "a"), stderr=subprocess.STDOUT); return
    gs = games()
    exe = gs[0].exe() if gs else None
    if not exe:
        import winreg, shlex
        try:
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run") as k:
                for i in range(winreg.QueryInfoKey(k)[1]):
                    v = str(winreg.EnumValue(k, i)[1])
                    if "poketdesktop" in v.lower():
                        exe = shlex.split(v, posix=False)[0].strip('"'); break
        except OSError: pass
    for p in gs:
        try: p.kill()
        except Exception: pass
    if exe: time.sleep(2); subprocess.Popen([exe, "--autostart"], cwd=os.path.dirname(exe))


root = tk.Tk()
try: import updater; root.title(f"포스크탑 조종판 {updater.version()}".strip())   # 10/13 자동 업데이트: 지금 판 번호
except Exception: root.title("포스크탑 조종판")
root.configure(bg="white"); root.resizable(True, True); root.minsize(560, 360)   # 10/11 사용자: 창 크기 조절 (탭 내용은 스크롤)
style = ttk.Style(); style.theme_use("clam")
style.configure("TButton", font=(FONT, 10), padding=(10, 6))
style.configure("Big.TButton", font=(FONT, 11, "bold"), padding=(12, 8))

for name, bg, act, big in (("On", GREEN, "#0b6a57", False), ("OnBig", GREEN, "#0b6a57", True), ("Warn", "#d97706", "#b45309", False), ("Stop", RED, "#a93226", True)):
    style.configure(f"{name}.TButton", background=bg, foreground="white", font=(FONT, 11 if big else 10, "bold"), padding=(12, 8) if big else (10, 6))
    style.map(f"{name}.TButton", background=[("active", act), ("pressed", act)], foreground=[("active", "white"), ("pressed", "white")])
_shown = {}   # 10/13: 바뀐 것만 다시 칠한다 (3초마다 120개를 다 configure 하면 창 전체를 다시 배치해 1초씩 멈췄다)
def mark(btn, on, on_text, off_text, on_style="On.TButton", off_style="TButton"):
    v = (on_text if on else off_text, on_style if on else off_style)
    if _shown.get(btn) != v: _shown[btn] = v; btn.configure(text=v[0], style=v[1])
style.configure("TLabel", background="white", font=(FONT, 10))
style.configure("TLabelframe", background="white"); style.configure("TLabelframe.Label", background="white", font=(FONT, 10, "bold"))

state = {}
def row(parent, r, name):
    # 2026-10-11 사용자 '가독성이 너무 떨어진다': 굵은 글씨로 ' · ' 를 줄줄이 잇던 것을 → 이름 칸 고정 폭·위 정렬, 값은 보통 굵기 한 줄에 하나
    ttk.Label(parent, text=name, foreground=GRAY, width=9, anchor="nw").grid(row=r, column=0, sticky="nw", padx=(10, 8), pady=(5, 3))
    v = ttk.Label(parent, text="…", font=(FONT, 11), wraplength=470, justify="left"); v.grid(row=r, column=1, sticky="nw", pady=(5, 3))
    state[name] = v

# 2026-10-11: 탭을 여섯으로 — 상태(요약) / 육성 / 관장 / 포획 / 시간별 기록(누적 표) / 랭크·기타.
# 오늘 수치는 사냥기록.txt(서버 직접 관장·포획도 남음)에서 센다. 예전 '오늘'은 게임 로그만 봐서 서버 직접 처리가 빠졌다
nb = ttk.Notebook(root); nb.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)   # 10/11: 버튼·설정도 '조작' 탭으로 — 창 하나 폭 전체를 정보가 씀(옆에 두면 창을 줄일 때 정보 칸만 좁아짐)
TABS = (("상태", ("사냥기", "게임", "관장전 지금", "오늘 요약", "경험치(오늘)", "이상 감지")),
        ("육성", ("육성 슬롯", "오늘 Lv100", "수동 진화 대기", "최근 교체", "지닌 도구", "유대 미션")),
        ("관장", ("관장 방식", "이긴 곳", "상한·연승", "오늘 판수", "육성 KO(오늘)", "자주 간 곳")),
        ("포획", ("포획 방식", "오늘 포획", "남은 볼", "최근 포획")),
        ("랭크·기타", ("랜덤 배틀", "랭크 팀", "랭크 팀 승패")))
def scroll_frame(parent, w=620, h=470):
    # 창을 줄여도 탭 내용이 잘리지 않게 세로 스크롤 (마우스 휠·트랙패드)
    outer = tk.Frame(parent, bg="white")
    cv = tk.Canvas(outer, bg="white", highlightthickness=0, bd=0, width=w, height=h)
    sb = ttk.Scrollbar(outer, orient="vertical", command=cv.yview)
    inner = tk.Frame(cv, bg="white"); win = cv.create_window(0, 0, window=inner, anchor="nw")
    inner.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
    def fit(e):   # 창 폭에 맞춰 값 글자의 줄바꿈 폭도 바꿈 (좁히면 잘리지 않고 다음 줄로)
        cv.itemconfigure(win, width=e.width)
        for c in inner.grid_slaves(column=1):
            if isinstance(c, ttk.Label): c.configure(wraplength=max(200, e.width - 150))
    cv.bind("<Configure>", fit)
    cv.configure(yscrollcommand=sb.set); cv.pack(side="left", fill="both", expand=True); sb.pack(side="right", fill="y")
    wheel = lambda e: cv.yview_scroll(int(-e.delta) if MAC else int(-e.delta / 120), "units")
    outer.bind("<Enter>", lambda e: cv.bind_all("<MouseWheel>", wheel)); outer.bind("<Leave>", lambda e: cv.unbind_all("<MouseWheel>"))
    return outer, inner
tabs = {}
for name, rows_ in TABS:
    o_, f = scroll_frame(nb); nb.add(o_, text=f" {name} "); tabs[name] = f
    for i, n in enumerate(rows_): row(f, i, n)
hist_tab = tk.Frame(nb, bg="white"); nb.insert(4, hist_tab, text=" 시간별 기록 ")
histbox = tk.Text(hist_tab, width=70, height=15, tabs=("46p", "96p", "128p", "152p", "190p", "250p", "296p", "322p", "348p"), font=("Menlo" if MAC else "Consolas", 9), bg="white", fg="#222222", relief="flat", wrap="none", highlightthickness=0, bd=0)
histbox.pack(padx=6, pady=4)
# 2026-10-11 사용자: 누적 그래프 — 시간별_지표.json(정각마다 1시간 합) + 사냥기록.txt의 Lv100. 항목·기간은 골라서 보고 조종판설정.json에 기억
graph_tab = tk.Frame(nb, bg="white"); nb.insert(5, graph_tab, text=" 누적 그래프 ")
GMET = (("경험치", "만"), ("Lv100", "마리"), ("육성KO", "%"), ("포획", "마리"), ("관장", "판"))
gvar, rvar = tk.StringVar(value=conf().get("그래프_항목", "경험치")), tk.StringVar(value=str(conf().get("그래프_범위", "48")))
def graph_pick():
    c = conf(); c["그래프_항목"], c["그래프_범위"] = gvar.get(), rvar.get(); save(c); draw_graph()
gctl = tk.Frame(graph_tab, bg="white"); gctl.pack(fill="x", padx=6, pady=(4, 0))
_rb = dict(bg="white", fg="#222222", activeforeground="#222222", activebackground="white", selectcolor="white", highlightthickness=0, font=(FONT, 10))   # 맥 다크 모드: 글자색을 박아야 보임
for k, _u in GMET: tk.Radiobutton(gctl, text=k, value=k, variable=gvar, command=graph_pick, **_rb).pack(side="left")
tk.Label(gctl, text="  |", bg="white", fg=GRAY).pack(side="left")
for v_, t_ in (("24", "24시간"), ("48", "48시간"), ("0", "전체")): tk.Radiobutton(gctl, text=t_, value=v_, variable=rvar, command=graph_pick, **_rb).pack(side="left")
canvas = tk.Canvas(graph_tab, width=520, height=200, bg="white", highlightthickness=0); canvas.pack(padx=6, pady=2)
gsum = tk.Label(graph_tab, text="", bg="white", fg="#222222", font=("Menlo" if MAC else "Consolas", 9), justify="left", anchor="w"); gsum.pack(fill="x", padx=8, pady=(0, 4))
c_outer, ctrl_tab = scroll_frame(nb); nb.insert(1, c_outer, text=" 조작 ")   # 아래 사냥기·관장·자동 관리·최근 기록 칸이 여기로 (grid in_)
ctrl_tab.columnconfigure(0, weight=1); ctrl_tab.columnconfigure(1, weight=1)
try: nb.select(int(conf().get("조종판_탭", 0)))   # 마지막에 보던 탭
except Exception: pass
nb.bind("<<NotebookTabChanged>>", lambda e: (lambda c: (c.__setitem__("조종판_탭", nb.index("current")), save(c)))(conf()))

hb = ttk.LabelFrame(root, text="사냥기"); hb.grid(in_=ctrl_tab, row=0, column=0, sticky="nsew", padx=(8, 4), pady=3 if MAC else 6)
def do(f):
    threading.Thread(target=lambda: (f(), root.after(500, refresh)), daemon=True).start()
hunt_on_btn = ttk.Button(hb, text="켜기", style="Big.TButton", command=lambda: do(hunter_on)); hunt_on_btn.grid(row=0, column=0, padx=8, pady=8, sticky="ew")
hunt_off_btn = ttk.Button(hb, text="끄기", style="Big.TButton", command=lambda: do(hunter_off)); hunt_off_btn.grid(row=0, column=1, padx=8, pady=8, sticky="ew")
pause_btn = ttk.Button(hb, text="잠깐 멈춤", command=lambda: (flag(PAUSE, not os.path.exists(PAUSE)), refresh()))
pause_btn.grid(row=1, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")

gb = ttk.LabelFrame(root, text="관장 이어 도전"); gb.grid(in_=ctrl_tab, row=0, column=1, sticky="nsew", padx=(4, 8), pady=3 if MAC else 6)
def force(minutes):
    c = conf(); c["바로진행_까지"] = time.time() + minutes * 60 if minutes else 0
    save(c)
def chain_toggle():
    on = not os.path.exists(CHAIN)
    flag(CHAIN, on); force(15 if on else 0); refresh()
chain_btn = ttk.Button(gb, text="켜기", style="Big.TButton", command=chain_toggle)
chain_btn.grid(row=0, column=0, columnspan=2, padx=8, pady=8, sticky="ew")
ttk.Label(gb, text="손 뗀 뒤 대기(초)\n0 = 일하는 중에도 진행", foreground=GRAY).grid(row=1, column=0, padx=(8, 4), pady=PB, sticky="w")
idle = tk.IntVar(value=int(conf().get("관장_대기초", 60)))
def save_idle(*_):
    try: v = max(0, int(idle.get()))
    except Exception: return
    c = conf(); c["관장_대기초"] = v
    save(c)
ttk.Spinbox(gb, from_=0, to=600, increment=10, width=6, textvariable=idle, command=save_idle, font=(FONT, 10)).grid(row=1, column=1, padx=(0, 8), pady=PB)
idle.trace_add("write", save_idle)
force_btn = ttk.Button(gb, text="관장전 바로 진행 (15분)", command=lambda: (force(0 if conf().get("바로진행_까지", 0) > time.time() else 15), refresh()))
force_btn.grid(row=2, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")
def train_toggle():
    c = conf(); c["관장_수련"] = not c.get("관장_수련", False)
    save(c); refresh()
train_btn = ttk.Button(gb, text="관장 수련 켜기", command=train_toggle)
if not LITE: train_btn.grid(row=3, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")

ttk.Label(hb, text="포획 시도 횟수\n(빠져나오면 다시 던짐)", foreground=GRAY).grid(row=3, column=0, padx=(8, 4), pady=PB, sticky="w")
tries = tk.IntVar(value=int(conf().get("포획_시도횟수", 1)))
def save_tries(*_):
    try: v = max(1, min(10, int(tries.get())))
    except Exception: return
    c = conf(); c["포획_시도횟수"] = v
    save(c)
ttk.Spinbox(hb, from_=1, to=10, increment=1, width=4, textvariable=tries, command=save_tries, font=(FONT, 10)).grid(row=3, column=1, padx=(0, 8), pady=PB)
tries.trace_add("write", save_tries)

def mode_row(parent, r, key, label):
    # 서버 직접(게임 창 없이 서버 요청) / 화면(게임 창을 눌러서). 화면이 잠기면 '화면'이어도 사냥기는 서버로 한다
    v = tk.StringVar(value=conf().get(key, "서버"))
    def put():
        c = conf(); c[key] = v.get(); save(c); refresh()
    fr = tk.Frame(parent, bg="white"); fr.grid(row=r, column=0, columnspan=2, padx=8, pady=PB, sticky="w")
    ttk.Label(fr, text=label, foreground=GRAY).pack(side="left")
    for t in ("서버", "화면"):
        tk.Radiobutton(fr, text=t + (" 직접" if t == "서버" else ""), value=t, variable=v, command=put, bg="white", fg="#222222", activeforeground="#222222", activebackground="white", selectcolor="white", highlightthickness=0, font=(FONT, 10)).pack(side="left", padx=(6, 0))   # 맥 다크 모드: 글자색을 박아야 보임
    return v
catch_mode = mode_row(hb, 6, "포획_방식", "포획 방식")
gym_mode = mode_row(gb, 4, "관장_방식", "관장 방식")
def money_toggle():
    c = conf(); c["돈_모드"] = not c.get("돈_모드", False)
    save(c); refresh()
money_btn = ttk.Button(gb, text="돈 모드 켜기", command=money_toggle)   # 10/12: 이긴 관장 하루 1번 상금(레벨×5원)을 먼저 다 받고 수련
if not LITE: money_btn.grid(row=5, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")
def exp_toggle():
    c = conf(); c["탐험_자동"] = not c.get("탐험_자동", True)
    save(c); refresh()
exp_btn = ttk.Button(gb, text="탐험 자동 켜기", command=exp_toggle)   # 10/13: 빈 탐험 칸에 대성공 나는 포켓몬을 8시간, 돌아오면 보따리 받기
exp_btn.grid(row=6, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")

def grow_toggle():
    c = conf()
    if c.get("육성슬롯", False):   # 끌 때는 확인 (10/10 모르는 사이 꺼져 Lv100 들이 1시간 넘게 자리 차지)
        from tkinter import messagebox
        if not messagebox.askyesno("육성 슬롯 끄기", "육성 슬롯을 끄면 Lv100 이 된 포켓몬도 교체되지 않습니다.\n정말 끌까요?"): return
    c["육성슬롯"] = not c.get("육성슬롯", False)
    save(c); refresh()
grow_btn = ttk.Button(hb, text="육성 슬롯 켜기", command=grow_toggle)
if not LITE: grow_btn.grid(row=4, column=0, columnspan=2, padx=8, pady=PB, sticky="ew")
slots = tk.IntVar(value=int(conf().get("육성_자리수", 1)))
def save_slots(*_):
    try: v = max(1, min(6, int(slots.get())))
    except Exception: return
    c = conf(); c["육성_자리수"] = v
    save(c)
if not LITE:
    ttk.Label(hb, text="육성 자리 수 (1~6)\n주력은 6에서 뺀 만큼", foreground=GRAY).grid(row=5, column=0, padx=(8, 4), pady=PB, sticky="w")
    ttk.Spinbox(hb, from_=1, to=6, increment=1, width=4, textvariable=slots, command=save_slots, font=(FONT, 10)).grid(row=5, column=1, padx=(0, 8), pady=PB)
    slots.trace_add("write", save_slots)

# ---- 자동 관리 (2026-10-09 맥판에서 추가: 기술 배우기 판단·레벨업 육성·랜덤 배틀) ----
ab = ttk.LabelFrame(root, text="자동 관리"); ab.grid(in_=ctrl_tab, row=1, column=0, columnspan=2, sticky="ew", padx=8, pady=3)
def conf_toggle(key, default=True):
    c = conf(); c[key] = not c.get(key, default)
    save(c); refresh()
learn_btn = ttk.Button(ab, command=lambda: conf_toggle("기술_자동판단"))
learn_btn.grid(row=0, column=0, padx=(8, 4), pady=8, sticky="ew")
lvup_btn = ttk.Button(ab, command=lambda: conf_toggle("육성_레벨업"))
lvup_btn.grid(row=0, column=1, padx=4, pady=8, sticky="ew")
if not LITE: ttk.Label(ab, text="랜덤 배틀\n하루 판수", foreground=GRAY).grid(row=0, column=2, padx=(8, 4), pady=8, sticky="w")
pvp_n = tk.IntVar(value=int(conf().get("랜덤배틀_하루", 20)))
def save_pvp(*_):
    try: v = max(0, min(20, int(pvp_n.get())))
    except Exception: return
    c = conf(); c["랜덤배틀_하루"] = v
    save(c)
if not LITE: ttk.Spinbox(ab, from_=0, to=20, increment=1, width=3, textvariable=pvp_n, command=save_pvp, font=(FONT, 10)).grid(row=0, column=3, padx=(0, 8), pady=8)
pvp_n.trace_add("write", save_pvp)
ab.columnconfigure(0, weight=1); ab.columnconfigure(1, weight=1)

eb = tk.Frame(root, bg="white"); eb.grid(in_=ctrl_tab, row=2, column=0, columnspan=2, sticky="ew", padx=8, pady=3)
ttk.Button(eb, text="게임 다시 켜기", command=lambda: do(game_restart)).pack(side="left")
ttk.Button(eb, text="기록 파일 열기", command=lambda: open_path(HUNT)).pack(side="left", padx=8)
ttk.Button(eb, text="폴더 열기", command=lambda: open_path(HERE)).pack(side="left")

lf = ttk.LabelFrame(root, text="최근 기록"); lf.grid(in_=ctrl_tab, row=3, column=0, columnspan=2, sticky="ew", padx=8, pady=(3, 8))
logbox = tk.Text(lf, width=64, height=8 if MAC else 10, font=("Menlo" if MAC else "Consolas", 9), bg="#f7f8fa", fg="#222222", relief="flat", wrap="none", highlightthickness=0, bd=0)   # 맥 다크 모드: 글자색을 안 박으면 흰 글자가 된다
logbox.pack(padx=8, pady=4 if MAC else 8)

def show(name, text, color=None):
    v = (text, color or "black")
    if name in state and _shown.get(name) != v: _shown[name] = v; state[name].configure(text=v[0], foreground=v[1])

_dex = {}
def dex():
    if not _dex:
        try: _dex.update({sp["internal"]: sp for sp in json.load(open(os.path.join(GDIR, "pokedex.json"), encoding="utf-8"))["species"]})
        except Exception: pass
    return _dex

def evo_waiting(P, bag, shop):
    # 진화 대기: 손으로 시켜야 하는 진화(돌·도구, 다 찬 친밀도, 레벨 조건을 넘겼는데 안 한 것). 사냥기는 돌·사탕 진화를 하지 않는다(10/10 사용자 결정)
    S = dex(); bst = lambda sp: sum((S.get(sp) or {}).get("base", {}).values())
    best = {}
    for p in P:
        if p.get("noEvolve"): continue
        for e in (S.get(p["species"]) or {}).get("evo") or []:
            to, m = e.get("to"), e.get("mode")
            if to not in S or (e.get("gender") and e["gender"] != p.get("gender")): continue
            if m == "stone":
                it = shop.get(e.get("item")) or {}; have = bag.get(e.get("item"), 0)
                how, ready = f"{it.get('kr', e.get('item'))} " + (f"가방 {have}개 ✓" if have else f"상점 {it['cost']:,}원" if it.get("buyable") else "없음"), bool(have)
            elif m == "friend" and (p.get("happiness") or 0) >= (e.get("happiness") or 999):
                how, ready = f"친밀도 다 참 — 레벨 하나(이상한사탕 {bag.get('RARECANDY', 0)}개)", True
            elif m == "level" and p["level"] >= (e.get("level") or 999) and (p["level"] >= 100 or not p["onDesktop"]):
                how, ready = f"Lv{e.get('level')} 넘김 — 레벨 하나(이상한사탕 {bag.get('RARECANDY', 0)}개)", True
            else: continue
            k = (ready, p["level"] >= 100, bst(to) - bst(p["species"]))
            if p["id"] not in best or k > best[p["id"]][0]: best[p["id"]] = (k, p, to, how)
    xs = sorted(best.values(), key=lambda x: x[0], reverse=True)
    if not xs: return "없음"
    head = f"{len(xs)}마리 중 바로 가능 {sum(1 for x in xs if x[0][0])}  (✓ = 도구 있음)"
    return head + "\n" + "\n".join(f"{'✓' if k[0] else '·'} {p['info']['name']} → {(S.get(to) or {}).get('kr', to)}  +{k[2]}  {how.replace(' ✓', '')}" for k, p, to, how in xs[:6])

def lv100_by_hour():
    # 사냥기록.txt 의 'Lv100 → 박스로' 를 (날짜, 시) 별로. 줄엔 시각만 있어 'YYYY-MM-DD 자동사냥 시작' 줄과 자정 넘김으로 날짜를 이어 감.
    # 키는 시간별_지표.json 처럼 '그 시간이 끝난 정각'(11:20 → '10-11 12:00')
    import datetime, re
    out, day, prev = {}, None, 0
    try: lines = open(HUNT, encoding="utf-8", errors="ignore").readlines()
    except OSError: return out
    for l in lines:
        m = re.match(r"(\d\d):\d\d:\d\d (\d{4}-\d\d-\d\d) 자동사냥 시작", l)
        if m: day = datetime.date.fromisoformat(m.group(2))
        if not (len(l) > 8 and l[2] == ":" and l[:2].isdigit()) or day is None: continue
        h = int(l[:2])
        if h < prev - 12: day += datetime.timedelta(days=1)
        prev = h
        if "육성 끝:" in l and re.search(r"육성 끝: \S+ Lv100", l) and "친밀도 채우기보다" not in l:
            k = (datetime.datetime.combine(day, datetime.time(h)) + datetime.timedelta(hours=1)).strftime("%m-%d %H:00")
            out[k] = out.get(k, 0) + 1
    return out

def draw_graph():
    rows = slow.get("grows") or []
    met, rng = gvar.get(), int(rvar.get() or 0)
    rows = rows[-rng:] if rng else rows
    unit = dict(GMET).get(met, "")
    val = {"경험치": lambda r: (r.get("경험치합") or 0) / 1e4, "Lv100": lambda r: r.get("Lv100", 0),
           "육성KO": lambda r: (100 * r["육성KO"] / r["전체KO"]) if r.get("전체KO") else None,
           "포획": lambda r: r.get("잡음") or 0, "관장": lambda r: r.get("관장판") or 0}[met]
    canvas.delete("all")
    W, H, L, B, T = 520, 200, 40, 22, 14
    vs = [val(r) for r in rows]
    if not rows: canvas.create_text(W / 2, H / 2, text="기록 없음", fill=GRAY); return
    top = max([v for v in vs if v is not None] + [1]) * 1.1
    bw = (W - L - 6) / len(rows)
    for i in range(5):   # 눈금
        y = H - B - (H - B - T) * i / 4
        canvas.create_line(L, y, W - 4, y, fill="#e5e7eb")
        canvas.create_text(L - 4, y, text=f"{top * i / 4:.0f}", anchor="e", fill=GRAY, font=(FONT, 8))
    for i, (r, v) in enumerate(zip(rows, vs)):
        x0 = L + i * bw + 1
        if v is not None and v > 0:
            canvas.create_rectangle(x0, H - B - (H - B - T) * v / top, x0 + max(bw - 2, 1), H - B, fill=GREEN, width=0)
        hh = str(r.get("시각", ""))[6:8]
        if hh == "00" or i == 0: canvas.create_text(x0, H - B + 3, text=str(r.get("시각", ""))[:5].replace("-", "/"), anchor="nw", fill="#222222", font=(FONT, 8))
        elif len(rows) <= 24 and int(hh or 0) % 3 == 0: canvas.create_text(x0, H - B + 3, text=hh + "시", anchor="nw", fill=GRAY, font=(FONT, 8))
    ok = [v for v in vs if v is not None]
    if ok:
        avg = sum(ok) / len(ok); y = H - B - (H - B - T) * avg / top
        canvas.create_line(L, y, W - 4, y, fill=RED, dash=(4, 3))
        canvas.create_text(W - 6, y - 2, text=f"평균 {avg:.0f}{unit}", anchor="se", fill=RED, font=(FONT, 8))
    canvas.create_text(L, 2, text=f"{met} ({unit}, 1시간마다) — 최근 {len(rows)}시간", anchor="nw", fill="#222222", font=(FONT, 9, "bold"))
    gsum.configure(text=slow.get("gday", ""))

slow = {"at": 0}
def slow_refresh():
    import re, collections
    load = lambda f, d: (json.load(open(os.path.join(HERE, f), encoding="utf-8")) if os.path.exists(os.path.join(HERE, f)) else d)
    L = today_lines(); cnt = lambda w: sum(1 for l in L if w in l)
    # ---- 관장
    try:
        g = api("/api/gym")
        try: rw = len(load("관장_다시이김.json", {}).get(time.strftime("%Y-%m-%d"), []))
        except Exception: rw = 0
        slow["이긴 곳"] = f"{g['cleared']} / {g['total']}" + (f" · 오늘 상금 받은 곳 {rw}" if rw else "")
    except Exception: slow["이긴 곳"] = "읽지 못함"
    st = load("관장_승패.json", {})
    slow["상한·연승"] = (f"상한 Lv{st.get('cap')}" if st.get("cap", 999) < 999 else "상한 없음") + f"   연승 {st.get('streak', 0)}"
    games_ = cnt("관장(서버 직접) 끝") + cnt("관장전 끝 - 지도로")
    won, lost, draw = cnt("끝: 이김"), cnt("관장전 짐"), cnt("관장 비김")
    lv = [int(m.group(1)) for l in L for m in [re.search(r"관장(?:\(서버 직접[^)]*\)| 수련| 다시 이기기| 이어 도전): \S+ \S+ Lv\.(\d+)", l)] if m]
    slow["오늘 판수"] = f"{games_}판   {won}승 {lost}패" + (f" {draw}비김" if draw else "") + (f"   평균 Lv{round(sum(lv) / len(lv))}" if lv else "")
    ko, kg = cnt("관장 쓰러뜨림"), cnt("(육성)")
    slow["육성 KO(오늘)"] = f"{round(100 * kg / ko)}%   ({kg} / {ko})" if ko else "아직 없음"
    names = collections.Counter(m.group(1) for l in L for m in [re.search(r"관장(?:\(서버 직접[^)]*\)| 수련| 다시 이기기| 이어 도전): \S+ (\S+ Lv\.\d+)", l)] if m)
    slow["자주 간 곳"] = "\n".join(f"{k}  {v}번" for k, v in names.most_common(4)) or "—"
    # ---- 포획
    tries_, got = cnt(" 포획 "), cnt("→ 잡음")
    slow["오늘 포획"] = f"{got} / {tries_}마리" + (f"   ({round(100 * got / tries_)}%)" if tries_ else "")
    try:
        bag = api("/api/bag").get("bag") or {}
        balls = sorted(((k, v) for k, v in bag.items() if k.endswith("BALL") and k not in ("IRONBALL",) and v), key=lambda kv: -kv[1])
        KR = {"POKEBALL": "몬스터볼", "GREATBALL": "슈퍼볼", "ULTRABALL": "하이퍼볼", "MASTERBALL": "마스터볼", "HEALBALL": "힐볼", "PREMIERBALL": "프레미어볼",
              "LOVEBALL": "러브볼", "NESTBALL": "네스트볼", "NETBALL": "네트볼", "DUSKBALL": "다크볼", "QUICKBALL": "퀵볼", "TIMERBALL": "타이머볼",
              "REPEATBALL": "리피트볼", "DREAMBALL": "드림볼", "LUXURYBALL": "럭셔리볼", "FRIENDBALL": "프렌드볼", "LEVELBALL": "레벨볼", "MOONBALL": "문볼",
              "HEAVYBALL": "헤비볼", "LUREBALL": "루어볼", "FASTBALL": "스피드볼", "DIVEBALL": "다이브볼", "SAFARIBALL": "사파리볼", "BEASTBALL": "울트라볼",
              "CHERISHBALL": "프레셔스볼", "SPORTBALL": "콘테스트볼", "PARKBALL": "파크볼"}
        slow["남은 볼"] = "   ".join(f"{KR.get(k, k.title())} {v}" for k, v in balls[:4]) or "없음"
        slow["남은 볼_색"] = RED if bag.get("POKEBALL", 0) + bag.get("GREATBALL", 0) + bag.get("ULTRABALL", 0) < 100 else None
    except Exception: slow["남은 볼"] = "읽지 못함"
    def cline(l):   # 볼 던진 과정 전체 대신: 시각 이름 결과 · 던진 볼 수 · 가장 낮았던 체력
        m = re.search(r"포획 (?:\(서버 직접[^)]*\) )?(\S+ Lv\d+)", l); hp = [int(x) for x in re.findall(r"체력 (\d+)%", l)]
        res = "✓ 잡음" if l.rstrip().endswith("잡음") else "✗ 쓰러뜨림" if "쓰러뜨림" in l else "✗ 놓침" if "빠짐" in l else "✗ " + l.rstrip().split("→")[-1].strip()[:12]
        return f"{l[:5]}  {m.group(1) if m else '?'}  {res}" + (f"  (볼 {l.count('던짐')}개, 체력 {min(hp)}%)" if hp else "")
    slow["최근 포획"] = "\n".join([cline(l) for l in L if " 포획 " in l and "→" in l][-5:]) or "—"
    # ---- 육성
    lv100 = [re.search(r"육성 끝: (\S+) Lv100", l).group(1) for l in L if re.search(r"육성 끝: \S+ Lv100", l) and "친밀도 채우기보다" not in l]   # 친밀도 대기로 이미 Lv100이던 것은 뺌
    slow["오늘 Lv100"] = f"{len(lv100)}마리" + ("\n최근: " + ", ".join(lv100[-5:]) if lv100 else "")
    ch = [l[:5] + "  " + re.sub(r"\s*\(.*|\s*→ 박스로.*", "", l[9:].replace("육성 시작: ", "들어옴  ").replace("육성 끝: ", "나감  ")).strip() for l in L if "육성 시작:" in l or "육성 끝:" in l][-4:]
    slow["최근 교체"] = "\n".join(ch) or "—"
    try:
        P = api("/api/pokemon")["pokemon"]; desk = [p for p in P if p["onDesktop"]]
        slow["지닌 도구"] = "\n".join(f"{p['info']['name']}  —  {p.get('heldKr') or '없음'}" for p in desk)
        bond = api("/api/me").get("bond") or {}
        near = sorted((p for p in desk if (p.get("happiness") or 0) < 255), key=lambda p: -(p.get("happiness") or 0))[:3]
        slow["유대 미션"] = (f"진행 중 {len(bond.get('ready') or [])}   받을 것 {len(bond.get('claim') or [])}\n친밀도(255 만점): "
                          + ", ".join(f"{p['info']['name']} {p.get('happiness')}" for p in near))
    except Exception: slow["지닌 도구"] = slow["유대 미션"] = "읽지 못함"
    try:
        shop = {x["id"]: x for x in api("/api/shop").get("items") or []}
        slow["수동 진화 대기"] = evo_waiting(P, api("/api/bag").get("bag") or {}, shop)
    except Exception: slow["수동 진화 대기"] = "읽지 못함"
    # ---- 시간별 기록 (누적 표) + 오늘 경험치
    rows = load("시간별_지표.json", {}).get("rows") or []
    day = time.strftime("%m-%d")
    today = [r for r in rows if str(r.get("시각", "")).startswith(day) and r.get("경험치합") is not None]
    slow["경험치(오늘)"] = f"{sum(r['경험치합'] for r in today) / 1e4:,.0f}만   (1시간 평균 {round(sum(r['경험치합'] for r in today) / max(len(today), 1) / 1e4)}만, {len(today)}시간)"
    hdr = "시각\t경험치\t관장\t패\t평균Lv\t육성KO\t포획\t놓침\t오류\t교체\n"
    lines_ = ["\t".join(str(x) for x in (str(r.get('시각', ''))[6:], f"{(r.get('경험치합') or 0) / 1e4:.0f}만", r.get('관장판', 0), r.get('관장짐', 0), r.get('관장평균Lv') or '-',
              f"{r.get('육성KO')}/{r.get('전체KO')}" if r.get('전체KO') is not None else '-', f"{r.get('잡음')}/{r.get('포획시도')}", r.get('놓침', 0), r.get('오류', 0), r.get('육성교체', 0)))
              for r in rows[-12:]]
    lvh = lv100_by_hour()
    slow["grows"] = [dict(r, Lv100=lvh.get(str(r.get("시각")), 0)) for r in rows if r.get("경험치합") is not None]
    days = {}
    for r in slow["grows"]:
        d = days.setdefault(str(r["시각"])[:5], [0, 0, 0, 0, 0, 0])
        d[0] += 1; d[1] += r.get("경험치합") or 0; d[2] += r.get("관장판") or 0; d[3] += r.get("잡음") or 0; d[4] += r.get("포획시도") or 0; d[5] += r["Lv100"]
    slow["gday"] = "날짜    시간  경험치    관장   포획      Lv100\n" + "\n".join(
        f"{k.replace('-', '/')}  {d[0]:>3}  {d[1] / 1e4:>6.0f}만 {d[2]:>5}판 {d[3]:>4}/{d[4]:<4} {d[5]:>4}마리" for k, d in sorted(days.items()))
    slow["hist"] = hdr + "\n".join(lines_[::-1]) + "\n\n최근이 위 · 경험치 = 그 시각 전 1시간 합 · 육성KO = 육성 포켓몬이 직접 쓰러뜨린 수/전체\n(10/11 00~03시 판수·포획은 시험 출력이 섞여 부풀어 있음)"
    # ---- 상태 요약 / 이상 감지
    slow["오늘 요약"] = f"Lv100 {len(lv100)}마리   관장 {games_}판   포획 {got}/{tries_}   오류 {cnt('오류(')}"
    an = load("이상_기록.json", [])
    slow["이상 감지"] = (" / ".join(f"{x['at'][6:11]} {x['kind']}" for x in an[-3:]) or "없음")
    # ---- 랭크·기타
    try:
        f = api("/api/pvp/pending").get("fight") or {}
        r = api("/api/pvp/records?limit=40")
        sm = r.get("summary") or {}
        d0 = time.strftime("%Y-%m-%d")
        mine = [x for x in r.get("records") or [] if x.get("kind") == "random" and x.get("started") and kst_day(x.get("at")) == d0]
        w, l = sum(1 for x in mine if x.get("result") == "win"), sum(1 for x in mine if x.get("result") == "lose")
        slow["랜덤 배틀"] = (f"오늘 {f.get('foughtToday', 0)}/{f.get('dailyBattles', 20)}판 · {w}승 {l}패 · RP {sm.get('rp', '?')} ({sm.get('tierKr', '?')}"
                         + (f", {sm.get('nextTierKr')}까지 {sm.get('rpToNext')}" if sm.get("rpToNext") else "") + ")")
    except Exception: slow["랜덤 배틀"] = "읽지 못함"
    try:
        t = api("/api/pvp/team")
        slow["랭크 팀"] = ", ".join(f"{p['info']['name']} Lv{p['level']}" for p in t.get("pokemon") or []) or "등록 안 함 (데리고 다니는 파티로 싸움)"
        d = load("랭크팀_승패.json", {}); ids = t.get("ids") or []
        k = ",".join(str(i) for i in sorted(ids)); w, l = (d.get("rec") or {}).get(k, [0, 0])
        lg = [x for x in (d.get("log") or []) if x.get("result") in ("win", "lose")][-10:]
        slow["랭크 팀 승패"] = f"지금 팀 {w}승 {l}패 · 최근 10판 {sum(x['result'] == 'win' for x in lg)}승 · 막은 조합 {len(d.get('blocked') or [])}개"
    except Exception: slow["랭크 팀"] = slow["랭크 팀 승패"] = "읽지 못함"

def kst_day(iso):
    # 서버 시각(UTC ISO) → 한국 날짜. 랜덤 배틀 하루 한도도 한국 자정 기준이다
    import datetime
    try: return (datetime.datetime.fromisoformat(iso) + datetime.timedelta(hours=9)).strftime("%Y-%m-%d")
    except Exception: return ""

def refresh():
    hs, gs = hunters(), games()
    paused = os.path.exists(PAUSE)
    show("사냥기", ("잠깐 멈춤" if paused else "켜짐") if hs else "꺼짐", (GRAY if paused else GREEN) if hs else RED)
    show("게임", "켜짐" if gs else "꺼짐", GREEN if gs else RED)
    on = os.path.exists(CHAIN)
    w = conf().get("관장_대기초", 60)
    mark(hunt_on_btn, bool(hs), "● 켜짐", "켜기", "OnBig.TButton", "Big.TButton")
    mark(hunt_off_btn, not hs, "● 꺼짐", "끄기", "Stop.TButton", "Big.TButton")
    mark(chain_btn, on, "● 켜짐 — 누르면 끄기", "○ 꺼짐 — 누르면 켜기", "OnBig.TButton", "Big.TButton")
    mark(train_btn, conf().get("관장_수련", False), "● 관장 수련 켜짐 — 누르면 끄기", "○ 관장 수련 꺼짐 (다 이긴 뒤 경험치용 반복)")
    mark(exp_btn, conf().get("탐험_자동", True), "● 탐험 자동 켜짐 — 빈 칸에 박스 포켓몬 8시간(대성공 먼저), 돌아오면 받기", "○ 탐험 자동 꺼짐")
    mark(money_btn, conf().get("돈_모드", False), "● 돈 모드 켜짐 — 높은 관장 상금 먼저, 낮은 곳은 자정(또는 PC 끄는 시각)까지 나눠서", "○ 돈 모드 꺼짐 (이긴 관장 하루 상금 받기, 육성과 균형)")
    left = conf().get("바로진행_까지", 0) - time.time()
    mark(force_btn, left > 0, f"● 바로 진행 중 {int(left // 60) + 1}분 남음 — 누르면 원래대로", "○ 관장전 바로 진행 (15분)")
    mark(pause_btn, paused, "● 멈춤 중 — 누르면 다시 진행", "잠깐 멈춤 (화면 써야 할 때)", "Warn.TButton")
    pv = conf().get("랜덤배틀_하루", 20)
    for k in ("이긴 곳", "상한·연승", "오늘 판수", "육성 KO(오늘)", "자주 간 곳", "오늘 포획", "최근 포획", "오늘 Lv100", "수동 진화 대기", "최근 교체",
              "지닌 도구", "유대 미션", "경험치(오늘)", "오늘 요약", "랭크 팀", "랭크 팀 승패"):
        show(k, slow.get(k, "…"))
    show("남은 볼", slow.get("남은 볼", "…"), slow.get("남은 볼_색"))
    show("이상 감지", slow.get("이상 감지", "…"), RED if slow.get("이상 감지", "없음") not in ("없음", "…") else None)
    show("랜덤 배틀", slow.get("랜덤 배틀", "…") if pv else "꺼짐", None if pv else GRAY)
    lk = locked()
    for key, nm in (("관장_방식", "관장 방식"), ("포획_방식", "포획 방식")):
        m = conf().get(key, "서버")
        show(nm, ("서버 직접 — 게임 창을 누르지 않고 서버 요청으로" if m == "서버" else "화면 — 게임 창을 눌러서" + (" (지금 화면이 잠겨 서버로 하는 중)" if lk else "")), GREEN if m == "서버" or lk else None)
    if slow.get("hist") and _shown.get("hist") != slow["hist"]:
        _shown["hist"] = slow["hist"]; histbox.configure(state="normal"); histbox.delete("1.0", "end"); histbox.insert("end", slow["hist"]); histbox.configure(state="disabled")
    if slow.get("grows") is not slow.get("_drawn"): slow["_drawn"] = slow.get("grows"); draw_graph()
    mark(learn_btn, conf().get("기술_자동판단", True), "● 기술 자동 판단", "○ 기술 자동 판단 꺼짐")
    mark(lvup_btn, conf().get("육성_레벨업", True), "● 레벨업 육성", "○ 레벨업 육성 꺼짐")
    try:
        st = json.load(open(os.path.join(HERE, "사냥기상태.json"), encoding="utf-8"))
        g = st.get("관장", "…") if hs and time.time() - st.get("시각", 0) < 30 else "—"
    except Exception: g = "—"
    show("관장전 지금", g, GREEN if g.startswith("진행 중") else GRAY if g.startswith("대기") or g == "—" else None)
    gr = conf().get("육성슬롯", False)
    try: gs = json.load(open(os.path.join(HERE, "사냥기상태.json"), encoding="utf-8")).get("육성", "확인 중…")
    except Exception: gs = "확인 중…"
    import re as _re
    bar = lambda lv: "■" * (lv // 10) + "□" * (10 - lv // 10)
    gl = [(m.group(1), int(m.group(2))) for m in _re.finditer(r"(\S+) Lv(\d+)", gs)] if gr else []
    show("육성 슬롯", ("\n".join(f"{bar(lv)}  Lv{lv:<3} {n}" for n, lv in gl) if gl else gs) if gr else "꺼짐", GREEN if gr else GRAY)
    mark(grow_btn, gr, "● 육성 슬롯 켜짐 — 누르면 끄기", "○ 육성 슬롯 꺼짐 (진화·레벨업할 포켓몬 차례로 키우기)")
    t = tail()
    if _shown.get("log") != t:
        _shown["log"] = t; logbox.configure(state="normal"); logbox.delete("1.0", "end"); logbox.insert("end", t); logbox.see("end"); logbox.configure(state="disabled")
    if time.time() - slow["at"] > 60:
        slow["at"] = time.time(); threading.Thread(target=slow_refresh, daemon=True).start()

def loop():
    try: refresh()
    finally: root.after(3000, loop)
loop()
root.columnconfigure(0, weight=1); root.rowconfigure(0, weight=1)
  # 창을 키우고 줄이면 왼쪽 정보 칸이 따라 늘고 줄어듦
root.update_idletasks()
_g = conf().get("조종판_크기")   # 마지막 창 크기·위치 (사용자가 바꾼 대로)
if _g: root.geometry(_g)
else:   # 처음: 내용 크기, 단 화면보다 크면 (맥은) 창을 38x105 로 망가뜨리므로 화면 안으로
    root.geometry(f"{min(root.winfo_reqwidth(), root.winfo_screenwidth() - 80)}x{min(root.winfo_reqheight(), root.winfo_screenheight() - 60)}+40+25")
_gs = {"id": None}
def _geo_save(e):
    if e.widget is not root: return
    if _gs["id"]: root.after_cancel(_gs["id"])
    _gs["id"] = root.after(800, lambda: (lambda c: (c.__setitem__("조종판_크기", root.geometry()), save(c)))(conf()))
root.bind("<Configure>", _geo_save)
root.mainloop()
