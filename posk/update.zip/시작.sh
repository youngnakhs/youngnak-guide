#!/bin/bash
# 포스크탑 자동사냥 (맥) — 앱·포스크탑 자동사냥.command 가 부른다. 새 판 받기 → 게임('탐지기' 붙여) → 조종판.
# 사냥기는 조종판의 [켜기] 로 켠다. (2026-10-13, 10-09 판 .command 를 앱에서도 쓰게 옮김)
H="$HOME/dev/개발_프로젝트/포스크탑자동사냥"
G="$HOME/dev/개발_프로젝트/poketdesktop"
cd "$H" || exit 1
.venv/bin/python updater.py >>/tmp/posk_panel.log 2>&1
# 설치된 포스크탑 앱(/Applications/포스크탑.app, 로그인 때 스스로 켜짐)은 탐지기가 없어 사냥기가 못 본다 → 끄고 탐지기 붙은 게임으로 (로그인 정보는 같은 폴더라 그대로)
pkill -f "포스크탑.app/Contents/MacOS" && sleep 3
if ! pgrep -f "game_probe.py" >/dev/null; then
  pgrep -f "client/run.pyw" >/dev/null && { pkill -f "client/run.pyw"; sleep 3; }
  (cd "$G" && nohup .venv/bin/python "$H/game_probe.py" "$G" >>/tmp/poketdesktop.log 2>&1 &)
fi
pgrep -f "posk_panel.py" >/dev/null || nohup .venv/bin/python posk_panel.py >/tmp/posk_panel.log 2>&1 &
