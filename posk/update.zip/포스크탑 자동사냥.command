#!/bin/bash
# 터미널에서 켜고 싶을 때 (앱과 같음)
/bin/bash "$HOME/dev/개발_프로젝트/포스크탑자동사냥/시작.sh"
echo "게임과 조종판을 켰습니다. 이 창은 닫아도 됩니다."
sleep 2; osascript -e 'tell application "Terminal" to close front window' >/dev/null 2>&1 &
