# -*- coding: utf-8 -*-
"""랜덤 배틀 팀 고르기 - 서버와 같은 배틀 엔진(common/party_battle)으로 미리 붙여 본다 (2026-11-15 맥).

랜덤 배틀은 '양쪽 팀 + 시드'면 결과가 정해지는 자동 판이다(server/app/pvp.py run_match).
그래서 최근에 만난 상대 팀들을 대전 기록(재생 로그)에서 되살리고, 내 후보 팀을 그 팀들과 여러 시드로
붙여 이긴 비율이 가장 높은 팀을 고른다. 상대의 기술·특성·메가는 로그에 나온 것만 알 수 있어서
안 나온 기술은 배울 수 있는 기술 중 센 것으로, 노력치는 '공격 쪽 252 + 스피드 252' 로 채운다.

사냥기(posk_hunt.py)가 api 함수를 넘겨 쓴다. 서버 규칙(같은 종 1, 전설·환상 1, 같은 도구 1,
탐험 중 제외, Lv.50 이상 6마리)은 여기서 같이 지킨다.
"""
import json, os, random, sys, time

MAC = sys.platform == 'darwin'
HERE = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))   # 윈도우 exe: 코드\ 가 아니라 exe 옆 _game_pyc (posk_hunt 와 같게)
GAME = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
GDIR = os.path.expanduser('~/Library/Application Support/poketdesktop') if MAC else os.path.join(os.environ.get('APPDATA', ''), 'poketdesktop')
CACHE = os.path.join(HERE, '랜덤배틀_상대팀.json')
CAP = 50

if GAME not in sys.path: sys.path.insert(0, GAME)
from common import pokelogic as PL, party_battle as PB   # noqa: E402

_dex = _raw = None
def dex():
    global _dex, _raw
    if _dex is None:
        p = os.path.join(GDIR, 'pokedex.json')
        _raw = json.load(open(p, encoding='utf-8')); _dex = PL.Pokedex.load(p)
    return _dex

def raw():
    dex(); return _raw

def _maps():
    r = raw()
    sp = {s['internal']: s for s in r['species']}
    mv = r['moves'] if isinstance(r['moves'], dict) else {m['key']: m for m in r['moves']}
    kr2mv = {}
    for k, m in mv.items(): kr2mv.setdefault(m.get('kr'), k)
    stone = {}   # (종) -> 메가스톤
    for m in r.get('megas') or []:
        if m.get('megaOf') and m.get('megaStone'): stone.setdefault(m['megaOf'], m['megaStone'])
    return sp, mv, kr2mv, stone

# ------------------------------------------------------------ 상대 팀 되살리기
def _foe_from_match(ev):
    sp, mv, kr2mv, stone = _maps()
    E = ev.get('events') or []
    t = next((e for e in E if e.get('t') == 'teams'), None)
    if not t: return None
    team = [{'species': m['species'], 'maxhp': m.get('maxhp'), 'moves': [], 'ability': None, 'mega': False} for m in t.get('foe') or []]
    by_name = {}
    for i, m in enumerate(t.get('foe') or []): by_name.setdefault(m.get('name'), i)
    cur = None
    for e in E:
        if e.get('t') == 'round' and isinstance(e.get('foe'), dict): cur = by_name.get(e['foe'].get('name'), cur)
        if e.get('who') != 'foe' or cur is None: continue
        if e.get('t') == 'move':
            k = kr2mv.get(e.get('move'))
            if k and k not in team[cur]['moves'] and len(team[cur]['moves']) < 4: team[cur]['moves'].append(k)
        elif e.get('t') == 'ability' and e.get('ability'): team[cur]['ability'] = e['ability']
        elif e.get('t') == 'mega': team[cur]['mega'] = True
    return team

def foe_teams(api, n=60):
    """최근 랜덤 배틀 상대 팀 (되살린 것). 판마다 한 번만 받아 CACHE 에 둔다."""
    try: cache = json.load(open(CACHE, encoding='utf-8'))
    except Exception: cache = {}
    rec = (api(f'/api/pvp/records?limit={min(100, n)}') or {}).get('records') or []
    out = []
    for r in rec:
        if r.get('kind') != 'random' or not r.get('matchId'): continue
        k = str(r['matchId'])
        if k not in cache and r.get('canReplay', True):
            ev = api(f"/api/pvp/match/{r['matchId']}") or {}
            team = _foe_from_match(ev)
            if team: cache[k] = {'at': r.get('at'), 'result': r.get('result'), 'foe': r.get('foe'), 'team': team}
        if k in cache: out.append(cache[k])
    keep = dict(sorted(cache.items(), key=lambda kv: kv[1].get('at') or '')[-300:])
    tmp = CACHE + '.tmp'; json.dump(keep, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False); os.replace(tmp, CACHE)
    return out[:n]

def _fill_moves(spc, seen, mv):
    """안 보인 기술 칸: 그 종이 Lv.50 까지 배우는 기술·떠올리기 기술 중 위력 센 것 (자속 우선, 공격 쪽 맞춤)."""
    moves = list(seen)
    if len(moves) >= 4: return moves[:4]
    base = spc.get('base') or {}
    cat = 'physical' if base.get('atk', 0) >= base.get('spa', 0) else 'special'
    pool = {k for l, k in spc.get('moves') or [] if l <= CAP} | set(spc.get('remind') or [])
    types = set(spc.get('types') or [])
    def val(k):
        m = mv.get(k) or {}
        if not m.get('power') or m.get('cat') == 'status': return -1
        return m['power'] * (1.5 if m.get('type') in types else 1) * (1 if m.get('cat') == cat else 0.6) * ((m.get('acc') or 100) / 100)
    seen_types = {(mv.get(k) or {}).get('type') for k in moves}
    for k in sorted(pool, key=val, reverse=True):
        if len(moves) >= 4: break
        if val(k) <= 0: break
        t = (mv.get(k) or {}).get('type')
        if k in moves or (t in seen_types and len(moves) < 3 and len(pool) > 8): continue   # 앞 칸은 타입을 고르게
        moves.append(k); seen_types.add(t)
    for k in sorted(pool, key=val, reverse=True):
        if len(moves) >= 4: break
        if k not in moves and val(k) > 0: moves.append(k)
    return moves or ['TACKLE']

FOE_NATURE = {'atk': 'ADAMANT', 'spa': 'MODEST'}   # 상대는 공격 쪽을 올린 성격으로 본다 (모르는 값 - 세게 잡는 편)

def foe_mons(team):
    sp, mv, kr2mv, stone = _maps()
    out = []
    for i, f in enumerate(team):
        s = sp.get(f['species']) or {}
        base = s.get('base') or {}
        atk = 'atk' if base.get('atk', 0) >= base.get('spa', 0) else 'spa'
        # 체력 노력치는 로그의 최대 체력에서 되짚는다: Lv.50 최대 체력 = (2×종족값 + 개체값 + 노력치/4) / 2 + 60
        hp_ev = 4
        if f.get('maxhp') and base.get('hp'):
            hp_ev = max(0, min(252, int(((f['maxhp'] - 60) * 2 - 2 * base['hp'] - 31) * 4)))
        evs = {'hp': hp_ev, 'atk': 0, 'def': 0, 'spa': 0, 'spd': 0, 'spe': 0}; evs[atk] = 252
        evs['spe'] = max(0, min(252, 510 - hp_ev - 252))
        ab = f.get('ability') or ((s.get('abil') or [None])[0])
        out.append({'id': -1 - i, 'species': f['species'], 'nickname': None, 'level': CAP, 'exp': 0, 'nature': FOE_NATURE.get(atk, 'HARDY'),
                    'ability': ab, 'hiddenAbility': ab == s.get('hidden'), 'gender': 'M', 'shiny': False, 'happiness': 255,
                    'ivs': {k: 31 for k in ('hp', 'atk', 'def', 'spa', 'spd', 'spe')}, 'evs': evs,
                    'moves': _fill_moves(s, f.get('moves') or [], mv),
                    'held': stone.get(f['species']) if f.get('mega') else None, 'bonded': bool(f.get('mega'))})
    return out

# ------------------------------------------------------------ 붙여 보기
_MY_KEYS = ('id', 'species', 'nickname', 'level', 'exp', 'nature', 'ability', 'hiddenAbility', 'gender', 'shiny', 'happiness',
            'ivs', 'evs', 'moves', 'held', 'bonded', 'hyper', 'form')
def my_mon(p):
    m = {k: p.get(k) for k in _MY_KEYS if k in p}
    m['level'] = min(CAP, int(m.get('level') or 1))
    return m

def win_rate(team, foes, seeds=2, keystone=True, seed0=7, war_ai=False):
    """team(내 포켓몬 dict, 순서대로) 이 foes(상대 팀 목록) 에게 이긴 비율. 비기면 반."""
    d = dex(); mine = [my_mon(p) for p in team]; s = n = 0
    for j, f in enumerate(foes):
        for k in range(seeds):
            try:
                o = PB.simulate(d, [dict(x) for x in mine], [dict(x) for x in f], seed=seed0 + 1000 * j + k,
                                keystone={'me': keystone, 'foe': True}, zring={'me': keystone, 'foe': True}, war_ai=war_ai)
            except Exception:
                continue
            s += {'me': 1, 'draw': 0.5}.get(o.get('winner'), 0); n += 1
    return s / n if n else 0

def legal(team, legend_of):
    sps = [p['species'] for p in team]
    if len(set(sps)) < len(sps): return False
    if sum(1 for p in team if legend_of(p)) > 1: return False
    held = [str(p.get('held')).upper() for p in team if p.get('held')]
    return len(set(held)) == len(held)

def best_team(P, foes, away=(), current=(), legend_of=None, budget=150, seeds=2, say=print):
    """랜덤 배틀 팀 고르기: 지금 팀·사냥기 추천 팀에서 시작해 한 자리씩 바꿔 보며 이긴 비율이 오르면 남긴다.
    budget = 팀을 붙여 볼 횟수 상한 (한 번 = 상대 팀 수 × seeds 판)."""
    legend_of = legend_of or (lambda p: False)
    pool = [p for p in P if int(p.get('level') or 0) >= CAP and p['id'] not in set(away)
            and sum(1 for k in p.get('moves') or [] if (raw()['moves'].get(k) or {}).get('power')) >= 2]
    byid = {p['id']: p for p in pool}
    # 후보를 줄인다: 혼자서 상대 첫 판 몇 개에 얼마나 버티나(1:6) 대신 종족값·레벨 큰 순 상위 40
    sp = _maps()[0]
    bst = lambda p: sum((sp.get(p['species']) or {}).get('base', {}).values())
    # 11/15 사용자 '스피드와 공격이 빠르면 연타로 이기지 않나' - 시뮬로 재 보니 맞다: 스피드×공격(물리·특수 큰 쪽) 순 팀이
    # 58%, 종족값 순 후보에서 찾은 팀은 52%. 그래서 후보는 두 줄 세우기를 합치고, 출발점도 스피드×공격 팀으로 둔다.
    st = lambda p: ((p.get('info') or {}).get('stats') or {})
    sa = lambda p: st(p).get('spe', 0) * max(st(p).get('atk', 0), st(p).get('spa', 0))
    cands = []
    for p in sorted(pool, key=bst, reverse=True)[:30] + sorted(pool, key=sa, reverse=True)[:30]:
        if p not in cands: cands.append(p)
    for i in current:
        if i in byid and byid[i] not in cands: cands.append(byid[i])
    def fill(t, order):
        t = list(t)
        for p in order:
            if len(t) >= 6: break
            if p not in t and legal(t + [p], legend_of): t.append(p)
        return t
    starts = [fill([], sorted(pool, key=sa, reverse=True)), fill([byid[i] for i in current if i in byid][:6], cands)]
    starts = [t for t in starts if len(t) == 6]
    if not starts: return None, 0, 0
    cache = {}
    def score(t):
        k = tuple(p['id'] for p in t)
        if k not in cache: cache[k] = win_rate(t, foes, seeds)
        return cache[k]
    cur_ids = [i for i in current if i in byid]
    base = score([byid[i] for i in cur_ids]) if len(cur_ids) == 6 else 0
    best = max(starts, key=score); bs = score(best); used = 3
    improved = True
    while improved and used < budget:
        improved = False
        for slot in range(6):
            for p in cands:
                if used >= budget: break
                if p in best: continue
                t = best[:slot] + [p] + best[slot + 1:]
                if not legal(t, legend_of): continue
                v = score(t); used += 1
                if v > bs + 1e-9: best, bs, improved = t, v, True
        # 순서(선두) 바꾸기: 앞 두 자리를 나머지와 바꿔 본다
        for a in range(2):
            for b in range(a + 1, 6):
                if used >= budget: break
                t = list(best); t[a], t[b] = t[b], t[a]
                v = score(t); used += 1
                if v > bs + 1e-9: best, bs, improved = t, v, True
    return best, bs, base

# ------------------------------------------------------------ 기술·도구 다듬기 (11/15 사용자 '기술도 최적화')
def _move_val(p, k):
    """후보를 줄이는 대략 점수: 위력 × 자속 × 공격 쪽 맞음 × 명중."""
    mv = raw()['moves'].get(k) or {}
    if not mv.get('power') or mv.get('cat') == 'status': return 0
    st = (p.get('info') or {}).get('stats') or {}
    cat = 'physical' if st.get('atk', 0) >= st.get('spa', 0) else 'special'
    types = set((_maps()[0].get(p['species']) or {}).get('types') or [])
    return mv['power'] * (1.5 if mv.get('type') in types else 1) * (1 if mv.get('cat') == cat else 0.5) * ((mv.get('acc') or 100) / 100)

def tune_kit(team, foes, tm_moves, bag_items, legend_of=None, seeds=1, per_mon=6, say=print):
    """랭크 팀의 기술(기술머신으로 배울 수 있는 것)과 지닌 도구(가방에 있는 것)를 시뮬로 다듬는다.
    tm_moves = {포켓몬 id: {기술: 기술머신 번호}}, bag_items = {도구: 개수} (지닐 수 있는 것만 넘길 것).
    돌려주는 것: (새 팀 사본, 이긴 비율 전, 후, 바꾼 것 목록[(id, 'move', 잊을, 배울, 번호) | (id, 'held', 전, 후)])"""
    legend_of = legend_of or (lambda p: False)
    T = [dict(p, moves=list(p.get('moves') or [])) for p in team]
    sc = lambda t: win_rate(t, foes, seeds)
    base = cur = sc(T); changes = []
    for i, p in enumerate(T):
        cand = sorted((k for k in (tm_moves.get(p['id']) or {}) if k not in p['moves']), key=lambda k: _move_val(p, k), reverse=True)[:per_mon]
        for k in cand:
            best = None
            for s in range(len(p['moves'])):
                t = [dict(x) for x in T]; t[i]['moves'] = p['moves'][:s] + [k] + p['moves'][s + 1:]
                v = sc(t)
                if v > cur + 1e-9 and (best is None or v > best[0]): best = (v, s)
            if best:
                v, s = best; old = p['moves'][s]
                p['moves'] = p['moves'][:s] + [k] + p['moves'][s + 1:]; T[i] = p; cur = v
                changes.append((p['id'], 'move', old, k, tm_moves[p['id']][k]))
    for i, p in enumerate(T):
        have = {str(x.get('held')).upper() for j, x in enumerate(T) if j != i and x.get('held')}
        if p.get('held') in set(_maps()[3].values()): continue   # 메가스톤은 그대로 (유대 미션으로 받은 것)
        for it, n in bag_items.items():
            if n <= 0 or it.upper() in have or it == p.get('held'): continue
            t = [dict(x) for x in T]; t[i]['held'] = it
            v = sc(t)
            if v > cur + 1e-9:
                old = p.get('held'); p = dict(p, held=it); T[i] = p; cur = v
                changes = [c for c in changes if not (c[0] == p['id'] and c[1] == 'held')] + [(p['id'], 'held', old, it)]
    return T, base, cur, changes
