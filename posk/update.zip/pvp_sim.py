# -*- coding: utf-8 -*-
"""랜덤 배틀 팀 고르기 - 서버와 같은 배틀 엔진(common/party_battle)으로 미리 붙여 본다 (2026-11-15 맥).

랜덤 배틀은 '양쪽 팀 + 시드'면 결과가 정해지는 자동 판이다(server/app/pvp.py run_match).
그래서 최근에 만난 상대 팀들을 대전 기록(재생 로그)에서 되살리고, 내 후보 팀을 그 팀들과 여러 시드로
붙여 이긴 비율이 가장 높은 팀을 고른다. 상대의 기술·특성·메가는 로그에 나온 것만 알 수 있어서
안 나온 기술은 배울 수 있는 기술 중 센 것으로, 노력치는 '공격 쪽 252 + 스피드 252' 로 채운다.

사냥기(posk_hunt.py)가 api 함수를 넘겨 쓴다. 서버 규칙(같은 종 1, 전설·환상 1, 같은 도구 1,
탐험 중 제외, Lv.50 이상 6마리)은 여기서 같이 지킨다.
"""
import json, os, random, sys, time

MAC = sys.platform == 'darwin'
HERE = os.path.dirname(sys.executable) if getattr(sys, 'frozen', False) else os.path.dirname(os.path.abspath(__file__))   # 윈도우 exe: 코드\ 가 아니라 exe 옆 _game_pyc (posk_hunt 와 같게)
GAME = os.path.expanduser('~/dev/개발_프로젝트/poketdesktop') if MAC else os.path.join(HERE, '_game_pyc')
GDIR = os.path.expanduser('~/Library/Application Support/poketdesktop') if MAC else os.path.join(os.environ.get('APPDATA', ''), 'poketdesktop')
CACHE = os.path.join(HERE, '랜덤배틀_상대팀.json')
CAP = 50
TERA_HELD_FROM = '2026-11-15T15:35'   # 게임 v2.5.1 (테라피스 = 지니는 도구) 나온 때, UTC

if GAME not in sys.path: sys.path.insert(0, GAME)
from common import pokelogic as PL, party_battle as PB, held as HD   # noqa: E402
_KR_HELD = sorted(((v, k) for k, v in HD.KR.items() if len(v) >= 2), key=lambda x: -len(x[0]))   # 로그 문구에서 도구 이름 찾기 (긴 이름 먼저)

_dex = _raw = None
def dex():
    global _dex, _raw
    if _dex is None:
        p = os.path.join(GDIR, 'pokedex.json')
        _raw = json.load(open(p, encoding='utf-8')); _dex = PL.Pokedex.load(p)
    return _dex

def raw():
    dex(); return _raw

def _maps():
    r = raw()
    sp = {s['internal']: s for s in r['species']}
    mv = r['moves'] if isinstance(r['moves'], dict) else {m['key']: m for m in r['moves']}
    kr2mv = {}
    for k, m in mv.items(): kr2mv.setdefault(m.get('kr'), k)
    stone = {}   # (종) -> 메가스톤
    for m in r.get('megas') or []:
        if m.get('megaOf') and m.get('megaStone'): stone.setdefault(m['megaOf'], m['megaStone'])
    return sp, mv, kr2mv, stone

# ------------------------------------------------------------ 상대 팀 되살리기
def _foe_from_match(ev):
    sp, mv, kr2mv, stone = _maps()
    E = ev.get('events') or []
    t = next((e for e in E if e.get('t') == 'teams'), None)
    if not t: return None
    team = [{'species': m['species'], 'num': m.get('num'), 'maxhp': m.get('maxhp'), 'moves': [], 'ability': None, 'mega': False} for m in t.get('foe') or []]   # 11/19: num = 폼 (워시로토무 10009·크라운자시안 10188)
    by_name, by_species = {}, {}
    for i, m in enumerate(t.get('foe') or []):
        by_name.setdefault(m.get('name'), i); by_species.setdefault(m.get('species'), i)
    cur = None
    for e in E:
        # 11/22: 메가진화하면 round 의 foe 이름이 '메가레쿠쟈'로 바뀌어 by_name 실패 → 직전 포켓몬에 기술·도구가 오염됐다
        # (예: 레쿠쟈의 신속이 따라큐에 붙어 선공 어긋남). round 는 메가라도 base species 를 담으므로 species 로 추적(랜덤배틀 같은종 1마리라 유일키)
        if e.get('t') == 'round' and isinstance(e.get('foe'), dict):
            fo = e['foe']; cur = by_species.get(fo.get('species'), by_name.get(fo.get('name'), cur))
        if e.get('who') != 'foe' or cur is None: continue
        if e.get('t') == 'move':
            k = kr2mv.get(e.get('move'))
            if k and k not in team[cur]['moves'] and len(team[cur]['moves']) < 4: team[cur]['moves'].append(k)
        elif e.get('t') == 'zpower':   # 11/22: Z기술이 드러낸 진짜 base 기술 + Z크리스탈 도구 (예전엔 Z기술명이라 버려졌다)
            k = kr2mv.get(e.get('base'))
            if k and k not in team[cur]['moves'] and len(team[cur]['moves']) < 4: team[cur]['moves'].append(k)
            if e.get('item') and not team[cur].get('held'): team[cur]['held'] = e['item']
        elif e.get('t') == 'ability' and e.get('ability'): team[cur]['ability'] = e['ability']
        elif e.get('t') == 'mega': team[cur]['mega'] = True
        elif e.get('t') == 'tera' and e.get('type'): team[cur]['tera'] = e['type']   # 11/16 시즌 6: 테라피스를 지닌 포켓몬만 테라스탈
        if e.get('t') not in ('mega', 'zpower') and not team[cur].get('held'):   # 11/17: '먹다남은음식으로 회복' 같은 문구로 드러난 도구를 남긴다 (예전엔 안 남겨 시뮬이 상대 도구를 없음으로 봤음)
            txt = e.get('text') or ''
            for kr, k in _KR_HELD:
                if kr in txt and not k.endswith('ITE') and 'TERASHARD' not in k: team[cur]['held'] = k; break
    return team

def foe_teams(api, n=60):
    """최근 랜덤 배틀 상대 팀 (되살린 것). 판마다 한 번만 받아 CACHE 에 둔다."""
    try: cache = json.load(open(CACHE, encoding='utf-8'))
    except Exception: cache = {}
    rec = (api(f'/api/pvp/records?limit={min(100, n)}') or {}).get('records') or []
    out = []
    for r in rec:
        if r.get('kind') != 'random' or not r.get('matchId'): continue
        k = str(r['matchId'])
        if k not in cache and r.get('canReplay', True):
            ev = api(f"/api/pvp/match/{r['matchId']}") or {}
            team = _foe_from_match(ev)
            if team and (r.get('at') or '') < TERA_HELD_FROM:
                for m in team: m.pop('tera', None)   # 2.5.1 전 판은 누구나 첫째 타입으로 테라스탈됐음(버그) - 테라피스 증거 아님
            if team: cache[k] = {'at': r.get('at'), 'result': r.get('result'), 'foe': r.get('foe'), 'foeId': r.get('foeId'), 'practice': r.get('practice'), 'team': team}
        elif k in cache and r.get('canReplay', True) and any(m.get('num') is None and m['species'] in _form_species() for m in cache[k]['team']):
            # 11/19: 예전 기록엔 폼(도감 번호)이 없어 워시로토무를 기본 로토무로 되살렸음(시뮬 93% vs 실제 14%) → 폼 있는 종이 든 판만 번호를 다시 받음
            t = next((e for e in (api(f"/api/pvp/match/{r['matchId']}") or {}).get('events') or [] if e.get('t') == 'teams'), None)
            if t and len(t.get('foe') or []) == len(cache[k]['team']):
                for m, x in zip(cache[k]['team'], t['foe']): m['num'] = x.get('num')
        if k in cache: out.append(cache[k])
    keep = dict(sorted(cache.items(), key=lambda kv: kv[1].get('at') or '')[-1000:])   # 11/17: 상위권 상대 정보 쌓기 300 → 1000판
    tmp = CACHE + '.tmp'; json.dump(keep, open(tmp, 'w', encoding='utf-8'), ensure_ascii=False); os.replace(tmp, CACHE)
    return enrich(out[:n], list(keep.values()))   # 11/19: 같은 상대·같은 종에서 본 것으로 채움

def enrich(rows, know=None):
    """11/19: 한 판 로그로는 포켓몬당 기술 1.4개만 보여 나머지를 센 공격기로 채웠다 → 실제 상대의 도깨비불·스텔스록·용의춤을 몰라
    시뮬이 크게 낙관(77% vs 실제 54%). 같은 상대(foeId·이름)를 만난 다른 판, 그다음 같은 종을 쓴 다른 상대들에서 본 기술·도구·특성으로 먼저 채운다.
    rows = 되살릴 판들, know = 아는 판 전체(없으면 rows). 원본은 안 바꾸고 사본을 돌려준다."""
    from collections import Counter, defaultdict
    know = know if know is not None else rows
    pm, ph, pa, sm = defaultdict(Counter), defaultdict(Counter), defaultdict(Counter), defaultdict(Counter)
    for v in know:
        who = v.get('foeId') or v.get('foe')
        for m in v.get('team') or []:
            key = (m['species'], m.get('num'))
            for k in m.get('moves') or []:
                sm[key][k] += 1
                if who: pm[(who,) + key][k] += 1
            if who and m.get('held'): ph[(who,) + key][m['held']] += 1
            if who and m.get('ability'): pa[(who,) + key][m['ability']] += 1
    out = []
    for v in rows:
        who = v.get('foeId') or v.get('foe'); team = []
        for m in v.get('team') or []:
            key = (m['species'], m.get('num')); mv_ = list(m.get('moves') or [])
            for src in ((pm.get((who,) + key) if who else None), Counter({k: n for k, n in sm.get(key, Counter()).items() if n >= 2})):
                for k, _ in (src or Counter()).most_common():
                    if len(mv_) >= 4: break
                    if k not in mv_: mv_.append(k)
            m = dict(m, moves=mv_)
            if who and not m.get('held') and ph.get((who,) + key): m['held'] = ph[(who,) + key].most_common(1)[0][0]
            if who and not m.get('ability') and pa.get((who,) + key): m['ability'] = pa[(who,) + key].most_common(1)[0][0]
            team.append(m)
        used = set()   # 같은 도구 1개 규칙: 겹치면 뒤의 것은 비움(흔한 도구로 다시 채워짐)
        for m in team:
            if m.get('held') and not m.get('mega') and not m.get('tera'):
                if m['held'] in used: m['held'] = None
                else: used.add(m['held'])
        out.append(dict(v, team=team))
    return out

def _fill_moves(spc, seen, mv):
    """안 보인 기술 칸: 그 종이 Lv.50 까지 배우는 기술·떠올리기 기술 중 위력 센 것 (자속 우선, 공격 쪽 맞춤)."""
    moves = list(seen)
    if len(moves) >= 4: return moves[:4]
    base = spc.get('base') or {}
    cat = 'physical' if base.get('atk', 0) >= base.get('spa', 0) else 'special'
    pool = {k for l, k in spc.get('moves') or [] if l <= CAP} | set(spc.get('remind') or [])
    types = set(spc.get('types') or [])
    def val(k):
        m = mv.get(k) or {}
        if not m.get('power') or m.get('cat') == 'status': return -1
        return m['power'] * (1.5 if m.get('type') in types else 1) * (1 if m.get('cat') == cat else 0.6) * ((m.get('acc') or 100) / 100)
    seen_types = {(mv.get(k) or {}).get('type') for k in moves}
    for k in sorted(pool, key=val, reverse=True):
        if len(moves) >= 4: break
        if val(k) <= 0: break
        t = (mv.get(k) or {}).get('type')
        if k in moves or (t in seen_types and len(moves) < 3 and len(pool) > 8): continue   # 앞 칸은 타입을 고르게
        moves.append(k); seen_types.add(t)
    for k in sorted(pool, key=val, reverse=True):
        if len(moves) >= 4: break
        if k not in moves and val(k) > 0: moves.append(k)
    return moves or ['TACKLE']

def _form_species():
    return {f['formOf'] for f in raw().get('forms') or [] if f.get('formKind') in ('use', 'held', 'evo')}
FORM_MOVE = {'ROTOM_WASH': 'HYDROPUMP', 'ROTOM_HEAT': 'OVERHEAT', 'ROTOM_FROST': 'BLIZZARD', 'ROTOM_FAN': 'AIRSLASH', 'ROTOM_MOW': 'LEAFSTORM'}   # 폼 바꿀 때 배우는 기술
def _form_of(f, s):
    """로그 도감 번호가 원래 종과 다르면 그 폼 (도감 forms 한 줄). 11/19"""
    if not f.get('num') or f.get('num') == s.get('num'): return None
    return next((x for x in raw().get('forms') or [] if x.get('num') == f['num'] and x.get('formOf') == f['species']), None)
FOE_HELD = ['LIFEORB', 'FOCUSSASH', 'LEFTOVERS', 'CHOICESCARF', 'ASSAULTVEST', 'SITRUSBERRY']   # 시뮬 검증관 11/17 - 로그에 자주 보인 도구
FOE_NATURE = {'atk': 'ADAMANT', 'spa': 'MODEST'}   # 상대는 공격 쪽을 올린 성격으로 본다 (모르는 값 - 세게 잡는 편)
SPE_FAST = 80   # 11/22 선공 보정: 종족값 스피드가 이 값 미만인 상대는 스피드 노력치를 안 주고 방어로 돌린다(느린 벌크형). None 이면 옛 방식(전부 252 스피드)
WAR_FOES = 15   # 11/22 팀 재랭크: 서버 AI(war_ai) 는 판당 ~4초라 재랭크는 최근 상대 이만큼만 (후보 TOPK 개 × 이 수)
TEAM_TOPK = 8   # 옛 AI 상위 이만큼을 서버 AI로 재랭크 (옛 AI·서버 AI 상관 0.69라 넉넉히)

_meta, _meta_at = None, 0
def species_meta():
    """11/20 보정: 쌓인 상대 기록 전체에서 종마다 실제로 쓴 기술·드러난 도구 빈도 (안 보인 칸을 레벨업 기술 대신 이걸로 먼저 채움).
    재현 30판 검사: 예전 채움(베어가르기·공중날기 등)은 시뮬 예상 73% vs 실제 53% (Brier 0.38)."""
    global _meta, _meta_at
    if _meta is not None and time.time() - _meta_at < 600: return _meta
    import collections
    mvs, held = collections.defaultdict(collections.Counter), collections.defaultdict(collections.Counter)
    try: cache = json.load(open(CACHE, encoding='utf-8'))
    except Exception: cache = {}
    for v in cache.values():
        for m in v.get('team') or []:
            for k in m.get('moves') or []: mvs[m['species']][k] += 1
            if m.get('held'): held[m['species']][m['held']] += 1
    _meta, _meta_at = (mvs, held), time.time()
    return _meta

def _real_move(mv, k):
    m = mv.get(k) or {}
    return bool(m) and (m.get('pp') or 0) > 1   # Z기술(pp 1)은 로그에 기술 이름으로 찍히지만 배운 기술이 아니다

def _meta_moves(f, mvs, mv):
    seen = [k for k in f.get('moves') or [] if _real_move(mv, k)]
    for k, _ in mvs[f['species']].most_common():
        if len(seen) >= 4: break
        if k not in seen and _real_move(mv, k): seen.append(k)
    return seen

def foe_mons(team):
    sp, mv, kr2mv, stone = _maps()
    mvs, helds = species_meta()
    out = []
    # 11/17: 상대 도구를 '없음'으로 두면 예상이 부풀었다(재현 244판: 71.6% → 채우면 52.9%, 실제 53.1%). 안 보인 자리는 흔한 도구로 채운다 (같은 도구 1개 규칙)
    used = {f.get('held') for f in team if f.get('held')}
    guess = {}   # 안 보인 도구: 그 종이 다른 판에서 지녔던 것 중 가장 흔한 것 (같은 도구 1개 규칙)
    for f in team:
        if f.get('held') or f.get('mega') or f.get('tera'): continue
        for k, _ in helds[f['species']].most_common():
            if k not in used: guess[f['species']] = k; used.add(k); break
    spare = [x for x in FOE_HELD if x not in used]
    for i, f in enumerate(team):
        s = sp.get(f['species']) or {}
        fm = _form_of(f, s)
        if fm:   # 폼의 종족값·타입으로 기술 채우기·노력치를 잡는다 (배틀 엔진은 form/held 로 폼을 정함)
            s = dict(s, base=fm['base'], types=fm.get('types') or s.get('types'))
            if FORM_MOVE.get(fm['internal']) and FORM_MOVE[fm['internal']] not in (f.get('moves') or []):
                f = dict(f, moves=(list(f.get('moves') or []) + [FORM_MOVE[fm['internal']]])[:4])
        base = s.get('base') or {}
        atk = 'atk' if base.get('atk', 0) >= base.get('spa', 0) else 'spa'
        # 체력 노력치는 로그의 최대 체력에서 되짚는다: Lv.50 최대 체력 = (2×종족값 + 개체값 + 노력치/4) / 2 + 60
        hp_ev = 4
        if f.get('maxhp') and base.get('hp'):
            hp_ev = max(0, min(252, int(((f['maxhp'] - 60) * 2 - 2 * base['hp'] - 31) * 4)))
        evs = {'hp': hp_ev, 'atk': 0, 'def': 0, 'spa': 0, 'spd': 0, 'spe': 0}
        # 11/22 벽형 보정(피해): 체력 크게 투자(hp_ev>=120)·공격 종족값 낮은(<=120) 종은 무보정 성격·공격 0 벽으로 쓰인다 (벌크어태커·순수 공격형은 그대로). 진단: 하마돈·아머까오 등 벽형을 과대평가(공비 0.39~0.72)
        wall = hp_ev >= 120 and base.get(atk, 0) <= 120
        evs[atk] = 0 if wall else 252
        room = max(0, 510 - hp_ev - evs[atk])
        # 11/22 선공 보정: 느린 종은 스피드 노력치 대신 방어로 (진단: 대도각참 실제 선공 67% vs 옛 시뮬 48% - 252 스피드가 느린 벌크 상대를 과대평가)
        if SPE_FAST is None or base.get('spe', 0) >= SPE_FAST:
            evs['spe'] = min(252, room)
        else:
            evs['def'] = min(252, room)
        # 11/21: 로그에서 주운 특성이 그 종 특성이 아니면 버린다 — 메가레쿠쟈의 델타스트림 글이 다음에 나온 루카리오·따라큐·어흥염에 붙어
        # 상대 따라큐가 '탈' 없이 시뮬됐음(쌓인 기록 13마리). 종 특성(보통·숨은) 안에 있을 때만 쓰고, 아니면 첫 특성
        own_ab = set(s.get('abil') or []) | ({s.get('hidden')} if s.get('hidden') else set())
        ab = f.get('ability') if f.get('ability') in own_ab else ((s.get('abil') or [None])[0])
        out.append({'id': -1 - i, 'species': f['species'], 'nickname': None, 'level': CAP, 'exp': 0, 'nature': 'HARDY' if wall else FOE_NATURE.get(atk, 'HARDY'),
                    'ability': ab, 'hiddenAbility': ab == s.get('hidden'), 'gender': 'M', 'shiny': False, 'happiness': 255,
                    'ivs': {k: 31 for k in ('hp', 'atk', 'def', 'spa', 'spd', 'spe')}, 'evs': evs,
                    'moves': _fill_moves(s, _meta_moves(f, mvs, mv), mv),
                    'held': stone.get(f['species']) if f.get('mega') else (f['tera'] + 'TERASHARD' if f.get('tera') else (f.get("held") or guess.get(f["species"]) or (next((spare.pop(j) for j, x in enumerate(spare) if not (wall and x in ('LIFEORB', 'EXPERTBELT'))), None) if spare else None))), 'bonded': bool(f.get('mega'))})
        if fm and fm.get('formKind') in ('use', 'evo'): out[-1]['form'] = fm['form']
        elif fm and fm.get('formKind') == 'held' and fm.get('items'): out[-1]['held'] = fm['items'][0]   # 녹슨검 → 크라운자시안
    return out

# ------------------------------------------------------------ 붙여 보기
_MY_KEYS = ('id', 'species', 'nickname', 'level', 'exp', 'nature', 'ability', 'hiddenAbility', 'gender', 'shiny', 'happiness',
            'ivs', 'evs', 'moves', 'held', 'bonded', 'hyper', 'form')
def my_mon(p):
    m = {k: p.get(k) for k in _MY_KEYS if k in p}
    m['level'] = min(CAP, int(m.get('level') or 1))
    return m

def win_rate(team, foes, seeds=2, keystone=True, seed0=7, war_ai=True):   # 11/17: 서버 랭크·연습판은 war_ai(스스로 교체)로 돈다 - False 면 예상 승률이 +18점 부풀었음
    """team(내 포켓몬 dict, 순서대로) 이 foes(상대 팀 목록) 에게 이긴 비율. 비기면 반."""
    d = dex(); mine = [my_mon(p) for p in team]; s = n = 0
    for j, f in enumerate(foes):
        for k in range(seeds):
            try:
                o = PB.simulate(d, [dict(x) for x in mine], [dict(x) for x in f], seed=seed0 + 1000 * j + k,
                                keystone={'me': keystone, 'foe': True}, zring={'me': keystone, 'foe': True}, war_ai=war_ai,
                                tera_orb={'me': keystone, 'foe': True})   # 11/16: 테라피스를 지닌 쪽만 실제로 씀
            except Exception:
                continue
            s += {'me': 1, 'draw': 0.5}.get(o.get('winner'), 0); n += 1
    return s / n if n else 0

def legal(team, legend_of):
    sps = [p['species'] for p in team]
    if len(set(sps)) < len(sps): return False
    if sum(1 for p in team if legend_of(p)) > 1: return False
    held = [str(p.get('held')).upper() for p in team if p.get('held')]
    return len(set(held)) == len(held)

def best_team(P, foes, away=(), current=(), legend_of=None, budget=150, seeds=2, say=print):
    """랜덤 배틀 팀 고르기: 지금 팀·사냥기 추천 팀에서 시작해 한 자리씩 바꿔 보며 이긴 비율이 오르면 남긴다.
    budget = 팀을 붙여 볼 횟수 상한 (한 번 = 상대 팀 수 × seeds 판)."""
    legend_of = legend_of or (lambda p: False)
    pool = [p for p in P if int(p.get('level') or 0) >= CAP and p['id'] not in set(away)
            and sum(1 for k in p.get('moves') or [] if (raw()['moves'].get(k) or {}).get('power')) >= 2]
    byid = {p['id']: p for p in pool}
    # 후보를 줄인다: 혼자서 상대 첫 판 몇 개에 얼마나 버티나(1:6) 대신 종족값·레벨 큰 순 상위 40
    sp = _maps()[0]
    bst = lambda p: sum((sp.get(p['species']) or {}).get('base', {}).values())
    # 11/15 사용자 '스피드와 공격이 빠르면 연타로 이기지 않나' - 시뮬로 재 보니 맞다: 스피드×공격(물리·특수 큰 쪽) 순 팀이
    # 58%, 종족값 순 후보에서 찾은 팀은 52%. 그래서 후보는 두 줄 세우기를 합치고, 출발점도 스피드×공격 팀으로 둔다.
    st = lambda p: ((p.get('info') or {}).get('stats') or {})
    sa = lambda p: st(p).get('spe', 0) * max(st(p).get('atk', 0), st(p).get('spa', 0))
    cands = []
    for p in sorted(pool, key=bst, reverse=True)[:30] + sorted(pool, key=sa, reverse=True)[:30]:
        if p not in cands: cands.append(p)
    for i in current:
        if i in byid and byid[i] not in cands: cands.append(byid[i])
    def fill(t, order):
        t = list(t)
        for p in order:
            if len(t) >= 6: break
            if p not in t and legal(t + [p], legend_of): t.append(p)
        return t
    starts = [fill([], sorted(pool, key=sa, reverse=True)), fill([byid[i] for i in current if i in byid][:6], cands)]
    starts = [t for t in starts if len(t) == 6]
    if not starts: return None, 0, 0
    cache, teams = {}, {}
    def score(t):
        k = tuple(p['id'] for p in t)
        if k not in cache: cache[k] = win_rate(t, foes, seeds, war_ai=False); teams[k] = t   # 찾기는 빠른 옛 AI(80배 빠름), 상위만 서버 AI로 재랭크
        return cache[k]
    cur_ids = [i for i in current if i in byid]
    base = score([byid[i] for i in cur_ids]) if len(cur_ids) == 6 else 0
    best = max(starts, key=score); bs = score(best); used = 3
    improved = True
    while improved and used < budget:
        improved = False
        for slot in range(6):
            for p in cands:
                if used >= budget: break
                if p in best: continue
                t = best[:slot] + [p] + best[slot + 1:]
                if not legal(t, legend_of): continue
                v = score(t); used += 1
                if v > bs + 1e-9: best, bs, improved = t, v, True
        # 순서(선두) 바꾸기: 앞 두 자리를 나머지와 바꿔 본다
        for a in range(2):
            for b in range(a + 1, 6):
                if used >= budget: break
                t = list(best); t[a], t[b] = t[b], t[a]
                v = score(t); used += 1
                if v > bs + 1e-9: best, bs, improved = t, v, True
    # 11/22: 옛 AI는 '후보 추리기'만 한다 (서버 AI와 상관 0.69뿐 → 옛 1등은 실제 war 기준 ~21점 손해, 순위 20% 뒤집힘).
    # 상위 TOPK + 지금 팀을 서버 AI(war_ai)로 재랭크해 진짜 1등을 고른다. 지금 팀을 항상 넣어 현상유지 밑으로는 안 간다.
    cur_team = [byid[i] for i in cur_ids] if len(cur_ids) == 6 else None
    if cur_team: score(cur_team)
    shortlist = [teams[k] for k, _ in sorted(cache.items(), key=lambda kv: -kv[1])[:TEAM_TOPK]]
    if cur_team and all(tuple(p['id'] for p in cur_team) != tuple(p['id'] for p in t) for t in shortlist): shortlist.append(cur_team)
    wfoes = foes[:min(len(foes), WAR_FOES)]   # war 는 느리므로 재랭크는 상대 축소
    wr = {tuple(p['id'] for p in t): win_rate(t, wfoes, 1, war_ai=True, seed0=50001) for t in shortlist}
    best = teams[max(wr, key=wr.get)]
    # 결선(고른 war 1등 + 지금 팀)만 전체 상대·새 시드로 정직 채점 - 게이팅이 볼 맞대결 (2팀뿐이라 시드 +1)
    bs = win_rate(best, foes, seeds + 1, war_ai=True, seed0=90001)
    base = win_rate(cur_team, foes, seeds + 1, war_ai=True, seed0=90001) if cur_team else 0
    return best, bs, base

# ------------------------------------------------------------ 기술·도구 다듬기 (11/15 사용자 '기술도 최적화')
def _move_val(p, k):
    """후보를 줄이는 대략 점수: 위력 × 자속 × 공격 쪽 맞음 × 명중."""
    mv = raw()['moves'].get(k) or {}
    if not mv.get('power') or mv.get('cat') == 'status': return 0
    st = (p.get('info') or {}).get('stats') or {}
    cat = 'physical' if st.get('atk', 0) >= st.get('spa', 0) else 'special'
    types = set((_maps()[0].get(p['species']) or {}).get('types') or [])
    return mv['power'] * (1.5 if mv.get('type') in types else 1) * (1 if mv.get('cat') == cat else 0.5) * ((mv.get('acc') or 100) / 100)

def tune_kit(team, foes, tm_moves, bag_items, legend_of=None, seeds=1, per_mon=6, say=print):
    """랭크 팀의 기술(기술머신으로 배울 수 있는 것)과 지닌 도구(가방에 있는 것)를 시뮬로 다듬는다.
    tm_moves = {포켓몬 id: {기술: 기술머신 번호}}, bag_items = {도구: 개수} (지닐 수 있는 것만 넘길 것).
    돌려주는 것: (새 팀 사본, 이긴 비율 전, 후, 바꾼 것 목록[(id, 'move', 잊을, 배울, 번호) | (id, 'held', 전, 후)])"""
    legend_of = legend_of or (lambda p: False)
    T = [dict(p, moves=list(p.get('moves') or [])) for p in team]
    sc = lambda t: win_rate(t, foes, seeds)
    base = cur = sc(T); changes = []
    for i, p in enumerate(T):
        cand = sorted((k for k in (tm_moves.get(p['id']) or {}) if k not in p['moves']), key=lambda k: _move_val(p, k), reverse=True)[:per_mon]
        for k in cand:
            best = None
            for s in range(len(p['moves'])):
                t = [dict(x) for x in T]; t[i]['moves'] = p['moves'][:s] + [k] + p['moves'][s + 1:]
                v = sc(t)
                if v > cur + 1e-9 and (best is None or v > best[0]): best = (v, s)
            if best:
                v, s = best; old = p['moves'][s]
                p['moves'] = p['moves'][:s] + [k] + p['moves'][s + 1:]; T[i] = p; cur = v
                changes.append((p['id'], 'move', old, k, tm_moves[p['id']][k]))
    for i, p in enumerate(T):
        have = {str(x.get('held')).upper() for j, x in enumerate(T) if j != i and x.get('held')}
        if p.get('held') in set(_maps()[3].values()): continue   # 메가스톤은 그대로 (유대 미션으로 받은 것)
        for it, n in bag_items.items():
            if n <= 0 or it.upper() in have or it == p.get('held'): continue
            t = [dict(x) for x in T]; t[i]['held'] = it
            v = sc(t)
            if v > cur + 1e-9:
                old = p.get('held'); p = dict(p, held=it); T[i] = p; cur = v
                changes = [c for c in changes if not (c[0] == p['id'] and c[1] == 'held')] + [(p['id'], 'held', old, it)]
    return T, base, cur, changes

# ------------------------------------------------------------ 보정 검사 (11/20)
def calibrate(api, team, n=30, seeds=2):
    """최근 랭크 판(연습판 빼고) n 개를 지금 팀으로 다시 붙여 '시뮬 예상 승률 vs 실제'를 잰다.
    gap = 예상 - 실제 (양수면 시뮬이 낙관). brier 는 0.25(동전) 보다 작아야 판별력이 있다."""
    try: cache = json.load(open(CACHE, encoding='utf-8'))
    except Exception: cache = {}
    rec = [r for r in (api('/api/pvp/records?limit=100') or {}).get('records') or []
           if r.get('kind') == 'random' and not r.get('practice') and str(r.get('matchId')) in cache][:n]
    if len(rec) < 10: return None
    rows = [(win_rate(team, [foe_mons(cache[str(r['matchId'])]['team'])], seeds=seeds), 1 if r.get('result') == 'win' else 0) for r in rec]
    pred = sum(p for p, _ in rows) / len(rows); act = sum(a for _, a in rows) / len(rows)
    # 11/22: 과신 shrinkage k 적합 (p' = 0.5 + k(p-0.5)). prior 0.5 로 당겨 소표본 요동 억제 - 사냥기가 예측을 교정·게이팅에 씀
    def _fit_k(rows, lam=0.1, k0=0.5):
        best = (k0, 1e18)
        for i in range(101):
            kk = i / 100.0
            b = sum((0.5 + kk * (p - 0.5) - a) ** 2 for p, a in rows) / len(rows) + lam * (kk - k0) ** 2
            if b < best[1]: best = (kk, b)
        return best[0]
    k = _fit_k(rows)
    bc = sum((0.5 + k * (p - 0.5) - a) ** 2 for p, a in rows) / len(rows)
    return {'n': len(rows), 'pred': round(pred, 3), 'actual': round(act, 3), 'gap': round(pred - act, 3),
            'brier': round(sum((p - a) ** 2 for p, a in rows) / len(rows), 3),
            'k': round(k, 2), 'brier_cal': round(bc, 3), 'at': time.strftime('%Y-%m-%d %H:%M')}
