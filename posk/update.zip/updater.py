# -*- coding: utf-8 -*-
"""자동 업데이트 (2026-10-13) - 윈도우 exe·맥 같이 쓴다.

구글 드라이브의 '포스크탑자동사냥_업데이트/업데이트.zip' (안에 버전.txt + 코드)이 지금 판보다 새로우면 코드만 풀어 넣는다.
기록·설정 파일은 zip 에 없으니 건드리지 않는다. zip 하나로 받는 것은 드라이브가 파일을 반쯤 받은 상태에서
섞여 풀리지 않게 하려고 (zip 검사가 실패하면 다음에 다시 본다). 이 폴더(사냥기 폴더)에 업데이트.zip 을 직접 넣어도 된다.

풀어 넣는 곳: 윈도우 exe = exe 옆 '코드' 폴더 (launcher 가 그 폴더의 .py 를 exe 안의 것보다 먼저 쓴다),
맥(.py 로 실행) = 사냥기 폴더 그대로. 적용 시점: 사냥기는 새 판을 보면 스스로 끝나고 고리가 다시 켜며 받는다,
조종판은 다음에 열 때.
"""
import glob, io, os, sys, tempfile, zipfile
FROZEN = getattr(sys, 'frozen', False)
HERE = os.path.dirname(sys.executable) if FROZEN else os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(HERE, '코드') if FROZEN else HERE
NAME = os.path.join('포스크탑자동사냥_업데이트', '업데이트.zip')

def drives():
    if sys.platform == 'darwin':
        return glob.glob(os.path.expanduser('~/Library/CloudStorage/GoogleDrive-*/*'))   # '내 드라이브' / 'My Drive'
    return [f'{d}:\\{n}' for d in 'DEFGHIJKLMNOPQRSTUVWXYZ' for n in ('내 드라이브', 'My Drive')]

def version(path=None):
    try:
        if path is None: return open(os.path.join(CODE, '버전.txt'), encoding='utf-8').read().strip()
        with zipfile.ZipFile(path) as z: return z.read('버전.txt').decode('utf-8').strip()
    except Exception: return ''

def vkey(v):
    # '2026.10.13-12' → (2026, 10, 13, 12). 글자 비교는 '-12' < '-9' 라서 10번째 판부터 못 받았다 (10/13)
    import re
    return tuple(int(n) for n in re.findall(r'\d+', v or ''))

# 10/19 사용자 '받은 분들도 재실행할 때마다 자동 업데이트' — 상담도우미와 같은 방식(사용자 결정):
# youngnak-guide(GitHub Pages)/posk/ 의 version.txt 가 지금 판보다 새로우면 update.zip·update.sig 를 받아
# **서명(Ed25519)이 맞을 때만** 사냥기 폴더의 업데이트.zip 으로 둔다(그다음은 직접 넣은 업데이트.zip 과 같은 길).
# 비밀키 = 판 내는 PC ~/.yrgo/posk_sign.key (pack.py → publish). 켤 때 한 번, 그 뒤 30분에 한 번. 인터넷이 안 되면 조용히 넘어감
UPD = 'https://youngnakhs.github.io/youngnak-guide/posk/'
SIGN_PUB = 'Dx6KVvhUbbKJ63Anj+QgtsnUI1SdF3KaJBWuG1aUjHg='
_fetched = 0
def signed(data, sig):
    try:
        import base64
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
        Ed25519PublicKey.from_public_bytes(base64.b64decode(SIGN_PUB)).verify(base64.b64decode(sig), data); return True
    except Exception: return False
def fetch():
    global _fetched
    import time, urllib.request
    if time.time() - _fetched < 1800: return
    _fetched = time.time()
    get = lambda n, t: urllib.request.urlopen(urllib.request.Request(f'{UPD}{n}?t={int(time.time())}', headers={'User-Agent': 'posk-hunt'}), timeout=t).read()
    try:
        if vkey(get('version.txt', 5).decode('utf-8').strip()) <= vkey(version()): return
        data, sig = get('update.zip', 30), get('update.sig', 10).decode().strip()
        if not signed(data, sig): return
        with zipfile.ZipFile(io.BytesIO(data)) as z: v = z.read('버전.txt').decode('utf-8').strip()
        if vkey(v) <= vkey(version()): return
        fd, tmp = tempfile.mkstemp(dir=HERE)
        with os.fdopen(fd, 'wb') as f: f.write(data)
        os.replace(tmp, os.path.join(HERE, '업데이트.zip'))
    except Exception: pass

def newer():
    """더 새 판 zip 경로 (없으면 None). 버전은 '2026.10.13-1' 꼴 - 숫자로 비교한다."""
    fetch()
    cur = vkey(version())
    for d in [HERE] + drives():
        p = os.path.join(d, NAME) if d != HERE else os.path.join(HERE, '업데이트.zip')
        if os.path.isfile(p) and vkey(version(p)) > cur: return p

# 10/19 사용자 '기본을 다 내가 쓰고 있는 것으로': 조종판설정.json 에 없는 항목만 판 내는 사람(나)의 설정으로 채운다.
# 이미 적혀 있는 값(받은 사람이 바꾼 것)은 건드리지 않는다. 포켓몬 번호가 들어가는 것(관장_고정파티·육성_목록)과 창 위치는 뺀다
# 랭크팀_고정만 False: 나는 손으로 고른 팀이라 고정했지만, 받은 사람은 사냥기가 그 사람 포켓몬으로 랭크 팀을 골라 줘야 한다
DEFAULTS = {'포획_시도횟수': 3, '육성슬롯': True, '관장_수련': True, '육성_목표레벨': 100, '육성_자리수': 3, '돈_모드': True,
            '기술_자동판단': False, '랭크팀_고정': False, '관장_올클리어': False, '도감_모드': True,
            '노력치_자동': True, '도구_자동판매': True, '박스_정리': True}
def defaults():
    import json
    f = os.path.join(HERE, '조종판설정.json')
    try: c = json.load(open(f, encoding='utf-8'))
    except FileNotFoundError: c = {}
    except Exception: return   # 깨진 파일은 그대로 둠 (조종판이 다시 씀)
    add = {k: v for k, v in DEFAULTS.items() if k not in c}
    if add:
        c.update(add); tmp = f + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as o: json.dump(c, o, ensure_ascii=False)
        os.replace(tmp, f)

def apply():
    """새 판이 있으면 풀어 넣고 그 버전을, 없으면 None. 파일마다 임시로 풀었다가 바꿔치기(동시에 두 곳이 불러도 반쪽 파일 없음)."""
    try: defaults()
    except Exception: pass
    p = newer()
    if not p: return None
    try:
        data = open(p, 'rb').read()
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            if z.testzip() is not None: return None
            names = [n for n in z.namelist() if not n.endswith('/') and '..' not in n and not os.path.isabs(n)]
            for n in sorted(names, key=lambda n: n == '버전.txt'):   # 버전.txt 는 맨 끝 (중간에 끊기면 다음에 다시)
                dst = os.path.join(CODE, *n.split('/'))
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dst))
                with os.fdopen(fd, 'wb') as f: f.write(z.read(n))
                os.replace(tmp, dst)
        return version()
    except Exception: return None

GAME = os.path.join(HERE, '_game_pyc')
def game_code():
    """윈도우: 게임 규칙 코드(common·poketdesktop)가 없으면 게임 공식 저장소(GitHub, 공개)의 최신 판 소스에서 받는다 (10/13).
    공유받은 PC 용 — 게임 코드를 나눠 주지 않고, 받는 PC 가 직접 받는다. 하루 한 번 새 판인지 본다. 맥은 설치가 소스를 받아 둔다."""
    if sys.platform == 'darwin': return None
    tag_f = os.path.join(GAME, '태그.txt')
    if os.path.isdir(os.path.join(GAME, 'common')) and not os.path.exists(tag_f): return None   # 직접 넣어 둔 게임 코드(.pyc)는 그대로
    try:
        import json, time, urllib.request
        if os.path.exists(tag_f) and time.time() - os.path.getmtime(tag_f) < 86400: return None
        get = lambda u: urllib.request.urlopen(urllib.request.Request(u, headers={'User-Agent': 'posk-hunt'}), timeout=30).read()
        tag = json.loads(get('https://api.github.com/repos/rudtjr1106/poketdesktop/releases/latest'))['tag_name']
        if os.path.exists(tag_f) and open(tag_f, encoding='utf-8').read().strip() == tag:
            os.utime(tag_f); return None
        with zipfile.ZipFile(io.BytesIO(get(f'https://codeload.github.com/rudtjr1106/poketdesktop/zip/refs/tags/{tag}'))) as z:
            for n in z.namelist():
                parts = n.split('/')[1:]
                if not n.endswith('.py'): continue
                if parts[0] == 'common': dst = os.path.join(GAME, *parts)
                elif parts[:2] == ['client', 'poketdesktop']: dst = os.path.join(GAME, *parts[1:])
                else: continue
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                fd, tmp = tempfile.mkstemp(dir=os.path.dirname(dst))
                with os.fdopen(fd, 'wb') as f: f.write(z.read(n))
                os.replace(tmp, dst)
        open(tag_f, 'w', encoding='utf-8').write(tag)
        return tag
    except Exception: return None

if __name__ == '__main__':
    v = apply()
    print(f'새 판 {v} 받음' if v else f'지금 판 {version() or "?"} (새 판 없음)')
